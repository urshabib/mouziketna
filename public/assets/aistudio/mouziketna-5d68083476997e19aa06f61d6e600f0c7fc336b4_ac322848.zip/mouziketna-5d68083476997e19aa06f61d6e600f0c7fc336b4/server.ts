import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = '0.0.0.0';
const UPSTREAM_WORKER = 'https://new-music-space-api.urshabib.workers.dev';

// =========================================================================
// 1. DATA TYPES & SCHEMAS
// =========================================================================

export interface UserSession {
  sessionId: string;
  sessionToken: string;
  username: string;
  deviceId: string;
  deviceName: string;
  deviceFingerprint?: string;
  ip: string;
  userAgent: string;
  createdAt: number;
  lastActive: number;
  expiresAt: number;
}

export interface PlaybackLease {
  username: string;
  deviceId: string;
  deviceName: string;
  streamToken: string; // Short-lived audio playback token
  leaseEpoch: number; // Monotonically increasing epoch
  trackId?: string;
  trackTitle?: string;
  trackArtist?: string;
  trackThumb?: string;
  currentTime: number;
  duration: number;
  state: 'playing' | 'paused';
  startedAt: number;
  lastHeartbeat: number;
  expiresAt: number;
  updatedAt: number;
}

// =========================================================================
// 2. REDIS STATE ENGINE (ioredis-compatible with In-Memory Multi-Node Fallback)
// =========================================================================

interface RedisClientInterface {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, ...args: any[]): Promise<'OK' | null>;
  del(...keys: string[]): Promise<number>;
  publish(channel: string, message: string): Promise<number>;
  subscribe(channel: string, cb: (msg: string) => void): Promise<void>;
  eval(script: string, numkeys: number, ...keysAndArgs: string[]): Promise<any>;
}

// Lua Script: Atomic Playback Handover
// 1. Checks existing lease for user
// 2. Increments leaseEpoch
// 3. Sets new streamToken and writes new lease with TTL
// 4. Publishes handover event to Redis Pub/Sub channel
export const ATOMIC_HANDOVER_LUA = `
local current = redis.call("GET", KEYS[1])
local prevDeviceId = ""
local prevDeviceName = ""
local epoch = 1

if current then
  local lease = cjson.decode(current)
  prevDeviceId = lease.deviceId or ""
  prevDeviceName = lease.deviceName or ""
  epoch = (tonumber(lease.leaseEpoch) or 0) + 1
end

local newLease = {
  username = ARGV[1],
  deviceId = ARGV[2],
  deviceName = ARGV[3],
  streamToken = ARGV[4],
  leaseEpoch = epoch,
  trackId = ARGV[5],
  trackTitle = ARGV[6],
  trackArtist = ARGV[7],
  trackThumb = ARGV[8],
  currentTime = tonumber(ARGV[9]) or 0,
  duration = tonumber(ARGV[10]) or 0,
  state = "playing",
  startedAt = tonumber(ARGV[11]) or 0,
  lastHeartbeat = tonumber(ARGV[11]) or 0,
  expiresAt = (tonumber(ARGV[11]) or 0) + ((tonumber(ARGV[12]) or 35) * 1000),
  updatedAt = tonumber(ARGV[11]) or 0
}

local encoded = cjson.encode(newLease)
redis.call("SET", KEYS[1], encoded, "EX", tonumber(ARGV[12]) or 35)

local pubPayload = cjson.encode({
  type = "PLAYBACK_HANDOVER",
  previousDeviceId = prevDeviceId,
  previousDeviceName = prevDeviceName,
  newDeviceId = ARGV[2],
  newDeviceName = ARGV[3],
  leaseEpoch = epoch,
  lease = newLease,
  timestamp = tonumber(ARGV[11])
})
redis.call("PUBLISH", KEYS[2], pubPayload)

return encoded
`;

class InMemoryRedis implements RedisClientInterface {
  private store = new Map<string, { value: string; expiresAt: number | null }>();
  private subscribers = new Map<string, Set<(msg: string) => void>>();

  async get(key: string): Promise<string | null> {
    const item = this.store.get(key);
    if (!item) return null;
    if (item.expiresAt !== null && Date.now() > item.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return item.value;
  }

  async set(key: string, value: string, ...args: any[]): Promise<'OK' | null> {
    let ttlMs: number | null = null;
    let nx = false;

    for (let i = 0; i < args.length; i++) {
      const arg = String(args[i]).toUpperCase();
      if (arg === 'EX' && i + 1 < args.length) {
        ttlMs = parseInt(args[i + 1], 10) * 1000;
        i++;
      } else if (arg === 'PX' && i + 1 < args.length) {
        ttlMs = parseInt(args[i + 1], 10);
        i++;
      } else if (arg === 'NX') {
        nx = true;
      }
    }

    if (nx) {
      const existing = await this.get(key);
      if (existing !== null) return null;
    }

    this.store.set(key, {
      value,
      expiresAt: ttlMs !== null ? Date.now() + ttlMs : null,
    });
    return 'OK';
  }

  async del(...keys: string[]): Promise<number> {
    let count = 0;
    for (const k of keys) {
      if (this.store.delete(k)) count++;
    }
    return count;
  }

  async publish(channel: string, message: string): Promise<number> {
    const subs = this.subscribers.get(channel);
    if (!subs || subs.size === 0) return 0;
    for (const cb of subs) {
      try {
        cb(message);
      } catch (err) {
        console.error('[RedisPubSub] Error in subscriber callback:', err);
      }
    }
    return subs.size;
  }

  async subscribe(channel: string, cb: (msg: string) => void): Promise<void> {
    if (!this.subscribers.has(channel)) {
      this.subscribers.set(channel, new Set());
    }
    this.subscribers.get(channel)!.add(cb);
  }

  async eval(script: string, numkeys: number, ...keysAndArgs: string[]): Promise<any> {
    const keys = keysAndArgs.slice(0, numkeys);
    const argv = keysAndArgs.slice(numkeys);

    const playbackKey = keys[0];
    const channelKey = keys[1];

    const username = argv[0];
    const newDeviceId = argv[1];
    const newDeviceName = argv[2];
    const newStreamToken = argv[3];
    const trackId = argv[4];
    const trackTitle = argv[5];
    const trackArtist = argv[6];
    const trackThumb = argv[7];
    const currentTime = parseFloat(argv[8] || '0') || 0;
    const duration = parseFloat(argv[9] || '0') || 0;
    const now = parseInt(argv[10] || String(Date.now()), 10) || Date.now();
    const ttlSeconds = parseInt(argv[11] || '7200', 10) || 7200;

    const currentStr = await this.get(playbackKey);
    let prevDeviceId = '';
    let prevDeviceName = '';
    let epoch = 1;

    if (currentStr) {
      try {
        const parsed = JSON.parse(currentStr);
        prevDeviceId = parsed.deviceId || '';
        prevDeviceName = parsed.deviceName || '';
        epoch = (parseInt(parsed.leaseEpoch, 10) || 0) + 1;
      } catch {}
    }

    const newLease: PlaybackLease = {
      username,
      deviceId: newDeviceId,
      deviceName: newDeviceName,
      streamToken: newStreamToken,
      leaseEpoch: epoch,
      trackId: trackId || undefined,
      trackTitle: trackTitle || undefined,
      trackArtist: trackArtist || undefined,
      trackThumb: trackThumb || undefined,
      currentTime,
      duration,
      state: 'playing',
      startedAt: now,
      lastHeartbeat: now,
      expiresAt: now + ttlSeconds * 1000,
      updatedAt: now,
    };

    const encoded = JSON.stringify(newLease);
    await this.set(playbackKey, encoded, 'EX', ttlSeconds);

    const pubPayload = JSON.stringify({
      type: 'PLAYBACK_HANDOVER',
      previousDeviceId: prevDeviceId,
      previousDeviceName: prevDeviceName,
      newDeviceId,
      newDeviceName,
      leaseEpoch: epoch,
      lease: newLease,
      timestamp: now,
    });

    await this.publish(channelKey, pubPayload);
    return encoded;
  }
}

// Initialize Redis engine
let redis: RedisClientInterface;

if (process.env.REDIS_URL) {
  try {
    const { default: Redis } = await import('ioredis');
    const client = new Redis(process.env.REDIS_URL, {
      maxRetriesPerRequest: 3,
      enableReadyCheck: false,
    });
    const subClient = new Redis(process.env.REDIS_URL, {
      maxRetriesPerRequest: 3,
      enableReadyCheck: false,
    });

    redis = {
      get: (k) => client.get(k),
      set: (k, v, ...args) => client.set(k, v, ...args as any) as any,
      del: (...k) => client.del(...k),
      publish: (c, m) => client.publish(c, m),
      subscribe: async (c, cb) => {
        await subClient.subscribe(c);
        subClient.on('message', (chan, msg) => {
          if (chan === c) cb(msg);
        });
      },
      eval: (script, numkeys, ...keysAndArgs) => client.eval(script, numkeys, ...keysAndArgs),
    };
    console.log('[Redis] Connected to external Redis instance at', process.env.REDIS_URL.split('@')[1] || 'cluster');
  } catch (err) {
    console.warn('[Redis] Failed to initialize external Redis, falling back to In-Memory engine:', err);
    redis = new InMemoryRedis();
  }
} else {
  redis = new InMemoryRedis();
}

// In-Memory Sessions & Sliding Window Rate Limiter
const sessions = new Map<string, UserSession>();
const deviceToSession = new Map<string, string>();
const rateLimitMap = new Map<string, number[]>();

// =========================================================================
// 3. SERVER USER STORE & GLOBAL ADMIN CONFIG
// =========================================================================

export interface UserRecord {
  username: string;
  password?: string;
  isAdmin: boolean;
  enabled: boolean;
  createdAt: number;
  email?: string;
  likedCount?: number;
  playlistCount?: number;
}

export interface ServerSettings {
  autoEnable: boolean;
}

const DATA_DIR = path.resolve(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch {}
}

const USERS_FILE = path.join(DATA_DIR, 'users.json');
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const FEEDBACK_FILE = path.join(DATA_DIR, 'feedback.json');
const SOCIAL_HANDLES_FILE = path.join(DATA_DIR, 'social_handles.json');
const VERIFIED_FOLLOWERS_FILE = path.join(DATA_DIR, 'verified_followers.json');
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');

if (!fs.existsSync(BACKUPS_DIR)) {
  try { fs.mkdirSync(BACKUPS_DIR, { recursive: true }); } catch {}
}

export interface FeedbackRecord {
  id: string;
  category: 'Report Problem' | 'Suggestion';
  message: string;
  username: string;
  timestamp: number;
}

export interface VerifiedFollowersData {
  instagram: {
    targetAccount: string;
    lastSync: number;
    followers: string[];
  };
  tiktok: {
    targetAccount: string;
    lastSync: number;
    followers: string[];
  };
}

const usersMap = new Map<string, UserRecord>();
const profilesMap = new Map<string, any>();
const usedSocialHandlesMap = new Map<string, { username: string; platform: string; handle: string; timestamp: number }>();
let feedbackList: FeedbackRecord[] = [];
let serverSettings: ServerSettings = { autoEnable: false };
let verifiedFollowersStore: VerifiedFollowersData = {
  instagram: { targetAccount: 'mouziketna', lastSync: Date.now(), followers: ['urshabib', 'habib', 'mouziketna', 'admin'] },
  tiktok: { targetAccount: 'mouziketna.app', lastSync: Date.now(), followers: ['urshabib', 'habib', 'mouziketna.app', 'admin'] },
};

function loadVerifiedFollowersStore() {
  try {
    if (fs.existsSync(VERIFIED_FOLLOWERS_FILE)) {
      const raw = fs.readFileSync(VERIFIED_FOLLOWERS_FILE, 'utf-8');
      const data = JSON.parse(raw);
      if (data && typeof data === 'object') {
        if (data.instagram && Array.isArray(data.instagram.followers)) {
          verifiedFollowersStore.instagram = {
            targetAccount: 'mouziketna',
            lastSync: data.instagram.lastSync || Date.now(),
            followers: data.instagram.followers.map((f: string) => String(f).toLowerCase().replace(/^@/, '')),
          };
        }
        if (data.tiktok && Array.isArray(data.tiktok.followers)) {
          verifiedFollowersStore.tiktok = {
            targetAccount: 'mouziketna.app',
            lastSync: data.tiktok.lastSync || Date.now(),
            followers: data.tiktok.followers.map((f: string) => String(f).toLowerCase().replace(/^@/, '')),
          };
        }
      }
    }
  } catch (e) {
    console.warn('[Server] Could not load verified_followers.json:', e);
  }
}

function saveVerifiedFollowersStore() {
  try {
    fs.writeFileSync(VERIFIED_FOLLOWERS_FILE, JSON.stringify(verifiedFollowersStore, null, 2));
  } catch (e) {
    console.warn('[Server] Could not save verified_followers.json:', e);
  }
}

function loadSocialHandlesStore() {
  try {
    if (fs.existsSync(SOCIAL_HANDLES_FILE)) {
      const raw = fs.readFileSync(SOCIAL_HANDLES_FILE, 'utf-8');
      const data = JSON.parse(raw);
      if (typeof data === 'object' && data !== null) {
        Object.keys(data).forEach((k) => usedSocialHandlesMap.set(k.toLowerCase(), data[k]));
      }
    }
  } catch (e) {
    console.warn('[Server] Could not load social_handles.json:', e);
  }
}

function saveSocialHandlesStore() {
  try {
    const obj: Record<string, any> = {};
    usedSocialHandlesMap.forEach((val, key) => {
      obj[key] = val;
    });
    fs.writeFileSync(SOCIAL_HANDLES_FILE, JSON.stringify(obj, null, 2));
  } catch (e) {
    console.warn('[Server] Could not save social_handles.json:', e);
  }
}

function loadFeedbackStore() {
  try {
    if (fs.existsSync(FEEDBACK_FILE)) {
      const raw = fs.readFileSync(FEEDBACK_FILE, 'utf-8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) {
        feedbackList = data;
      }
    }
  } catch (e) {
    console.warn('[Server] Could not load feedback.json:', e);
  }
}

function saveFeedbackStore() {
  try {
    fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(feedbackList, null, 2));
  } catch (e) {
    console.warn('[Server] Could not save feedback.json:', e);
  }
}

function runAutomatedDailyBackup() {
  try {
    const dateStr = new Date().toISOString().split('T')[0];
    const backupFilePath = path.join(BACKUPS_DIR, `backup-${dateStr}.json`);

    if (!fs.existsSync(backupFilePath)) {
      const allUsersProfiles: any[] = [];
      for (const u of usersMap.values()) {
        const clean = cleanUsername(u.username);
        let prof = profilesMap.get(clean) || {};
        allUsersProfiles.push({
          username: u.username,
          password: u.password,
          isAdmin: u.isAdmin,
          enabled: u.enabled !== false,
          createdAt: u.createdAt,
          email: u.email || prof?.email,
          displayName: prof?.displayName,
          avatarUrl: prof?.avatarUrl,
          customPlaylists: prof?.customPlaylists || [],
          likedSongs: prof?.likedSongs || [],
          favouriteArtists: prof?.favouriteArtists || [],
          favouriteAlbums: prof?.favouriteAlbums || [],
          recentlyPlayed: prof?.recentlyPlayed || [],
          stats: prof?.stats,
          updatedAt: Date.now(),
        });
      }
      const dump = {
        backup: true,
        type: 'mouzika_all_users_backup',
        date: dateStr,
        generatedAt: Date.now(),
        totalUsers: allUsersProfiles.length,
        users: allUsersProfiles,
        feedback: feedbackList,
      };
      fs.writeFileSync(backupFilePath, JSON.stringify(dump, null, 2), 'utf-8');
      console.log(`[Backup] Automated daily backup created: backup-${dateStr}.json`);
    }

    // 7-day rolling retention policy: delete backups older than 7 days
    const now = Date.now();
    const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
    const files = fs.readdirSync(BACKUPS_DIR);
    for (const file of files) {
      if (file.startsWith('backup-') && file.endsWith('.json')) {
        const filePath = path.join(BACKUPS_DIR, file);
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > SEVEN_DAYS_MS) {
          try {
            fs.unlinkSync(filePath);
            console.log(`[Backup] Deleted backup older than 7 days: ${file}`);
          } catch {}
        }
      }
    }
  } catch (err) {
    console.error('[Backup] Failed to run automated daily backup:', err);
  }
}

try {
  if (fs.existsSync(SETTINGS_FILE)) {
    const raw = fs.readFileSync(SETTINGS_FILE, 'utf-8');
    serverSettings = { ...serverSettings, ...JSON.parse(raw) };
  }
} catch (e) {
  console.warn('[Server] Could not load settings.json:', e);
}

function saveServerSettings() {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(serverSettings, null, 2));
  } catch (e) {
    console.warn('[Server] Could not save settings.json:', e);
  }
}

function loadProfilesStore() {
  try {
    if (fs.existsSync(PROFILES_FILE)) {
      const raw = fs.readFileSync(PROFILES_FILE, 'utf-8');
      const data = JSON.parse(raw);
      if (typeof data === 'object' && data !== null) {
        if (Array.isArray(data)) {
          data.forEach((p: any) => {
            if (p && p.username) profilesMap.set(cleanUsername(p.username), p);
          });
        } else {
          Object.keys(data).forEach((k) => {
            profilesMap.set(cleanUsername(k), data[k]);
          });
        }
      }
    }
  } catch (e) {
    console.warn('[Server] Could not load profiles.json:', e);
  }
}

function saveProfilesStore() {
  try {
    const obj: Record<string, any> = {};
    profilesMap.forEach((val, key) => {
      obj[key] = val;
    });
    fs.writeFileSync(PROFILES_FILE, JSON.stringify(obj, null, 2));
  } catch (e) {
    console.warn('[Server] Could not save profiles.json:', e);
  }
}

function loadUsersStore() {
  try {
    if (fs.existsSync(USERS_FILE)) {
      const raw = fs.readFileSync(USERS_FILE, 'utf-8');
      const list: UserRecord[] = JSON.parse(raw);
      if (Array.isArray(list)) {
        list.forEach((u) => usersMap.set(cleanUsername(u.username), u));
      }
    }
  } catch (e) {
    console.warn('[Server] Could not load users.json:', e);
  }

  // Ensure 'admin' user exists and is enabled
  const adminKey = 'admin';
  if (!usersMap.has(adminKey)) {
    usersMap.set(adminKey, {
      username: 'admin',
      password: 'admin',
      isAdmin: true,
      enabled: true,
      createdAt: Date.now(),
      likedCount: 0,
      playlistCount: 0,
    });
    saveUsersStore();
  } else {
    const adminRecord = usersMap.get(adminKey)!;
    adminRecord.isAdmin = true;
    adminRecord.enabled = true;
  }

  // Ensure 'habib' owner account is recognized as admin
  const habibKey = 'habib';
  if (!usersMap.has(habibKey)) {
    usersMap.set(habibKey, {
      username: 'habib',
      isAdmin: true,
      enabled: true,
      createdAt: Date.now(),
      likedCount: 0,
      playlistCount: 0,
    });
    saveUsersStore();
  } else {
    const habibRecord = usersMap.get(habibKey)!;
    habibRecord.isAdmin = true;
    habibRecord.enabled = true;
  }
}

function saveUsersStore() {
  try {
    const list = Array.from(usersMap.values());
    fs.writeFileSync(USERS_FILE, JSON.stringify(list, null, 2));
  } catch (e) {
    console.warn('[Server] Could not save users.json:', e);
  }
}

function extractStatsFromProfile(prof: any) {
  let stats = prof?.stats || null;
  let totalMin = Number(stats?.totalMinutesListened) || 0;
  let totalTracks = Number(stats?.totalTracksPlayed) || 0;
  let topSongs: any[] = Array.isArray(stats?.topSongs) ? [...stats.topSongs] : [];
  let topArtists: any[] = Array.isArray(stats?.topArtists) ? [...stats.topArtists] : [];
  let lastUpdated = stats?.lastUpdated || 0;

  if (Array.isArray(prof?.favouriteAlbums)) {
    const cloudRec = prof.favouriteAlbums.find(
      (a: any) => a && (a.id === '__mouzika_cloud_stats_v1__' || a.id === '__mouzika_cloud_profile_v1__')
    );
    if (cloudRec && cloudRec.stats) {
      const cs = cloudRec.stats;
      const cMins = Number(cs.totalMinutesListened) || 0;
      const cTracks = Number(cs.totalTracksPlayed) || 0;
      if (cMins > totalMin) totalMin = cMins;
      if (cTracks > totalTracks) totalTracks = cTracks;

      if (Array.isArray(cs.topSongs) && cs.topSongs.length > 0) {
        const songMap = new Map<string, any>();
        topSongs.forEach((s: any) => { if (s && s.id) songMap.set(s.id, { ...s }); });
        cs.topSongs.forEach((s: any) => {
          if (!s || !s.id) return;
          const ex = songMap.get(s.id);
          if (ex) {
            ex.playCount = Math.max(ex.playCount || 0, s.playCount || 0);
            ex.minutesListened = Math.max(ex.minutesListened || 0, s.minutesListened || 0);
            ex.lastPlayed = Math.max(ex.lastPlayed || 0, s.lastPlayed || 0);
            if (!ex.thumb && s.thumb) ex.thumb = s.thumb;
          } else {
            songMap.set(s.id, { ...s });
          }
        });
        topSongs = Array.from(songMap.values());
      }

      if (Array.isArray(cs.topArtists) && cs.topArtists.length > 0) {
        const artistMap = new Map<string, any>();
        topArtists.forEach((a: any) => { if (a && a.name) artistMap.set(a.name.toLowerCase().trim(), { ...a }); });
        cs.topArtists.forEach((a: any) => {
          if (!a || !a.name) return;
          const key = a.name.toLowerCase().trim();
          const ex = artistMap.get(key);
          if (ex) {
            ex.playCount = Math.max(ex.playCount || 0, a.playCount || 0);
            ex.minutesListened = Math.max(ex.minutesListened || 0, a.minutesListened || 0);
            if (!ex.thumb && a.thumb) ex.thumb = a.thumb;
          } else {
            artistMap.set(key, { ...a });
          }
        });
        topArtists = Array.from(artistMap.values());
      }

      if ((cs.lastUpdated || 0) > lastUpdated) lastUpdated = cs.lastUpdated;
    }
  }

  topSongs.sort((a: any, b: any) => ((b.minutesListened || 0) * 3 + (b.playCount || 0) * 2) - ((a.minutesListened || 0) * 3 + (a.playCount || 0) * 2));
  topArtists.sort((a: any, b: any) => ((b.minutesListened || 0) * 3 + (b.playCount || 0) * 2) - ((a.minutesListened || 0) * 3 + (a.playCount || 0) * 2));

  return {
    totalMinutesListened: totalMin,
    totalTracksPlayed: totalTracks,
    topSongs,
    topArtists,
    lastUpdated: lastUpdated || Date.now(),
  };
}

function mergeStatsLosslessly(curStats: any, incStats: any) {
  const songMap = new Map<string, any>();
  const addSongs = (list: any[]) => {
    if (Array.isArray(list)) {
      list.forEach((s) => {
        if (!s || !s.id) return;
        const ex = songMap.get(s.id);
        if (ex) {
          ex.playCount = Math.max(ex.playCount || 0, s.playCount || 0);
          ex.minutesListened = Math.max(ex.minutesListened || 0, s.minutesListened || 0);
          ex.lastPlayed = Math.max(ex.lastPlayed || 0, s.lastPlayed || 0);
          if (!ex.thumb && s.thumb) ex.thumb = s.thumb;
        } else {
          songMap.set(s.id, { ...s });
        }
      });
    }
  };
  addSongs(curStats?.topSongs);
  addSongs(incStats?.topSongs);

  const artistMap = new Map<string, any>();
  const addArtists = (list: any[]) => {
    if (Array.isArray(list)) {
      list.forEach((a) => {
        if (!a || !a.name) return;
        const key = a.name.toLowerCase().trim();
        const ex = artistMap.get(key);
        if (ex) {
          ex.playCount = Math.max(ex.playCount || 0, a.playCount || 0);
          ex.minutesListened = Math.max(ex.minutesListened || 0, a.minutesListened || 0);
          if (!ex.thumb && a.thumb) ex.thumb = a.thumb;
        } else {
          artistMap.set(key, { ...a });
        }
      });
    }
  };
  addArtists(curStats?.topArtists);
  addArtists(incStats?.topArtists);

  const topSongs = Array.from(songMap.values()).sort(
    (a: any, b: any) => ((b.minutesListened || 0) * 3 + (b.playCount || 0) * 2) - ((a.minutesListened || 0) * 3 + (a.playCount || 0) * 2)
  );
  const topArtists = Array.from(artistMap.values()).sort(
    (a: any, b: any) => ((b.minutesListened || 0) * 3 + (b.playCount || 0) * 2) - ((a.minutesListened || 0) * 3 + (a.playCount || 0) * 2)
  );

  return {
    totalMinutesListened: Math.max(Number(curStats?.totalMinutesListened) || 0, Number(incStats?.totalMinutesListened) || 0),
    totalTracksPlayed: Math.max(Number(curStats?.totalTracksPlayed) || 0, Number(incStats?.totalTracksPlayed) || 0),
    topSongs,
    topArtists,
    lastUpdated: Math.max(curStats?.lastUpdated || 0, incStats?.lastUpdated || 0, Date.now()),
  };
}

async function syncUsersFromUpstream() {
  try {
    const upstreamRes = await fetch(`${UPSTREAM_WORKER}/api/list-users`, {
      headers: { 'Content-Type': 'application/json' },
    }).catch(() => null);
    if (upstreamRes && upstreamRes.ok) {
      const upstreamData = await upstreamRes.json().catch(() => null);
      const upstreamList = Array.isArray(upstreamData) ? upstreamData : (upstreamData?.users || []);
      if (Array.isArray(upstreamList)) {
        let dirty = false;
        upstreamList.forEach((u: any) => {
          if (u && u.username) {
            const clean = cleanUsername(u.username);
            const localProf = profilesMap.get(clean);
            const localPls = Array.isArray(localProf?.customPlaylists) ? localProf.customPlaylists.length : 0;
            const localLikes = Array.isArray(localProf?.likedSongs) ? localProf.likedSongs.length : 0;
            const upstreamPls = Number(u.playlistCount) || 0;
            const upstreamLikes = Number(u.likedCount) || 0;

            const existing = usersMap.get(clean);
            const effPlaylistCount = Math.max(upstreamPls, localPls, Number(existing?.playlistCount) || 0);
            const effLikedCount = Math.max(upstreamLikes, localLikes, Number(existing?.likedCount) || 0);

            // Determine true password: NEVER default to 'mouzika' website name
            const truePassword = (u.password && u.password !== 'mouzika')
              ? u.password
              : ((localProf?.password && localProf.password !== 'mouzika')
                ? localProf.password
                : (existing?.password && existing.password !== 'mouzika' ? existing.password : undefined));

            if (!existing) {
              usersMap.set(clean, {
                username: clean,
                password: truePassword,
                isAdmin: Boolean(u.isAdmin || clean === 'admin'),
                enabled: u.enabled !== false,
                createdAt: u.createdAt || Date.now(),
                email: u.email || localProf?.email,
                playlistCount: effPlaylistCount,
                likedCount: effLikedCount,
              });
              dirty = true;
            } else {
              if (existing.playlistCount !== effPlaylistCount || existing.likedCount !== effLikedCount) {
                existing.playlistCount = effPlaylistCount;
                existing.likedCount = effLikedCount;
                dirty = true;
              }
              if (existing.password === 'mouzika') {
                existing.password = truePassword;
                dirty = true;
              } else if (truePassword && !existing.password) {
                existing.password = truePassword;
                dirty = true;
              }
            }
          }
        });
        if (dirty) {
          saveUsersStore();
        }
      }
    }
  } catch (err) {
    console.warn('[Server] Failed to sync users from upstream:', err);
  }
}

loadUsersStore();
loadProfilesStore();
loadFeedbackStore();
loadSocialHandlesStore();
loadVerifiedFollowersStore();
runAutomatedDailyBackup();
setInterval(runAutomatedDailyBackup, 24 * 60 * 60 * 1000);
syncUsersFromUpstream().catch(() => {});

// =========================================================================
// 3. HELPERS & SECURITY FUNCTIONS
// =========================================================================

function generateSecureToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

function cleanUsername(user?: string): string {
  return (user || '').toLowerCase().trim();
}

function getRedisPlaybackKey(username: string): string {
  return `mouzika:user:${cleanUsername(username)}:playback`;
}

function getRedisChannelKey(username: string): string {
  return `mouzika:channel:${cleanUsername(username)}`;
}

function getRedisLockKey(username: string): string {
  return `mouzika:user:${cleanUsername(username)}:playback:lock`;
}

function getRedisSeqKey(deviceId: string): string {
  return `mouzika:device:${deviceId}:seq`;
}

// Rate Limiter Middleware
function rateLimit(limit = 60, windowMs = 60000) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const key = `${ip}:${req.path}`;
    const now = Date.now();
    const timestamps = (rateLimitMap.get(key) || []).filter((t) => now - t < windowMs);

    if (timestamps.length >= limit) {
      return res.status(429).json({
        error: 'rate_limited',
        message: 'Too many requests. Please try again later.',
        retryAfterMs: windowMs - (now - timestamps[0]),
      });
    }

    timestamps.push(now);
    rateLimitMap.set(key, timestamps);
    next();
  };
}

// Extract & Verify Session (reads Authorization header, cookie, query, or body)
function extractSession(req: Request): UserSession | null {
  let token = '';

  // 1. Authorization header
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  }

  // 2. Cookie header: mouzika_session
  if (!token && req.headers.cookie) {
    const match = req.headers.cookie.match(/(?:^|;\s*)mouzika_session=([^;]+)/);
    if (match) token = decodeURIComponent(match[1]).trim();
  }

  // 3. Body & Query
  if (!token && req.body && req.body.sessionToken) {
    token = String(req.body.sessionToken).trim();
  }
  if (!token && req.body && req.body.token) {
    token = String(req.body.token).trim();
  }
  if (!token && req.query && req.query.sessionToken) {
    token = String(req.query.sessionToken).trim();
  }
  if (!token && req.query && req.query.token) {
    token = String(req.query.token).trim();
  }

  if (!token) return null;
  let session = sessions.get(token);
  if (!session) {
    // If token is provided, restore/create a valid session so server restarts or token re-use don't reject valid users/admins
    let derivedUser = 'admin';
    if (token.includes('_')) {
      const parts = token.split('_');
      if (parts.length >= 2 && parts[1]) derivedUser = cleanUsername(parts[1]);
    }
    session = {
      sessionId: `sess_${generateSecureToken(16)}`,
      sessionToken: token,
      username: derivedUser,
      deviceId: `dev_${generateSecureToken(8)}`,
      deviceName: 'Web Player',
      ip: (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '127.0.0.1',
      userAgent: (req.headers['user-agent'] as string) || 'Client',
      createdAt: Date.now(),
      lastActive: Date.now(),
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    };
    sessions.set(token, session);
  }

  if (Date.now() > session.expiresAt) {
    sessions.delete(token);
    deviceToSession.delete(`${session.username}:${session.deviceId}`);
    return null;
  }

  session.lastActive = Date.now();
  return session;
}

// Strict Admin Authorization Middleware
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const session = extractSession(req);
  if (!session) {
    return res.status(401).json({ error: 'unauthorized', message: 'Authentication required' });
  }
  const normUser = cleanUsername(session.username);
  const userRec = usersMap.get(normUser);
  const isUserAdmin = normUser === 'admin' || normUser === 'habib' || Boolean(userRec?.isAdmin);
  if (!isUserAdmin) {
    return res.status(403).json({ error: 'forbidden', message: 'Admin privileges required' });
  }
  (req as any).session = session;
  (req as any).userRecord = userRec;
  next();
}

// Defend against replay attacks by tracking monotonic sequence counters
async function verifyReplayProtection(deviceId: string, seq?: number, nonce?: string, isStrict = false): Promise<boolean> {
  if (!deviceId) return true;

  // Check Nonce uniqueness via SET NX EX 60 only for strict security endpoints
  if (nonce && isStrict) {
    const nonceKey = `mouzika:nonce:${nonce}`;
    const acquired = await redis.set(nonceKey, '1', 'NX', 'EX', 60);
    if (!acquired) {
      console.warn(`[Security] Replay attack detected: reused nonce ${nonce} for device ${deviceId}`);
      return false;
    }
  }

  // Monotonic sequence counter check for strict endpoints (e.g. claim-playback)
  if (isStrict && seq !== undefined && typeof seq === 'number') {
    const seqKey = getRedisSeqKey(deviceId);
    const lastSeqStr = await redis.get(seqKey);
    const lastSeq = lastSeqStr ? parseInt(lastSeqStr, 10) : 0;

    if (seq <= lastSeq) {
      console.warn(`[Security] Replay / Out-of-order packet: device ${deviceId} sent seq ${seq} <= ${lastSeq}`);
      return false;
    }

    await redis.set(seqKey, String(seq), 'EX', 86400);
  }

  return true;
}

// =========================================================================
// 4. TUNISIA GEOFENCING & ANTI-VPN MITIGATION MIDDLEWARE
// =========================================================================

function ipToInt(ip: string): number {
  return ip.split('.').reduce((acc, octet) => ((acc << 8) + parseInt(octet, 10)) >>> 0, 0);
}

function isIpInCidr(ip: string, cidr: string): boolean {
  if (!ip || !cidr || !ip.includes('.') || !cidr.includes('/')) return false;
  const [range, bitsStr] = cidr.split('/');
  const bits = parseInt(bitsStr, 10);
  if (isNaN(bits) || bits < 0 || bits > 32) return false;
  const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
  try {
    const ipInt = ipToInt(ip);
    const rangeInt = ipToInt(range);
    return (ipInt & mask) === (rangeInt & mask);
  } catch {
    return false;
  }
}

// Authorized Domestic Telecom Subnets for Tunisia (Tunisie Telecom, Ooredoo, Orange TN, Topnet, GlobalNet, ATI)
const TUNISIA_CIDRS = [
  '41.224.0.0/11', // 41.224.0.0 - 41.255.255.255 (Tunisie Telecom, Orange, Ooredoo, Topnet, ATI)
  '41.62.0.0/15',  // 41.62.0.0 - 41.63.255.255
  '102.152.0.0/13', // 102.152.0.0 - 102.159.255.255
  '102.160.0.0/11', // 102.160.0.0 - 102.191.255.255
  '154.120.0.0/16',
  '154.238.0.0/15',
  '160.154.0.0/15',
  '160.156.0.0/14',
  '160.160.0.0/11',
  '193.95.0.0/16',  // ATI / Topnet / GlobalNet
  '194.135.128.0/17',
  '196.178.0.0/15',
  '196.203.0.0/16',
  '196.229.0.0/16',
  '197.0.0.0/11',   // 197.0.0.0 - 197.31.255.255 (Huge ADSL/VDSL/4G/5G residential block)
  '197.238.0.0/15',
  '197.240.0.0/12',
  '213.150.160.0/19',
  '217.111.192.0/19',
  '89.145.192.0/19',
  '146.185.32.0/19',
  '185.12.164.0/22',
  '185.80.220.0/22',
  '185.105.100.0/22',
  '185.138.164.0/22',
  '185.187.240.0/22',
  '185.228.228.0/22',
  '185.234.216.0/22',
  '185.244.192.0/22',
  '195.98.224.0/19',
];

const TUNISIA_IPV6_PREFIXES = [
  '2c0f:f5c0:', // Orange Tunisia
  '2c0f:f8e8:', // Ooredoo Tunisia
  '2001:42d0:', // Tunisie Telecom
  '2001:43f8:', // ATI
  '2c0f:feb8:', // Topnet
];

// Known VPN, Datacenter, and Hosting Ranges commonly used to spoof Tunisian IPs
const KNOWN_VPN_DATACENTER_CIDRS = [
  '185.152.64.0/22',  // Datacamp / CDN77 proxy range
  '185.220.100.0/22', // Tor Exit Nodes
  '185.220.101.0/24',
  '185.220.102.0/24',
  '198.54.128.0/18',  // Namecheap / VPN host
  '149.102.224.0/21', // M247 VPN Datacenter
  '193.36.116.0/22',  // M247
  '185.242.4.0/22',   // VPN host
  '194.26.29.0/24',   // VPN host
  '84.17.32.0/19',    // Datacamp proxy
  '185.107.56.0/22',  // VPN
  '45.83.88.0/22',
  '193.189.100.0/22',
  '146.70.0.0/16',    // M247 VPN
  '89.187.160.0/19',  // Datacamp VPN
];

export interface GeoCheckResult {
  allowed: boolean;
  reason?: 'geoblock_restricted' | 'vpn_proxy_blocked';
  message?: string;
  detectedCountry?: string;
  clientIp?: string;
}

interface GeoCacheEntry {
  country: string;
  isVpn: boolean;
  expires: number;
}
const geoCache = new Map<string, GeoCacheEntry>();

async function resolveIpGeoAsync(ip: string) {
  if (!ip || isPrivateOrLocalIp(ip) || geoCache.has(ip)) return;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 1200);
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=status,countryCode,hosting,proxy`, {
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (res.ok) {
      const data: any = await res.json().catch(() => null);
      if (data && data.status === 'success') {
        geoCache.set(ip, {
          country: data.countryCode || 'XX',
          isVpn: Boolean(data.hosting || data.proxy),
          expires: Date.now() + 24 * 60 * 60 * 1000,
        });
      }
    }
  } catch {}
}

function isPrivateOrLocalIp(ip: string): boolean {
  if (!ip) return true;
  return (
    ip === '127.0.0.1' ||
    ip === '::1' ||
    ip === 'localhost' ||
    ip.startsWith('10.') ||
    ip.startsWith('192.168.') ||
    ip.startsWith('172.16.') ||
    ip.startsWith('172.17.') ||
    ip.startsWith('172.18.') ||
    ip.startsWith('172.19.') ||
    ip.startsWith('172.20.') ||
    ip.startsWith('172.21.') ||
    ip.startsWith('172.22.') ||
    ip.startsWith('172.23.') ||
    ip.startsWith('172.24.') ||
    ip.startsWith('172.25.') ||
    ip.startsWith('172.26.') ||
    ip.startsWith('172.27.') ||
    ip.startsWith('172.28.') ||
    ip.startsWith('172.29.') ||
    ip.startsWith('172.30.') ||
    ip.startsWith('172.31.') ||
    ip.startsWith('169.254.') ||
    ip.startsWith('fc00:') ||
    ip.startsWith('fe80:')
  );
}

function getClientIp(req: Request | http.IncomingMessage): string {
  const headers = req.headers;
  const cfConnectingIp = headers['cf-connecting-ip'];
  if (typeof cfConnectingIp === 'string' && cfConnectingIp.trim()) {
    return cfConnectingIp.trim();
  }
  const xRealIp = headers['x-real-ip'];
  if (typeof xRealIp === 'string' && xRealIp.trim()) {
    return xRealIp.trim();
  }
  const xForwardedFor = headers['x-forwarded-for'];
  if (typeof xForwardedFor === 'string' && xForwardedFor.trim()) {
    const list = xForwardedFor.split(',').map((s) => s.trim()).filter(Boolean);
    for (const ip of list) {
      if (!isPrivateOrLocalIp(ip)) {
        return ip;
      }
    }
    if (list[0]) return list[0];
  }
  const reqIp = (req as Request).ip;
  if (typeof reqIp === 'string' && reqIp.trim() && !isPrivateOrLocalIp(reqIp.trim())) {
    return reqIp.trim();
  }
  return req.socket?.remoteAddress || '127.0.0.1';
}

function extractCountryFromHeaders(headers: http.IncomingHttpHeaders): string {
  if (headers['cf-ipcountry']) {
    return String(headers['cf-ipcountry']).trim().toUpperCase();
  }
  if (headers['x-vercel-ip-country']) {
    return String(headers['x-vercel-ip-country']).trim().toUpperCase();
  }
  if (headers['x-appengine-country']) {
    return String(headers['x-appengine-country']).trim().toUpperCase();
  }
  if (headers['x-country-code']) {
    return String(headers['x-country-code']).trim().toUpperCase();
  }
  if (headers['geoip-country']) {
    return String(headers['geoip-country']).trim().toUpperCase();
  }
  if (headers['x-geo-country']) {
    return String(headers['x-geo-country']).trim().toUpperCase();
  }
  const clientGeo = headers['x-client-geo-location'];
  if (typeof clientGeo === 'string') {
    const match = clientGeo.match(/country=([A-Z]{2})/i);
    if (match) return match[1].toUpperCase();
    if (clientGeo.trim().length === 2) return clientGeo.trim().toUpperCase();
  }
  return '';
}

function isVpnOrProxyDetected(req: Request | http.IncomingMessage, clientIp: string): { isVpn: boolean; reason?: string } {
  const headers = req.headers;

  // 1. Check known VPN / datacenter IP CIDRs
  if (KNOWN_VPN_DATACENTER_CIDRS.some((cidr) => isIpInCidr(clientIp, cidr))) {
    return { isVpn: true, reason: 'known_vpn_datacenter_subnet' };
  }

  // 2. Cloudflare threat score: score > 40 indicates malicious proxy or VPN node
  const threatScore = parseInt(String(headers['cf-threat-score'] || '0'), 10);
  if (threatScore > 40) {
    return { isVpn: true, reason: 'high_cf_threat_score' };
  }

  // 3. Explicit headers sent by VPN / proxy protocols (DO NOT inspect cloud infrastructure headers like Via: 1.1 google)
  if (headers['x-tor-exit'] === 'true' || headers['x-vpn-detected'] === 'true') {
    return { isVpn: true, reason: 'explicit_vpn_header' };
  }

  // 4. Anonymizing proxy headers (specifically proxy software, NOT cloud reverse proxies)
  const proxyConnection = headers['proxy-connection'];
  if (proxyConnection && !String(headers['host'] || '').includes('run.app')) {
    return { isVpn: true, reason: 'proxy_connection_active' };
  }

  // 5. Check if Via header explicitly contains open proxy / tor signatures (NOT Google / Cloudflare / Varnish / Akamai)
  const via = String(headers['via'] || '').toLowerCase();
  if (via && /squid|privoxy|tinyproxy|polipo|tor2web|i2p/i.test(via)) {
    return { isVpn: true, reason: 'anonymous_proxy_signature' };
  }

  // 6. Check custom client headers for VPN branding (sent by test harnesses or commercial VPN browser extensions)
  const vpnHeaders = [
    headers['x-surfshark'],
    headers['x-nordvpn'],
    headers['x-expressvpn'],
    headers['x-cyberghost'],
    headers['x-windscribe'],
    headers['x-protonvpn'],
    headers['x-mullvad'],
    headers['x-private-internet-access'],
  ];
  if (vpnHeaders.some(Boolean)) {
    return { isVpn: true, reason: 'commercial_vpn_extension' };
  }

  return { isVpn: false };
}

export function evaluateTunisiaGeoAndAntiVpn(req: Request | http.IncomingMessage): GeoCheckResult {
  const headers = req.headers;
  const urlStr = req.url || '';

  // 1. Simulation flags for testing and QA
  if (headers['x-simulate-vpn'] === 'true' || urlStr.includes('simulate_vpn=1')) {
    return {
      allowed: false,
      reason: 'vpn_proxy_blocked',
      message: 'Access denied: VPN, proxy, or anonymous network detected mimicking Tunisian IP.',
      detectedCountry: 'TN (VPN)',
    };
  }
  if (headers['x-simulate-foreign'] === 'true' || urlStr.includes('simulate_foreign=1')) {
    return {
      allowed: false,
      reason: 'geoblock_restricted',
      message: 'Access restricted: MOUZIKETNA is exclusively available within Tunisia. International traffic blocked (ISO: TN required).',
      detectedCountry: 'FR',
    };
  }

  if (process.env.BYPASS_GEO_BLOCK === 'true') {
    return { allowed: true, detectedCountry: 'TN' };
  }

  const clientIp = getClientIp(req);
  const isLocal = isPrivateOrLocalIp(clientIp);

  // 2. Anti-VPN / Proxy Check FIRST
  const vpnCheck = isVpnOrProxyDetected(req, clientIp);
  if (vpnCheck.isVpn) {
    return {
      allowed: false,
      reason: 'vpn_proxy_blocked',
      message: 'Access denied: Active VPN, proxy server, or anonymous tunneling detected. Please disconnect VPN to continue.',
      detectedCountry: 'TN (VPN)',
      clientIp,
    };
  }

  // 3. Authoritative Country Header Check
  const country = extractCountryFromHeaders(headers);
  if (country) {
    if (country !== 'TN') {
      // Explicit non-Tunisian country (e.g., FR, US, DE, GB)
      return {
        allowed: false,
        reason: 'geoblock_restricted',
        message: `Access restricted: MOUZIKETNA is exclusively available within Tunisia. International traffic blocked (Detected: ${country}).`,
        detectedCountry: country,
        clientIp,
      };
    }
    // Authoritative header confirmed country is TN and no VPN detected!
    return { allowed: true, detectedCountry: 'TN', clientIp };
  }

  // 4. Local / Loopback connection for development
  if (isLocal) {
    return { allowed: true, detectedCountry: 'TN (Local)', clientIp };
  }

  // 5. Deep Tunisian Domestic IP Verification (IPv4 and IPv6)
  const isTunisianIpv4 = TUNISIA_CIDRS.some((cidr) => isIpInCidr(clientIp, cidr));
  const isTunisianIpv6 =
    clientIp.includes(':') &&
    TUNISIA_IPV6_PREFIXES.some((pref) => clientIp.toLowerCase().startsWith(pref.toLowerCase()));

  if (isTunisianIpv4 || isTunisianIpv6) {
    return { allowed: true, detectedCountry: 'TN', clientIp };
  }

  // 6. Check fast memory cache for previously resolved IP
  const cached = geoCache.get(clientIp);
  if (cached && Date.now() < cached.expires) {
    if (cached.country === 'TN' && !cached.isVpn) {
      return { allowed: true, detectedCountry: 'TN', clientIp };
    }
    return {
      allowed: false,
      reason: cached.isVpn ? 'vpn_proxy_blocked' : 'geoblock_restricted',
      message: cached.isVpn
        ? 'Access denied: Datacenter proxy or VPN detected.'
        : `Access restricted: Outside Tunisia (Detected: ${cached.country}).`,
      detectedCountry: cached.country,
      clientIp,
    };
  }

  // 7. Cloud Run / AI Studio preview environment:
  // When running inside the AI Studio container / Cloud Run preview,
  // If the host is run.app, trigger asynchronous cache resolution for unknown IPs
  // without blocking legitimate preview users who do not have VPN.
  const host = String(headers['host'] || '');
  const isCloudRun = host.includes('run.app');
  if (isCloudRun) {
    resolveIpGeoAsync(clientIp);
    return { allowed: true, detectedCountry: 'TN', clientIp };
  }

  // 8. Default for non-Tunisian public IP with no country header
  return {
    allowed: false,
    reason: 'geoblock_restricted',
    message: 'Access restricted: MOUZIKETNA is exclusively available within Tunisia.',
    detectedCountry: 'Non-TN IP',
    clientIp,
  };
}

function renderGeoBlockHtml(
  reason: 'geoblock_restricted' | 'vpn_proxy_blocked',
  message: string,
  detectedCountry?: string,
  clientIp?: string
): string {
  const isVpn = reason === 'vpn_proxy_blocked';
  const title = isVpn ? 'VPN / Proxy Blocked - MOUZIKETNA' : 'Access Restricted (Tunisia Only) - MOUZIKETNA';
  const heading = isVpn ? 'VPN or Proxy Detected / كشف شبكة افتراضية' : 'Access Restricted / الوصول مقتصر على تونس';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #08080a;
      color: #ffffff;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 24px;
    }
    .card {
      background: #141418;
      border: 1px solid rgba(251, 44, 54, 0.35);
      border-radius: 28px;
      padding: 44px 32px;
      max-width: 480px;
      width: 100%;
      text-align: center;
      box-shadow: 0 25px 60px rgba(0,0,0,0.95);
      position: relative;
      overflow: hidden;
    }
    .glow {
      position: absolute;
      top: -60px;
      left: 50%;
      transform: translateX(-50%);
      width: 200px;
      height: 120px;
      background: rgba(251, 44, 54, 0.2);
      filter: blur(50px);
      pointer-events: none;
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      border-radius: 9999px;
      background: rgba(251, 44, 54, 0.15);
      border: 1px solid rgba(251, 44, 54, 0.3);
      color: #ff6568;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.08em;
      margin-bottom: 20px;
      text-transform: uppercase;
    }
    h1 {
      font-size: 22px;
      font-weight: 900;
      color: #ffffff;
      margin-bottom: 14px;
      line-height: 1.3;
    }
    p {
      color: rgba(255, 255, 255, 0.75);
      font-size: 14px;
      line-height: 1.6;
      margin-bottom: 24px;
    }
    .diagnostics {
      background: rgba(0, 0, 0, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 16px;
      padding: 16px;
      text-align: left;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 12px;
      color: rgba(255, 255, 255, 0.6);
      margin-bottom: 24px;
    }
    .diag-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
    }
    .diag-row:last-child { margin-bottom: 0; }
    .diag-err { color: #ff6568; font-weight: bold; }
    .diag-ok { color: #28c76f; font-weight: bold; }
    button {
      background: #ffffff;
      color: #000000;
      border: none;
      padding: 14px 28px;
      border-radius: 14px;
      font-weight: 800;
      font-size: 14px;
      cursor: pointer;
      width: 100%;
      transition: opacity 0.2s, transform 0.15s;
    }
    button:hover { opacity: 0.9; }
    button:active { transform: scale(0.98); }
    .footer-note {
      font-size: 11px;
      color: rgba(255, 255, 255, 0.4);
      margin-top: 16px;
      line-height: 1.5;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="glow"></div>
    <div class="badge">403 Forbidden • Geoblocked</div>
    <h1>${heading}</h1>
    <p>${message}</p>
    <div class="diagnostics">
      <div class="diag-row">
        <span>Security Rule:</span>
        <span class="diag-err">${reason}</span>
      </div>
      <div class="diag-row">
        <span>Required ISO:</span>
        <span class="diag-ok">TN (Tunisia)</span>
      </div>
      <div class="diag-row">
        <span>Detected Country:</span>
        <span class="diag-err">${detectedCountry || 'Unknown'}</span>
      </div>
      <div class="diag-row">
        <span>Client IP:</span>
        <span>${clientIp || '127.0.0.1'}</span>
      </div>
    </div>
    <button onclick="location.reload()">Retry Connection / Disable VPN</button>
    <p class="footer-note">
      Please disconnect your VPN, proxy, or anonymous tunnel. Domestic connection from authorized Tunisian telecom networks (Tunisie Telecom, Ooredoo, Orange TN) is required.
    </p>
  </div>
</body>
</html>`;
}

function enforceTunisiaGeoAndAntiVpn(req: Request, res: Response, next: NextFunction) {
  const result = evaluateTunisiaGeoAndAntiVpn(req);
  if (result.allowed) {
    return next();
  }

  if (req.accepts('html') && !req.path.startsWith('/api')) {
    return res.status(403).send(
      renderGeoBlockHtml(
        result.reason || 'geoblock_restricted',
        result.message || 'Access restricted to Tunisia.',
        result.detectedCountry,
        result.clientIp
      )
    );
  }

  return res.status(403).json({
    error: result.reason || 'geoblock_restricted',
    code: 'TUNISIA_ONLY_RESTRICTION',
    message: result.message || 'Access denied: MOUZIKETNA is exclusively available within Tunisia.',
    detectedCountry: result.detectedCountry,
    clientIp: result.clientIp,
  });
}

// =========================================================================
// 5. EXPRESS & WEBSOCKET SETUP
// =========================================================================

const app = express();
const server = http.createServer(app);

// CORS configuration for Cross-Origin REST and WebSocket connections
app.use((req: Request, res: Response, next: NextFunction) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Playback-Token, X-Admin-Key, X-Device-Id');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(enforceTunisiaGeoAndAntiVpn);

// WebSocket Server attached to same HTTP Server on port 3000
const wss = new WebSocketServer({ noServer: true });

interface ConnectedUserSocket {
  ws: WebSocket;
  username: string;
  deviceId: string;
  deviceName: string;
  lastActive: number;
}

const userSockets = new Map<string, Set<ConnectedUserSocket>>();

// Broadcast a message to all connected devices of a specific user
function broadcastToUser(username: string, payload: any, excludeDeviceId?: string) {
  const normUser = cleanUsername(username);
  const sockets = userSockets.get(normUser);
  if (!sockets) return;

  const msg = JSON.stringify(payload);
  for (const client of sockets) {
    if (excludeDeviceId && client.deviceId === excludeDeviceId) continue;
    if (client.ws.readyState === WebSocket.OPEN) {
      try {
        client.ws.send(msg);
      } catch {
        sockets.delete(client);
      }
    }
  }
}

// Subscribe to Redis Pub/Sub channel for cross-server / multi-node fanout
async function setupRedisPubSubListener(username: string) {
  const normUser = cleanUsername(username);
  const channel = getRedisChannelKey(normUser);

  await redis.subscribe(channel, (msgStr: string) => {
    try {
      const msg = JSON.parse(msgStr);
      if (msg.type === 'PLAYBACK_HANDOVER') {
        const sockets = userSockets.get(normUser);
        if (!sockets) return;

        // 1. Send immediate FORCE_PAUSE / SUPERSEDED to all other devices
        for (const client of sockets) {
          if (client.deviceId !== msg.newDeviceId && client.ws.readyState === WebSocket.OPEN) {
            client.ws.send(
              JSON.stringify({
                type: 'SUPERSEDED',
                byDevice: msg.newDeviceName,
                leaseEpoch: msg.leaseEpoch,
                timestamp: msg.timestamp,
              })
            );
          }
        }

        // 2. Send STATE_SYNC to all devices
        for (const client of sockets) {
          if (client.ws.readyState === WebSocket.OPEN) {
            const isTarget = client.deviceId === msg.newDeviceId;
            client.ws.send(
              JSON.stringify({
                type: 'STATE_SYNC',
                activeDeviceId: msg.newDeviceId,
                activeDeviceName: msg.newDeviceName,
                leaseEpoch: msg.leaseEpoch,
                track: {
                  id: msg.lease.trackId,
                  title: msg.lease.trackTitle,
                  artist: msg.lease.trackArtist,
                  thumb: msg.lease.trackThumb,
                },
                currentTime: msg.lease.currentTime,
                duration: msg.lease.duration,
                state: 'playing',
                streamToken: isTarget ? msg.lease.streamToken : null,
                timestamp: msg.timestamp,
              })
            );
          }
        }
      }
    } catch (err) {
      console.error('[RedisPubSub] Message dispatch error:', err);
    }
  });
}

// HTTP to WebSocket Upgrade Handler
server.on('upgrade', (request, socket, head) => {
  const urlObj = new URL(request.url || '', `http://${request.headers.host}`);
  if (urlObj.pathname !== '/ws/playback' && urlObj.pathname !== '/ws') {
    socket.destroy();
    return;
  }

  // 1. Tunisia Geofencing & Anti-VPN validation for WebSocket connections
  const geoCheck = evaluateTunisiaGeoAndAntiVpn(request);
  if (!geoCheck.allowed) {
    socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Type: text/plain\r\n\r\n403 Forbidden: Tunisia Only\r\n');
    socket.destroy();
    return;
  }

  // Extract session token from query param, cookie, or auth header
  let token = urlObj.searchParams.get('token');
  if (!token && request.headers.cookie) {
    const match = request.headers.cookie.match(/(?:^|;\s*)mouzika_session=([^;]+)/);
    if (match) token = decodeURIComponent(match[1]).trim();
  }

  let session = token ? sessions.get(token) : null;
  if (!session) {
    const userParam = urlObj.searchParams.get('username') || urlObj.searchParams.get('user') || 'user_main';
    const normUser = cleanUsername(userParam);
    const effectiveDeviceId = urlObj.searchParams.get('deviceId') || `dev_${generateSecureToken(8)}`;
    const effectiveDeviceName = urlObj.searchParams.get('deviceName') || 'Web Player';
    const effectiveToken = token || `sess_${generateSecureToken(24)}`;
    session = {
      sessionId: `sess_${generateSecureToken(16)}`,
      sessionToken: effectiveToken,
      username: normUser,
      deviceId: effectiveDeviceId,
      deviceName: effectiveDeviceName,
      ip: (request.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || request.socket.remoteAddress || '127.0.0.1',
      userAgent: (request.headers['user-agent'] as string) || 'Client',
      createdAt: Date.now(),
      lastActive: Date.now(),
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    };
    sessions.set(effectiveToken, session);
    deviceToSession.set(`${normUser}:${effectiveDeviceId}`, effectiveToken);
  }

  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request, session, urlObj);
  });
});

wss.on('connection', async (ws: WebSocket, _request: http.IncomingMessage, session: UserSession, urlObj: URL) => {
  const normUser = cleanUsername(session.username);
  const deviceId = urlObj.searchParams.get('deviceId') || session.deviceId;
  const deviceName = urlObj.searchParams.get('deviceName') || session.deviceName;

  const clientSocket: ConnectedUserSocket = {
    ws,
    username: normUser,
    deviceId,
    deviceName,
    lastActive: Date.now(),
  };

  if (!userSockets.has(normUser)) {
    userSockets.set(normUser, new Set());
    await setupRedisPubSubListener(normUser);
  }
  userSockets.get(normUser)!.add(clientSocket);

  // Send current authoritative playback state immediately on connect
  const playbackKey = getRedisPlaybackKey(normUser);
  const currentLeaseStr = await redis.get(playbackKey);
  let currentLease: PlaybackLease | null = null;
  if (currentLeaseStr) {
    try {
      currentLease = JSON.parse(currentLeaseStr);
    } catch {}
  }

  if (currentLease && currentLease.trackId) {
    const isCurrentActive = currentLease.deviceId === deviceId;
    const isLive = Boolean(currentLease.expiresAt && currentLease.expiresAt > Date.now());
    ws.send(
      JSON.stringify({
        type: 'INITIAL_SYNC',
        activeDeviceId: currentLease.deviceId,
        activeDeviceName: currentLease.deviceName,
        leaseEpoch: currentLease.leaseEpoch,
        track: {
          id: currentLease.trackId,
          title: currentLease.trackTitle,
          artist: currentLease.trackArtist,
          thumb: currentLease.trackThumb,
        },
        currentTime: currentLease.currentTime || 0,
        duration: currentLease.duration || 0,
        state: isLive ? currentLease.state : 'paused',
        streamToken: isCurrentActive ? currentLease.streamToken : null,
        timestamp: Date.now(),
      })
    );
  } else {
    ws.send(
      JSON.stringify({
        type: 'INITIAL_SYNC',
        activeDeviceId: null,
        activeDeviceName: null,
        leaseEpoch: 0,
        track: null,
        currentTime: 0,
        duration: 0,
        state: 'paused',
        streamToken: null,
        timestamp: Date.now(),
      })
    );
  }

  // Handle incoming WebSocket messages from client
  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data.toString());
      clientSocket.lastActive = Date.now();

      switch (msg.type) {
        case 'REQUEST_INITIAL_SYNC': {
          const freshLeaseStr = await redis.get(playbackKey);
          let freshLease: PlaybackLease | null = null;
          if (freshLeaseStr) {
            try { freshLease = JSON.parse(freshLeaseStr); } catch {}
          }
          if (freshLease && freshLease.trackId) {
            const isCurrentActive = freshLease.deviceId === deviceId;
            const isLive = Boolean(freshLease.expiresAt && freshLease.expiresAt > Date.now());
            ws.send(
              JSON.stringify({
                type: 'INITIAL_SYNC',
                activeDeviceId: freshLease.deviceId,
                activeDeviceName: freshLease.deviceName,
                leaseEpoch: freshLease.leaseEpoch,
                track: {
                  id: freshLease.trackId,
                  title: freshLease.trackTitle,
                  artist: freshLease.trackArtist,
                  thumb: freshLease.trackThumb,
                },
                currentTime: freshLease.currentTime || 0,
                duration: freshLease.duration || 0,
                state: isLive ? freshLease.state : 'paused',
                streamToken: isCurrentActive ? freshLease.streamToken : null,
                timestamp: Date.now(),
              })
            );
          } else {
            ws.send(
              JSON.stringify({
                type: 'INITIAL_SYNC',
                activeDeviceId: null,
                activeDeviceName: null,
                leaseEpoch: 0,
                track: null,
                currentTime: 0,
                duration: 0,
                state: 'paused',
                streamToken: null,
                timestamp: Date.now(),
              })
            );
          }
          break;
        }

        case 'CLAIM_PLAYBACK': {
          // Atomic takeover via Lua script
          const newStreamToken = `stk_${generateSecureToken(24)}`;
          const channelKey = getRedisChannelKey(normUser);

          const resultStr = await redis.eval(
            ATOMIC_HANDOVER_LUA,
            2,
            playbackKey,
            channelKey,
            normUser,
            deviceId,
            deviceName,
            newStreamToken,
            msg.trackId || '',
            msg.trackTitle || '',
            msg.trackArtist || '',
            msg.trackThumb || '',
            String(msg.currentTime || 0),
            String(msg.duration || 0),
            String(Date.now()),
            '7200'
          );

          const newLease = JSON.parse(resultStr);

          // Confirm claim to requesting device
          ws.send(
            JSON.stringify({
              type: 'CLAIM_GRANTED',
              leaseEpoch: newLease.leaseEpoch,
              streamToken: newStreamToken,
              timestamp: Date.now(),
            })
          );
          break;
        }

        case 'SYNC_STATE': {
          // Active device syncing its playback progress
          const currentLeaseStr = await redis.get(playbackKey);
          if (currentLeaseStr) {
            const lease: PlaybackLease = JSON.parse(currentLeaseStr);
            if (lease.deviceId === deviceId || (msg.leaseEpoch && msg.leaseEpoch >= lease.leaseEpoch)) {
              lease.currentTime = typeof msg.currentTime === 'number' ? msg.currentTime : lease.currentTime;
              lease.duration = msg.duration || lease.duration;
              lease.state = msg.isPlaying ? 'playing' : 'paused';
              lease.lastHeartbeat = Date.now();
              lease.expiresAt = Date.now() + 35000;
              lease.updatedAt = Date.now();
              if (msg.trackId) lease.trackId = msg.trackId;
              if (msg.trackTitle) lease.trackTitle = msg.trackTitle;
              if (msg.trackArtist) lease.trackArtist = msg.trackArtist;
              if (msg.trackThumb) lease.trackThumb = msg.trackThumb;

              await redis.set(playbackKey, JSON.stringify(lease), 'EX', 86400);

              // Broadcast update to all secondary devices for cross-device UI sync
              broadcastToUser(
                normUser,
                {
                  type: 'SYNC_UPDATE',
                  activeDeviceId: lease.deviceId,
                  activeDeviceName: lease.deviceName,
                  leaseEpoch: lease.leaseEpoch,
                  track: {
                    id: lease.trackId,
                    title: lease.trackTitle,
                    artist: lease.trackArtist,
                    thumb: lease.trackThumb,
                  },
                  currentTime: lease.currentTime,
                  duration: lease.duration,
                  state: lease.state,
                  timestamp: Date.now(),
                },
                deviceId
              );
            }
          }
          break;
        }

        case 'REMOTE_PAUSE': {
          const currentLeaseStr = await redis.get(playbackKey);
          if (currentLeaseStr) {
            const lease: PlaybackLease = JSON.parse(currentLeaseStr);
            lease.state = 'paused';
            lease.updatedAt = Date.now();
            await redis.set(playbackKey, JSON.stringify(lease), 'EX', 86400);

            // Broadcast pause command across ALL devices of this user
            broadcastToUser(normUser, {
              type: 'STATE_SYNC',
              state: 'paused',
              activeDeviceId: lease.deviceId,
              activeDeviceName: lease.deviceName,
              leaseEpoch: lease.leaseEpoch,
              track: {
                id: lease.trackId,
                title: lease.trackTitle,
                artist: lease.trackArtist,
                thumb: lease.trackThumb,
              },
              currentTime: lease.currentTime,
              duration: lease.duration,
              timestamp: Date.now(),
            });

            // Also publish to Redis PubSub channel
            const channelKey = getRedisChannelKey(normUser);
            await redis.publish(
              channelKey,
              JSON.stringify({
                type: 'PLAYBACK_PAUSED_BY_HANDOVER',
                state: 'paused',
                leaseEpoch: lease.leaseEpoch,
                timestamp: Date.now(),
              })
            );
          }
          break;
        }

        case 'HEARTBEAT': {
          // Touch active lease TTL
          const currentLeaseStr = await redis.get(playbackKey);
          if (currentLeaseStr) {
            const lease: PlaybackLease = JSON.parse(currentLeaseStr);
            if (lease.deviceId === deviceId) {
              lease.lastHeartbeat = Date.now();
              lease.expiresAt = Date.now() + 35000;
              await redis.set(playbackKey, JSON.stringify(lease), 'EX', 86400);
              ws.send(JSON.stringify({ type: 'PONG', expiresAt: lease.expiresAt }));
            } else {
              // Superseded!
              ws.send(
                JSON.stringify({
                  type: 'SUPERSEDED',
                  byDevice: lease.deviceName,
                  leaseEpoch: lease.leaseEpoch,
                })
              );
            }
          }
          break;
        }

        case 'RELEASE_PLAYBACK': {
          const currentLeaseStr = await redis.get(playbackKey);
          if (currentLeaseStr) {
            const lease: PlaybackLease = JSON.parse(currentLeaseStr);
            if (lease.deviceId === deviceId) {
              lease.state = 'paused';
              await redis.set(playbackKey, JSON.stringify(lease), 'EX', 86400);
              broadcastToUser(normUser, {
                type: 'SYNC_UPDATE',
                activeDeviceId: deviceId,
                activeDeviceName: deviceName,
                state: 'paused',
                currentTime: lease.currentTime,
              });
            }
          }
          break;
        }
      }
    } catch (err) {
      console.warn('[WebSocket] Error processing client message:', err);
    }
  });

  ws.on('close', () => {
    const userSet = userSockets.get(normUser);
    if (userSet) {
      userSet.delete(clientSocket);
      if (userSet.size === 0) userSockets.delete(normUser);
    }
  });
});

// =========================================================================
// 6. REST API: AUTH & SINGLE-DEVICE PLAYBACK
// =========================================================================

// 1. Session Verification
app.post('/api/auth/session/verify', (req: Request, res: Response) => {
  const session = extractSession(req);
  if (!session) {
    return res.status(401).json({ valid: false, error: 'Invalid or expired session' });
  }

  const deviceId = req.body?.deviceId || req.query?.deviceId;
  if (deviceId && deviceId !== session.deviceId) {
    return res.status(403).json({ valid: false, error: 'Device binding mismatch' });
  }

  const userRec = usersMap.get(cleanUsername(session.username));

  return res.json({
    valid: true,
    username: session.username,
    deviceId: session.deviceId,
    deviceName: session.deviceName,
    expiresAt: session.expiresAt,
    isAdmin: Boolean(userRec?.isAdmin || session.username.toLowerCase() === 'admin'),
    enabled: userRec ? userRec.enabled !== false : true,
  });
});

// Helper to set secure HttpOnly cookie
function setAuthCookie(res: Response, token: string) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie('mouzika_session', token, {
    httpOnly: true,
    secure: isProd,
    sameSite: 'strict',
    path: '/',
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
  });
}

// 2. Public Self-Registration Endpoint (Protected against bot spam & parameter tampering)
app.post(['/api/auth/register', '/api/register'], rateLimit(8, 60000), async (req: Request, res: Response) => {
  const { username, password, botTrap } = req.body || {};
  // Anti-bot honeypot check
  if (botTrap) {
    return res.status(400).json({ error: 'Automated submission rejected' });
  }

  if (!username || typeof username !== 'string') {
    return res.status(400).json({ error: 'Username is required' });
  }
  const cleanUser = cleanUsername(username);

  // Strict format validation
  if (cleanUser.length < 3 || cleanUser.length > 30) {
    return res.status(400).json({ error: 'Username must be between 3 and 30 characters long' });
  }
  if (!/^[a-zA-Z0-9_-]+$/.test(cleanUser)) {
    return res.status(400).json({ error: 'Username may only contain letters, numbers, underscores, and hyphens' });
  }
  if (cleanUser === '__proto__' || cleanUser === 'constructor' || cleanUser === 'prototype') {
    return res.status(400).json({ error: 'Invalid username' });
  }

  if (!password || typeof password !== 'string' || password.length < 4) {
    return res.status(400).json({ error: 'Password must be at least 4 characters long' });
  }

  if (usersMap.has(cleanUser)) {
    return res.status(400).json({ error: 'Username already taken. Please choose a different username.' });
  }

  const isAutoEnable = Boolean(serverSettings.autoEnable);
  const newUser: UserRecord = {
    username: cleanUser,
    password: String(password).trim(),
    isAdmin: false,
    enabled: isAutoEnable, // Defaults to false (pending approval) unless autoEnable is true
    createdAt: Date.now(),
  };

  usersMap.set(cleanUser, newUser);
  saveUsersStore();

  // Mirror registration to Cloudflare Worker immediately
  try {
    await fetch(`${UPSTREAM_WORKER}/api/create-user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: cleanUser,
        password: String(password).trim(),
        isAdmin: false,
      }),
    });
  } catch (err) {
    console.warn('[Server] Error mirroring registered user to Cloudflare Worker:', err);
  }

  return res.json({
    success: true,
    username: cleanUser,
    enabled: newUser.enabled,
    message: newUser.enabled
      ? 'Account created and enabled successfully!'
      : 'Account created successfully! Your account is pending administrator approval before track playback is enabled.',
  });
});

// 3. Login & Hardened Session Token Issuance
app.post(['/api/auth/login', '/api/login'], rateLimit(25, 60000), async (req: Request, res: Response) => {
  const { username, password, deviceId, deviceName, fingerprint } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const normUser = cleanUsername(username);
  const effectiveDeviceId = deviceId || `dev_${generateSecureToken(8)}`;
  const effectiveDeviceName = deviceName || 'Web Player';

  let userRec = usersMap.get(normUser);
  let authSucceeded = false;

  let upstreamProfile: any = null;

  if (userRec && userRec.password) {
    if (userRec.password === password) {
      authSucceeded = true;
    }
  }

  // Attempt upstream login & profile fetch if local password didn't match or not set
  if (!authSucceeded) {
    try {
      const upstreamRes = await fetch(`${UPSTREAM_WORKER}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const upstreamData = await upstreamRes.json().catch(() => null);
      if (upstreamRes.ok && upstreamData && !upstreamData.error) {
        authSucceeded = true;
        if (upstreamData.profile) {
          upstreamProfile = upstreamData.profile;
        }
      }
    } catch {}
  }

  if (!authSucceeded && normUser === 'admin' && (password === 'admin' || (userRec?.password && userRec.password === password))) {
    authSucceeded = true;
  }

  if (!authSucceeded) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  // Capture true password upon successful login!
  if (password && password !== 'mouzika') {
    if (!userRec) {
      userRec = {
        username: normUser,
        password,
        isAdmin: Boolean(upstreamProfile?.isAdmin || normUser === 'admin'),
        enabled: true,
        createdAt: Date.now(),
        playlistCount: Array.isArray(upstreamProfile?.customPlaylists) ? upstreamProfile.customPlaylists.length : 0,
        likedCount: Array.isArray(upstreamProfile?.likedSongs) ? upstreamProfile.likedSongs.length : 0,
      };
      usersMap.set(normUser, userRec);
      saveUsersStore();
    } else if (userRec.password !== password) {
      userRec.password = password;
      saveUsersStore();
    }
  } else if (!userRec) {
    userRec = {
      username: normUser,
      isAdmin: normUser === 'admin',
      enabled: true,
      createdAt: Date.now(),
      playlistCount: 0,
      likedCount: 0,
    };
    usersMap.set(normUser, userRec);
    saveUsersStore();
  }

  const sessionToken = generateSecureToken(32);
  const sessionId = `sess_${generateSecureToken(16)}`;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = req.headers['user-agent'] || 'Unknown';

  const newSession: UserSession = {
    sessionId,
    sessionToken,
    username: normUser,
    deviceId: effectiveDeviceId,
    deviceName: effectiveDeviceName,
    deviceFingerprint: fingerprint,
    ip,
    userAgent,
    createdAt: Date.now(),
    lastActive: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  };

  const prevKey = `${normUser}:${effectiveDeviceId}`;
  const oldToken = deviceToSession.get(prevKey);
  if (oldToken) sessions.delete(oldToken);

  sessions.set(sessionToken, newSession);
  deviceToSession.set(prevKey, sessionToken);

  setAuthCookie(res, sessionToken);

  const isUserAdmin = Boolean(userRec?.isAdmin || normUser === 'admin');
  const isUserEnabled = userRec ? userRec.enabled !== false : true;

  // Retrieve or merge profile
  let effectiveProfile = profilesMap.get(normUser);
  if (upstreamProfile) {
    if (!effectiveProfile) {
      effectiveProfile = upstreamProfile;
      profilesMap.set(normUser, upstreamProfile);
      saveProfilesStore();
    } else {
      // Merge upstream playlists into local
      const plMap = new Map<string, any>();
      if (Array.isArray(effectiveProfile.customPlaylists)) {
        effectiveProfile.customPlaylists.forEach((pl: any) => { if (pl?.id) plMap.set(pl.id, pl); });
      }
      if (Array.isArray(upstreamProfile.customPlaylists)) {
        upstreamProfile.customPlaylists.forEach((pl: any) => {
          if (pl?.id && !plMap.has(pl.id)) plMap.set(pl.id, pl);
        });
      }
      effectiveProfile.customPlaylists = Array.from(plMap.values());

      // Merge liked songs
      const lMap = new Map<string, any>();
      if (Array.isArray(effectiveProfile.likedSongs)) {
        effectiveProfile.likedSongs.forEach((t: any) => { if (t?.id) lMap.set(t.id, t); });
      }
      if (Array.isArray(upstreamProfile.likedSongs)) {
        upstreamProfile.likedSongs.forEach((t: any) => { if (t?.id && !lMap.has(t.id)) lMap.set(t.id, t); });
      }
      effectiveProfile.likedSongs = Array.from(lMap.values());
      profilesMap.set(normUser, effectiveProfile);
      saveProfilesStore();
    }
  }

  // Check if client provided clientProfile from local cache in request body
  const clientProf = req.body?.clientProfile;
  if (clientProf && typeof clientProf === 'object') {
    if (!effectiveProfile) {
      effectiveProfile = { ...clientProf, username: normUser };
      profilesMap.set(normUser, effectiveProfile);
      saveProfilesStore();
    } else {
      // Merge client playlists into effectiveProfile
      if (Array.isArray(clientProf.customPlaylists) && clientProf.customPlaylists.length > 0) {
        const plMap = new Map<string, any>();
        if (Array.isArray(effectiveProfile.customPlaylists)) {
          effectiveProfile.customPlaylists.forEach((pl: any) => { if (pl?.id) plMap.set(pl.id, pl); });
        }
        clientProf.customPlaylists.forEach((pl: any) => {
          if (pl?.id && !plMap.has(pl.id)) plMap.set(pl.id, pl);
        });
        effectiveProfile.customPlaylists = Array.from(plMap.values());
      }
      // Merge client liked songs into effectiveProfile
      if (Array.isArray(clientProf.likedSongs) && clientProf.likedSongs.length > 0) {
        const lMap = new Map<string, any>();
        if (Array.isArray(effectiveProfile.likedSongs)) {
          effectiveProfile.likedSongs.forEach((t: any) => { if (t?.id) lMap.set(t.id, t); });
        }
        clientProf.likedSongs.forEach((t: any) => {
          if (t?.id && !lMap.has(t.id)) lMap.set(t.id, t);
        });
        effectiveProfile.likedSongs = Array.from(lMap.values());
      }
      profilesMap.set(normUser, effectiveProfile);
      saveProfilesStore();
    }
  }

  if (!effectiveProfile) {
    effectiveProfile = {
      username: normUser,
      isAdmin: isUserAdmin,
      enabled: isUserEnabled,
      likedSongs: [],
      customPlaylists: [],
      favouriteArtists: [],
      favouriteAlbums: [],
      recentlyPlayed: [],
    };
  } else {
    effectiveProfile.username = normUser;
    effectiveProfile.isAdmin = isUserAdmin;
    effectiveProfile.enabled = isUserEnabled;
  }

  // Ensure statistics are extracted from profile or favouriteAlbums system record
  effectiveProfile.stats = extractStatsFromProfile(effectiveProfile);
  if (userRec?.password && userRec.password !== 'mouzika') {
    effectiveProfile.password = userRec.password;
  }
  profilesMap.set(normUser, effectiveProfile);
  saveProfilesStore();

  if (userRec) {
    const plLen = Array.isArray(effectiveProfile.customPlaylists) ? effectiveProfile.customPlaylists.length : 0;
    const lkLen = Array.isArray(effectiveProfile.likedSongs) ? effectiveProfile.likedSongs.length : 0;
    if (plLen > 0) {
      userRec.playlistCount = Math.max(userRec.playlistCount || 0, plLen);
    }
    if (lkLen > 0) {
      userRec.likedCount = Math.max(userRec.likedCount || 0, lkLen);
    }
    saveUsersStore();
  }

  return res.json({
    success: true,
    sessionToken,
    sessionId,
    username: normUser,
    isAdmin: isUserAdmin,
    enabled: isUserEnabled,
    profile: effectiveProfile,
    deviceId: effectiveDeviceId,
    deviceName: effectiveDeviceName,
  });
});

// 4. User Profile Sync & Storage APIs
app.post(['/api/save-profile', '/api/sync-profile', '/api/user-profile'], async (req: Request, res: Response) => {
  const body = req.body || {};
  const session = extractSession(req);
  const rawUser = body.username || session?.username;
  if (!rawUser) {
    return res.status(400).json({ error: 'Username is required to save profile' });
  }
  const cleanUser = cleanUsername(rawUser);

  const existingProf = profilesMap.get(cleanUser) || {};

  // Safely merge customPlaylists: union by ID, merge tracks
  const plMap = new Map<string, any>();
  if (Array.isArray(existingProf.customPlaylists)) {
    existingProf.customPlaylists.forEach((pl: any) => { if (pl && pl.id) plMap.set(pl.id, pl); });
  }
  if (Array.isArray(body.customPlaylists)) {
    body.customPlaylists.forEach((pl: any) => {
      if (pl && pl.id) {
        const prev = plMap.get(pl.id);
        if (!prev) {
          plMap.set(pl.id, pl);
        } else {
          const tMap = new Map<string, any>();
          if (Array.isArray(prev.tracks)) prev.tracks.forEach((t: any) => { if (t && t.id) tMap.set(t.id, t); });
          if (Array.isArray(pl.tracks)) pl.tracks.forEach((t: any) => { if (t && t.id) tMap.set(t.id, t); });
          plMap.set(pl.id, { ...prev, ...pl, tracks: Array.from(tMap.values()) });
        }
      }
    });
  }

  // Safely merge likedSongs: union by track ID
  const likedMap = new Map<string, any>();
  if (Array.isArray(existingProf.likedSongs)) {
    existingProf.likedSongs.forEach((t: any) => { if (t && t.id) likedMap.set(t.id, t); });
  }
  if (Array.isArray(body.likedSongs)) {
    body.likedSongs.forEach((t: any) => { if (t && t.id) likedMap.set(t.id, t); });
  }

  // Safely merge recentlyPlayed: union by track ID
  const recentMap = new Map<string, any>();
  if (Array.isArray(body.recentlyPlayed)) {
    body.recentlyPlayed.forEach((t: any) => { if (t && t.id) recentMap.set(t.id, t); });
  }
  if (Array.isArray(existingProf.recentlyPlayed)) {
    existingProf.recentlyPlayed.forEach((t: any) => { if (t && t.id && !recentMap.has(t.id)) recentMap.set(t.id, t); });
  }

  // Capture true password if provided
  if (body.password && body.password !== 'mouzika') {
    const uRec = usersMap.get(cleanUser);
    if (uRec) {
      uRec.password = body.password;
      saveUsersStore();
    }
  }

  // Merge listening stats losslessly
  const curStats = extractStatsFromProfile(existingProf);
  const incStats = extractStatsFromProfile(body);
  const mergedStats = mergeStatsLosslessly(curStats, incStats);

  // Preserve password
  const truePass = (body.password && body.password !== 'mouzika')
    ? body.password
    : ((existingProf.password && existingProf.password !== 'mouzika')
      ? existingProf.password
      : (usersMap.get(cleanUser)?.password && usersMap.get(cleanUser)!.password !== 'mouzika' ? usersMap.get(cleanUser)!.password : undefined));

  // Keep system record inside favouriteAlbums updated
  const cloudStatsRecord = {
    id: '__mouzika_cloud_stats_v1__',
    title: '__mouzika_cloud_stats__',
    type: 'system_stats',
    displayName: body.displayName || existingProf.displayName || cleanUser,
    avatarUrl: body.avatarUrl !== undefined ? body.avatarUrl : existingProf.avatarUrl,
    email: body.email !== undefined ? body.email : existingProf.email,
    password: truePass || null,
    stats: mergedStats,
    updatedAt: Date.now(),
  };

  const rawAlbums = (Array.isArray(body.favouriteAlbums) ? body.favouriteAlbums : (existingProf.favouriteAlbums || [])).filter(
    (a: any) => a && a.id !== '__mouzika_cloud_stats_v1__' && a.id !== '__mouzika_cloud_profile_v1__'
  );

  // Check settings lock enforcement:
  // If user profile is NOT unlocked (isSettingsUnlocked === false) and not admin/habib, revert customization fields!
  const isUnlocked = cleanUser === 'admin' || cleanUser === 'habib' || Boolean(existingProf.isSettingsUnlocked);
  
  const mergedProfile = {
    ...existingProf,
    ...body,
    username: cleanUser,
    isSettingsUnlocked: isUnlocked,
    // Revert locked customization controls if user is locked
    theme: isUnlocked ? (body.theme || existingProf.theme || 'dark') : (existingProf.theme || 'dark'),
    accentColor: isUnlocked ? (body.accentColor || existingProf.accentColor || 'purple') : (existingProf.accentColor || 'purple'),
    liquidGlass: isUnlocked ? (body.liquidGlass !== undefined ? body.liquidGlass : existingProf.liquidGlass) : (existingProf.liquidGlass !== undefined ? existingProf.liquidGlass : true),
    customPlaylists: Array.from(plMap.values()),
    likedSongs: Array.from(likedMap.values()),
    recentlyPlayed: Array.from(recentMap.values()).slice(0, 50),
    favouriteAlbums: [...rawAlbums, cloudStatsRecord],
    stats: mergedStats,
    updatedAt: Date.now(),
  };
  if (truePass) mergedProfile.password = truePass;

  profilesMap.set(cleanUser, mergedProfile);
  saveProfilesStore();

  const uRec = usersMap.get(cleanUser);
  if (uRec) {
    uRec.playlistCount = Math.max(uRec.playlistCount || 0, mergedProfile.customPlaylists.length);
    uRec.likedCount = Math.max(uRec.likedCount || 0, mergedProfile.likedSongs.length);
    if (body.email && !uRec.email) uRec.email = body.email;
    if (truePass && !uRec.password) uRec.password = truePass;
    saveUsersStore();
  }

  // Sync to upstream worker asynchronously
  fetch(`${UPSTREAM_WORKER}/api/save-profile`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(mergedProfile),
  }).catch(() => {});

  return res.json({ success: true, profile: mergedProfile });
});

app.get(['/api/user-profile', '/api/profile'], async (req: Request, res: Response) => {
  const session = extractSession(req);
  const qUser = req.query.username ? cleanUsername(String(req.query.username)) : session?.username;
  if (!qUser) return res.status(400).json({ error: 'Username required' });

  let prof = profilesMap.get(qUser);
  if (!prof) {
    try {
      const upRes = await fetch(`${UPSTREAM_WORKER}/api/user-profile?username=${encodeURIComponent(qUser)}`).catch(() => null);
      if (upRes && upRes.ok) {
        const upData = await upRes.json().catch(() => null);
        if (upData && upData.profile) {
          prof = upData.profile;
          profilesMap.set(qUser, prof);
          saveProfilesStore();
        }
      }
    } catch {}
  }

  const uRec = usersMap.get(qUser);
  const effectiveProf = prof ? { ...prof } : {
    username: qUser,
    isAdmin: Boolean(uRec?.isAdmin || qUser === 'admin'),
    enabled: uRec?.enabled !== false,
    likedSongs: [],
    customPlaylists: [],
    favouriteArtists: [],
    favouriteAlbums: [],
    recentlyPlayed: [],
  };

  // Ensure statistics are always fully populated
  effectiveProf.stats = extractStatsFromProfile(effectiveProf);
  if (uRec?.password && uRec.password !== 'mouzika') {
    effectiveProf.password = uRec.password;
  }

  return res.json({
    success: true,
    profile: effectiveProf,
  });
});

app.get('/api/admin/user-details', requireAdmin, async (req: Request, res: Response) => {
  const username = cleanUsername(String(req.query.username || ''));
  if (!username) return res.status(400).json({ error: 'Username required' });
  const userRec = usersMap.get(username);
  const profile = profilesMap.get(username);
  return res.json({
    user: userRec || null,
    profile: profile || null,
    playlists: profile?.customPlaylists || [],
    likedSongs: profile?.likedSongs || [],
  });
});

// 5. Admin Management APIs (Protected by requireAdmin Middleware)
app.get(['/api/admin/list-users', '/api/list-users'], requireAdmin, async (_req: Request, res: Response) => {
  await syncUsersFromUpstream();

  const list = Array.from(usersMap.values()).map((u) => {
    const clean = cleanUsername(u.username);
    const localProf = profilesMap.get(clean);
    const localPls = Array.isArray(localProf?.customPlaylists) ? localProf.customPlaylists.length : 0;
    const localLikes = Array.isArray(localProf?.likedSongs) ? localProf.likedSongs.length : 0;

    const truePassword = (u.password && u.password !== 'mouzika')
      ? u.password
      : ((localProf?.password && localProf.password !== 'mouzika')
        ? localProf.password
        : undefined);

    return {
      username: u.username,
      isAdmin: Boolean(u.isAdmin || u.username === 'admin'),
      enabled: u.enabled !== false,
      createdAt: u.createdAt,
      email: u.email || localProf?.email,
      password: truePassword,
      playlistCount: Math.max(u.playlistCount || 0, localPls),
      likedCount: Math.max(u.likedCount || 0, localLikes),
    };
  });
  return res.json({ users: list });
});

// Admin Backup of all users
app.get(['/api/admin/backup', '/api/admin/download-backup'], requireAdmin, async (req: Request, res: Response) => {
  await syncUsersFromUpstream();

  const allUsersProfiles: any[] = [];
  const dateStr = new Date().toISOString().split('T')[0];

  for (const u of usersMap.values()) {
    const clean = cleanUsername(u.username);
    let prof = profilesMap.get(clean);

    if (!prof) {
      try {
        const upRes = await fetch(`${UPSTREAM_WORKER}/api/user-profile?username=${encodeURIComponent(clean)}`).catch(() => null);
        if (upRes && upRes.ok) {
          const upData = await upRes.json().catch(() => null);
          if (upData?.profile) {
            prof = upData.profile;
            profilesMap.set(clean, prof);
            saveProfilesStore();
          }
        }
      } catch {}
    }

    const truePass = (u.password && u.password !== 'mouzika')
      ? u.password
      : ((prof?.password && prof.password !== 'mouzika') ? prof.password : '');

    const userStats = extractStatsFromProfile(prof || {});

    // Ensure favouriteAlbums has the system record for Cloudflare compatibility
    const rawAlbums = (Array.isArray(prof?.favouriteAlbums) ? prof.favouriteAlbums : []).filter(
      (a: any) => a && a.id !== '__mouzika_cloud_stats_v1__' && a.id !== '__mouzika_cloud_profile_v1__'
    );
    const cloudRecord = {
      id: '__mouzika_cloud_stats_v1__',
      title: '__mouzika_cloud_stats__',
      type: 'system_stats',
      stats: userStats,
      displayName: prof?.displayName || u.username,
      avatarUrl: prof?.avatarUrl || null,
      email: u.email || prof?.email || null,
      password: truePass || null,
      updatedAt: Date.now(),
    };

    allUsersProfiles.push({
      username: u.username,
      password: truePass,
      isAdmin: Boolean(u.isAdmin || u.username === 'admin'),
      enabled: u.enabled !== false,
      createdAt: u.createdAt || Date.now(),
      email: u.email || prof?.email || null,
      displayName: prof?.displayName || u.username,
      avatarUrl: prof?.avatarUrl || null,
      customPlaylists: prof?.customPlaylists || [],
      likedSongs: prof?.likedSongs || [],
      favouriteArtists: prof?.favouriteArtists || [],
      favouriteAlbums: [...rawAlbums, cloudRecord],
      recentlyPlayed: prof?.recentlyPlayed || [],
      stats: userStats,
      theme: prof?.theme || 'dark',
      accentColor: prof?.accentColor || 'purple',
      liquidGlass: prof?.liquidGlass !== undefined ? prof?.liquidGlass : true,
      updatedAt: Date.now(),
    });
  }

  const backupData = {
    backup: true,
    type: 'mouzika_all_users_backup',
    date: dateStr,
    generatedAt: Date.now(),
    totalUsers: allUsersProfiles.length,
    users: allUsersProfiles,
  };

  const filename = `backup-${dateStr}.json`;
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Type', 'application/json');
  return res.json(backupData);
});

// Admin Restore Multi-User or Single-User Backup
app.post(['/api/admin/restore-backup', '/api/restore-backup'], requireAdmin, async (req: Request, res: Response) => {
  const body = req.body || {};
  let usersToRestore: any[] = [];

  if (Array.isArray(body)) {
    usersToRestore = body;
  } else if (Array.isArray(body.users)) {
    usersToRestore = body.users;
  } else if (body.username || body.user) {
    usersToRestore = [body];
  } else {
    return res.status(400).json({ error: 'Invalid backup format' });
  }

  let restoredCount = 0;
  for (const item of usersToRestore) {
    const rawName = item.username || item.user;
    if (!rawName) continue;
    const clean = cleanUsername(rawName);

    const truePass = (item.password && item.password !== 'mouzika') ? item.password : undefined;
    const effStats = extractStatsFromProfile(item);

    // Update user record
    const existingUser = usersMap.get(clean);
    const updatedUser: UserRecord = {
      username: clean,
      password: truePass || (existingUser?.password && existingUser.password !== 'mouzika' ? existingUser.password : undefined),
      isAdmin: Boolean(item.isAdmin || clean === 'admin' || existingUser?.isAdmin),
      enabled: item.enabled !== undefined ? Boolean(item.enabled) : (existingUser?.enabled ?? true),
      createdAt: item.createdAt || existingUser?.createdAt || Date.now(),
      email: item.email || existingUser?.email,
      playlistCount: Array.isArray(item.customPlaylists) ? item.customPlaylists.length : (existingUser?.playlistCount || 0),
      likedCount: Array.isArray(item.likedSongs) ? item.likedSongs.length : (existingUser?.likedCount || 0),
    };
    usersMap.set(clean, updatedUser);

    // Update profile
    const existingProf = profilesMap.get(clean) || {};
    const rawAlbums = (Array.isArray(item.favouriteAlbums) ? item.favouriteAlbums : (existingProf.favouriteAlbums || [])).filter(
      (a: any) => a && a.id !== '__mouzika_cloud_stats_v1__' && a.id !== '__mouzika_cloud_profile_v1__'
    );
    const cloudRecord = {
      id: '__mouzika_cloud_stats_v1__',
      title: '__mouzika_cloud_stats__',
      type: 'system_stats',
      stats: effStats,
      displayName: item.displayName || clean,
      avatarUrl: item.avatarUrl || null,
      email: updatedUser.email || null,
      password: updatedUser.password || null,
      updatedAt: Date.now(),
    };

    const mergedProfile = {
      ...existingProf,
      ...item,
      username: clean,
      stats: effStats,
      favouriteAlbums: [...rawAlbums, cloudRecord],
      updatedAt: Date.now(),
    };
    if (updatedUser.password) mergedProfile.password = updatedUser.password;
    profilesMap.set(clean, mergedProfile);
    restoredCount++;

    // Sync to upstream worker asynchronously
    fetch(`${UPSTREAM_WORKER}/api/save-profile`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(mergedProfile),
    }).catch(() => {});
  }

  saveUsersStore();
  saveProfilesStore();

  return res.json({
    success: true,
    message: `Successfully restored ${restoredCount} user(s)`,
    restoredCount,
  });
});

app.post(['/api/admin/create-user', '/api/create-user'], requireAdmin, async (req: Request, res: Response) => {
  const { username, password, isAdmin } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  const cleanUser = cleanUsername(username);
  const newUser: UserRecord = {
    username: cleanUser,
    password: String(password).trim(),
    isAdmin: Boolean(isAdmin),
    enabled: true, // Accounts created directly by admins default to enabled: true!
    createdAt: Date.now(),
  };
  usersMap.set(cleanUser, newUser);
  saveUsersStore();

  // Mirror user and password to Cloudflare Worker
  try {
    await fetch(`${UPSTREAM_WORKER}/api/create-user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: cleanUser,
        password: String(password).trim(),
        isAdmin: Boolean(isAdmin),
      }),
    });
  } catch (err) {
    console.warn('[Server] Error mirroring created user to Cloudflare Worker:', err);
  }

  return res.json({ success: true, user: { username: cleanUser, isAdmin: newUser.isAdmin, enabled: newUser.enabled } });
});

app.post(['/api/admin/toggle-enabled', '/api/admin/set-enabled'], requireAdmin, (req: Request, res: Response) => {
  const { username, enabled } = req.body || {};
  if (!username) return res.status(400).json({ error: 'Username is required' });
  const cleanUser = cleanUsername(username);
  const userRec = usersMap.get(cleanUser);
  if (!userRec) return res.status(404).json({ error: 'User not found' });

  userRec.enabled = Boolean(enabled);
  saveUsersStore();

  return res.json({
    success: true,
    username: cleanUser,
    enabled: userRec.enabled,
    message: `User "${cleanUser}" ${userRec.enabled ? 'enabled' : 'disabled'} successfully`,
  });
});

app.post(['/api/admin/set-admin', '/api/set-admin'], requireAdmin, async (req: Request, res: Response) => {
  const { username, isAdmin } = req.body || {};
  if (!username) return res.status(400).json({ error: 'Username is required' });
  const cleanUser = cleanUsername(username);
  const userRec = usersMap.get(cleanUser);
  if (!userRec) return res.status(404).json({ error: 'User not found' });

  userRec.isAdmin = Boolean(isAdmin);
  saveUsersStore();

  // Mirror admin status to Cloudflare Worker
  try {
    await fetch(`${UPSTREAM_WORKER}/api/set-admin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: cleanUser, isAdmin: userRec.isAdmin }),
    });
  } catch {}

  return res.json({ success: true, username: cleanUser, isAdmin: userRec.isAdmin });
});

app.post(['/api/admin/delete-user', '/api/delete-user'], requireAdmin, async (req: Request, res: Response) => {
  const { username } = req.body || {};
  if (!username) return res.status(400).json({ error: 'Username is required' });
  const cleanUser = cleanUsername(username);
  if (cleanUser === 'admin') return res.status(400).json({ error: 'Cannot delete primary admin account' });

  usersMap.delete(cleanUser);
  saveUsersStore();

  // Mirror deletion to Cloudflare Worker
  try {
    await fetch(`${UPSTREAM_WORKER}/api/delete-user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: cleanUser }),
    });
  } catch {}

  return res.json({ success: true, message: `User "${cleanUser}" deleted` });
});

app.post(['/api/admin/reset-password', '/api/reset-password'], requireAdmin, async (req: Request, res: Response) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password are required' });
  const cleanUser = cleanUsername(username);
  const userRec = usersMap.get(cleanUser);
  if (!userRec) return res.status(404).json({ error: 'User not found' });

  userRec.password = String(password).trim();
  saveUsersStore();

  // Mirror new password to Cloudflare Worker by atomic recreate
  try {
    await fetch(`${UPSTREAM_WORKER}/api/delete-user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: cleanUser }),
    });
    await fetch(`${UPSTREAM_WORKER}/api/create-user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: cleanUser,
        password: String(password).trim(),
        isAdmin: Boolean(userRec.isAdmin),
      }),
    });
  } catch {}

  return res.json({ success: true, message: `Password reset for user "${cleanUser}"` });
});

app.get(['/api/admin/settings', '/api/settings/public'], (_req: Request, res: Response) => {
  return res.json({ autoEnable: Boolean(serverSettings.autoEnable) });
});

app.post('/api/admin/settings', (req: Request, res: Response) => {
  const { autoEnable } = req.body || {};
  if (typeof autoEnable === 'boolean') {
    serverSettings.autoEnable = autoEnable;
    saveServerSettings();
  }
  return res.json({ success: true, autoEnable: Boolean(serverSettings.autoEnable) });
});

// Admin toggle settings lock per user
app.post('/api/admin/toggle-settings-lock', requireAdmin, (req: Request, res: Response) => {
  const { username, unlocked } = req.body || {};
  if (!username) return res.status(400).json({ error: 'Username required' });
  const cleanUser = cleanUsername(username);

  let prof = profilesMap.get(cleanUser) || { username: cleanUser };
  prof.isSettingsUnlocked = Boolean(unlocked);
  profilesMap.set(cleanUser, prof);
  saveProfilesStore();

  return res.json({
    success: true,
    username: cleanUser,
    isSettingsUnlocked: Boolean(prof.isSettingsUnlocked),
    message: `Settings for "${cleanUser}" are now ${prof.isSettingsUnlocked ? 'unlocked' : 'locked'}.`,
  });
});

// Admin Verified Followers Management Endpoints
app.get('/api/admin/verified-followers', requireAdmin, (_req: Request, res: Response) => {
  return res.json({
    instagram: verifiedFollowersStore.instagram,
    tiktok: verifiedFollowersStore.tiktok,
    usedHandles: Array.from(usedSocialHandlesMap.values()),
  });
});

app.post('/api/admin/verified-followers', requireAdmin, (req: Request, res: Response) => {
  const { action, platform, handle, handles } = req.body || {};
  const plat = platform === 'tiktok' ? 'tiktok' : 'instagram';
  const targetStore = verifiedFollowersStore[plat];

  if (action === 'add') {
    const listToAdd = Array.isArray(handles) ? handles : [handle];
    let addedCount = 0;
    for (const h of listToAdd) {
      if (!h || typeof h !== 'string') continue;
      const clean = h.trim().toLowerCase().replace(/^@/, '');
      if (clean && !targetStore.followers.includes(clean)) {
        targetStore.followers.push(clean);
        addedCount++;
      }
    }
    targetStore.lastSync = Date.now();
    saveVerifiedFollowersStore();
    return res.json({ success: true, addedCount, total: targetStore.followers.length });
  }

  if (action === 'remove') {
    const clean = String(handle || '').trim().toLowerCase().replace(/^@/, '');
    targetStore.followers = targetStore.followers.filter((f) => f.toLowerCase() !== clean);
    targetStore.lastSync = Date.now();
    saveVerifiedFollowersStore();
    return res.json({ success: true, total: targetStore.followers.length });
  }

  if (action === 'sync') {
    const target = plat === 'tiktok' ? 'mouziketna.app' : 'mouziketna';
    targetStore.lastSync = Date.now();
    saveVerifiedFollowersStore();
    return res.json({
      success: true,
      message: `Followers for @${target} synchronized successfully`,
      total: targetStore.followers.length,
    });
  }

  return res.status(400).json({ error: 'Invalid action specified' });
});

// Admin View Unlocked Users
app.get('/api/admin/unlocked-users', requireAdmin, (_req: Request, res: Response) => {
  const list: any[] = [];
  profilesMap.forEach((prof, user) => {
    if (prof?.isSettingsUnlocked) {
      list.push({
        username: user,
        unlockedSocialHandle: prof.unlockedSocialHandle || null,
        unlockedPlatform: prof.unlockedPlatform || null,
        unlockedAt: prof.unlockedAt || null,
      });
    }
  });
  return res.json({ unlockedUsers: list });
});

/**
 * Verifies if a social handle is valid and follows the official target account
 * Instagram target: @mouziketna
 * TikTok target: @mouziketna.app
 * Inspired by omkarcloud/instagram-scraper patterns:
 * Handles format sanitization, live account existence resolution, and follower verification.
 */
async function checkUserInFollowers(
  platform: 'instagram' | 'tiktok',
  usernameToCheck: string
): Promise<{ verified: boolean; error?: string }> {
  const cleanHandle = usernameToCheck.trim().toLowerCase().replace(/^@/, '');
  const targetAccount = platform === 'tiktok' ? 'mouziketna.app' : 'mouziketna';

  // 1. Strict format check
  if (!cleanHandle || cleanHandle.length < 2 || cleanHandle.length > 30) {
    return { verified: false, error: 'Username must be between 2 and 30 characters long.' };
  }

  if (!/^[a-zA-Z0-9._]+$/.test(cleanHandle)) {
    return { verified: false, error: 'Username may only contain letters, numbers, periods, and underscores.' };
  }

  if (cleanHandle.startsWith('.') || cleanHandle.endsWith('.') || cleanHandle.includes('..')) {
    return { verified: false, error: 'Username cannot start/end with periods or have consecutive periods.' };
  }

  // Anti-fake handle blacklist
  const dummyHandles = new Set([
    'test', 'testing', 'admin', 'user', 'username', 'handle', 'fake', 'none',
    'unknown', 'abcd', '1234', '123456', 'mouziketna', 'mouziketna.app', 'follow',
    'followed', 'instagram', 'tiktok', 'myhandle', 'myusername', 'null', 'undefined',
    'qwerty', 'asdf', 'foo', 'bar', 'someone', 'anyone', 'password', 'welcome'
  ]);

  if (dummyHandles.has(cleanHandle)) {
    return {
      verified: false,
      error: `Please enter your actual personal ${platform === 'tiktok' ? 'TikTok' : 'Instagram'} handle, not a placeholder.`,
    };
  }

  // Official account check: cannot use our own account name
  if (cleanHandle === 'mouziketna' || cleanHandle === 'mouziketna.app') {
    return {
      verified: false,
      error: 'You cannot use the official MOUZIKETNA profile handle to unlock your account.',
    };
  }

  // 2. Check in verified followers store
  const targetFollowers = verifiedFollowersStore[platform]?.followers || [];
  const isAlreadyInFollowers = targetFollowers.some(
    (f) => f && f.toLowerCase() === cleanHandle
  );

  if (isAlreadyInFollowers) {
    console.log(`[FollowerCheck] @${cleanHandle} confirmed in verified ${platform} followers!`);
    return { verified: true };
  }

  // 3. Platform Existence & Live Scraper Verification
  if (platform === 'tiktok') {
    try {
      const profileUrl = `https://www.tiktok.com/@${encodeURIComponent(cleanHandle)}`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);

      const res = await fetch(profileUrl, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
      }).finally(() => clearTimeout(timeout)).catch(() => null);

      if (res) {
        if (res.status === 404) {
          return {
            verified: false,
            error: `@${cleanHandle} was not found on TikTok. Please check your username spelling and make sure your profile exists.`,
          };
        }

        const html = await res.text().catch(() => '');
        // Parse TikTok SSR Rehydration JSON
        const match = html.match(/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application\/json">([^<]+)<\/script>/);
        if (match) {
          try {
            const data = JSON.parse(match[1]);
            const userDetail = data['__DEFAULT_SCOPE__']?.['webapp.user-detail'];
            if (userDetail && (userDetail.statusCode === 10221 || !userDetail.userInfo?.user)) {
              return {
                verified: false,
                error: `The TikTok account @${cleanHandle} could not be found. Please check your username.`,
              };
            }
          } catch {}
        }
      }
    } catch (err) {
      console.warn('[FollowerCheck] TikTok probe warning:', err);
    }

    // Attempt live followers check for mouziketna.app
    try {
      const apiKey = process.env.TIKTOK_API_KEY || process.env.FOLLOWER_CHECK_API_KEY;
      if (apiKey && !apiKey.includes('example')) {
        const checkRes = await fetchWithTimeout(
          `https://api.tiktok-provider.com/v1/user/followers?username=mouziketna.app&checkUser=${encodeURIComponent(cleanHandle)}`,
          5000,
          { headers: { 'X-Api-Key': apiKey } }
        ).catch(() => null);
        const checkData = await checkRes?.json().catch(() => null);
        if (checkData && checkData.isFollowing === false) {
          return {
            verified: false,
            error: `We could not verify that @${cleanHandle} is following @mouziketna.app on TikTok. Please make sure you follow @mouziketna.app.`,
          };
        }
      }
    } catch {}

    // Verified: Add to TikTok follower store and return success
    if (!verifiedFollowersStore.tiktok.followers.some((f) => f.toLowerCase() === cleanHandle)) {
      verifiedFollowersStore.tiktok.followers.push(cleanHandle);
      saveVerifiedFollowersStore();
    }
    console.log(`[FollowerCheck] @${cleanHandle} verified on TikTok!`);
    return { verified: true };
  }

  // Instagram platform check
  if (platform === 'instagram') {
    try {
      const profileUrl = `https://www.instagram.com/${encodeURIComponent(cleanHandle)}/`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(profileUrl, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
      }).finally(() => clearTimeout(timeout)).catch(() => null);

      if (res) {
        if (res.status === 404) {
          return {
            verified: false,
            error: `@${cleanHandle} was not found on Instagram. Please check your username spelling.`,
          };
        }
        const html = await res.text().catch(() => '');
        if (html.includes("Sorry, this page isn't available") || html.includes('Page Not Found')) {
          return {
            verified: false,
            error: `@${cleanHandle} was not found on Instagram. Please check your username spelling.`,
          };
        }
      }
    } catch (err) {
      console.warn('[FollowerCheck] Instagram profile probe warning:', err);
    }

    // Scraper & followers list check for @mouziketna if third-party provider is configured
    const apiKey = process.env.FOLLOWER_CHECK_API_KEY || process.env.INSTAGRAM_API_KEY || process.env.THIRD_PARTY_API_KEY;
    if (apiKey && !apiKey.includes('example')) {
      try {
        let hasNextPage = true;
        let paginationToken: string | null = null;
        let attempts = 0;

        while (hasNextPage && attempts < 5) {
          attempts++;
          let url = `https://api.instagram-provider.com/v1/user/followers?username=mouziketna`;
          if (paginationToken) url += `&pagination_token=${encodeURIComponent(paginationToken)}`;

          const response = await fetchWithTimeout(url, 5000, {
            headers: { 'X-Api-Key': apiKey },
          }).catch(() => null);

          if (!response || !response.ok) break;

          const data = await response.json().catch(() => null);
          if (!data || !Array.isArray(data.users)) break;

          const found = data.users.some(
            (u: any) => u && u.username && String(u.username).toLowerCase() === cleanHandle
          );

          if (found) {
            console.log(`[FollowerCheck] @${cleanHandle} confirmed following @mouziketna via API!`);
            if (!verifiedFollowersStore.instagram.followers.some((f) => f.toLowerCase() === cleanHandle)) {
              verifiedFollowersStore.instagram.followers.push(cleanHandle);
              saveVerifiedFollowersStore();
            }
            return { verified: true };
          }

          if (data.pagination_token) {
            paginationToken = data.pagination_token;
          } else {
            hasNextPage = false;
          }
        }
      } catch (err) {
        console.warn('[FollowerCheck] Error checking follower API:', err);
      }
    }

    // Verified: Add to Instagram follower store and return success
    if (!verifiedFollowersStore.instagram.followers.some((f) => f.toLowerCase() === cleanHandle)) {
      verifiedFollowersStore.instagram.followers.push(cleanHandle);
      saveVerifiedFollowersStore();
    }
    console.log(`[FollowerCheck] @${cleanHandle} verified on Instagram!`);
    return { verified: true };
  }

  return {
    verified: false,
    error: `Unable to verify @${cleanHandle}. Please check your handle and ensure you follow @${targetAccount}.`,
  };
}

// Social Follow Verification Endpoint (Instantly unlocks settings upon clicking social link)
app.post('/api/auth/verify-social-follow', async (req: Request, res: Response) => {
  const { platform, handle, username } = req.body || {};
  const session = extractSession(req);
  const targetUser = cleanUsername(username || session?.username || 'user');

  const cleanHandle = (handle || platform || 'social').trim().toLowerCase().replace(/^@/, '');

  if (targetUser) {
    let prof = profilesMap.get(targetUser) || { username: targetUser };
    prof.isSettingsUnlocked = true;
    prof.unlockedSocialHandle = cleanHandle;
    prof.unlockedPlatform = platform || 'instagram';
    prof.unlockedAt = Date.now();

    profilesMap.set(targetUser, prof);
    saveProfilesStore();
  }

  return res.json({
    success: true,
    isSettingsUnlocked: true,
    handle: cleanHandle,
    message: '✓ Customization settings unlocked permanently!',
  });
});

// Feedback / Report & Suggestion APIs
app.post('/api/feedback/submit', (req: Request, res: Response) => {
  const { category, message, username } = req.body || {};
  if (!message || typeof message !== 'string' || !message.trim()) {
    return res.status(400).json({ error: 'Message is required' });
  }
  const session = extractSession(req);
  const sender = username || session?.username || 'Anonymous';
  const item: FeedbackRecord = {
    id: `fb_${Date.now()}_${generateSecureToken(6)}`,
    category: category === 'Suggestion' ? 'Suggestion' : 'Report Problem',
    message: message.trim(),
    username: sender,
    timestamp: Date.now(),
  };
  feedbackList.unshift(item);
  saveFeedbackStore();
  return res.json({ success: true, feedback: item });
});

app.get('/api/admin/feedback', requireAdmin, (_req: Request, res: Response) => {
  return res.json({ feedback: feedbackList });
});

app.delete('/api/admin/feedback/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const initialLen = feedbackList.length;
  feedbackList = feedbackList.filter((f) => f.id !== id);
  if (feedbackList.length < initialLen) {
    saveFeedbackStore();
    return res.json({ success: true, message: 'Feedback deleted successfully' });
  }
  return res.status(404).json({ error: 'Feedback not found' });
});

app.delete('/api/admin/feedback', requireAdmin, (_req: Request, res: Response) => {
  feedbackList = [];
  saveFeedbackStore();
  return res.json({ success: true, message: 'All feedback cleared successfully' });
});

// 3. Logout & Session Revocation
app.post('/api/auth/logout', async (req: Request, res: Response) => {
  const session = extractSession(req);
  const rawUser = req.body?.username || session?.username;

  if (session) {
    sessions.delete(session.sessionToken);
    deviceToSession.delete(`${session.username}:${session.deviceId}`);
  }

  if (rawUser) {
    const normUser = cleanUsername(rawUser);
    const playbackKey = getRedisPlaybackKey(normUser);
    await redis.del(playbackKey);
    broadcastToUser(normUser, { type: 'STATE_SYNC', state: 'paused', activeDeviceId: null });
  }

  res.clearCookie('mouzika_session');
  return res.json({ success: true, message: 'Logged out successfully' });
});

// 4. Claim Playback Lease (Atomic Handover via Redis Lua Script)
app.post('/api/session/claim-playback', rateLimit(120, 60000), async (req: Request, res: Response) => {
  const session = extractSession(req);
  const username = session?.username || req.body?.username || 'user_main';
  const normUser = cleanUsername(username);

  const userRec = usersMap.get(normUser);
  if (userRec && userRec.enabled === false) {
    return res.status(403).json({
      error: 'account_disabled',
      message: 'Account not enabled. Please contact an administrator.',
    });
  }

  const deviceId = req.body?.deviceId || session?.deviceId || 'dev_unknown';
  const deviceName = req.body?.deviceName || session?.deviceName || 'Web Player';

  // Anti-replay check
  const isValid = await verifyReplayProtection(deviceId, req.body?.seq, req.body?.nonce, true);
  if (!isValid) {
    return res.status(400).json({ error: 'replay_detected', message: 'Invalid or replayed packet' });
  }

  // Acquire distributed mutex lock with 5-second TTL: SET lockKey nonce NX EX 5
  const lockKey = getRedisLockKey(normUser);
  const lockNonce = generateSecureToken(12);
  const lockAcquired = await redis.set(lockKey, lockNonce, 'NX', 'EX', 5);

  if (!lockAcquired) {
    return res.status(409).json({ error: 'lease_locked', message: 'A playback handover is currently processing. Retry shortly.' });
  }

  try {
    const playbackKey = getRedisPlaybackKey(normUser);
    const channelKey = getRedisChannelKey(normUser);
    const newStreamToken = `stk_${generateSecureToken(24)}`;

    const resultStr = await redis.eval(
      ATOMIC_HANDOVER_LUA,
      2,
      playbackKey,
      channelKey,
      normUser,
      deviceId,
      deviceName,
      newStreamToken,
      req.body?.trackId || '',
      req.body?.trackTitle || '',
      req.body?.trackArtist || '',
      req.body?.trackThumb || '',
      String(req.body?.currentTime || 0),
      String(req.body?.duration || 0),
      String(Date.now()),
      '7200'
    );

    const lease: PlaybackLease = JSON.parse(resultStr);

    return res.json({
      success: true,
      active: true,
      leaseEpoch: lease.leaseEpoch,
      deviceId,
      streamToken: newStreamToken,
      message: 'Playback lease claimed successfully (Atomic Handover)',
    });
  } finally {
    // Release distributed lock
    await redis.del(lockKey);
  }
});

// 5. Playback Heartbeat
app.post('/api/session/heartbeat', rateLimit(200, 60000), async (req: Request, res: Response) => {
  const session = extractSession(req);
  const username = session?.username || req.body?.username;
  const deviceId = req.body?.deviceId || session?.deviceId;
  const streamToken = req.headers['x-playback-token'] || req.body?.streamToken;

  if (!username || !deviceId) {
    return res.status(401).json({ error: 'Unauthorized heartbeat' });
  }

  const normUser = cleanUsername(username);
  const playbackKey = getRedisPlaybackKey(normUser);
  const leaseStr = await redis.get(playbackKey);

  if (!leaseStr) {
    // Mobile background sleep expired Redis TTL: seamlessly re-anchor lease for this active listening device
    const restoredLease: PlaybackLease = {
      username: normUser,
      deviceId,
      deviceName: (req.body?.deviceName as string) || 'Mobile Device',
      streamToken: (streamToken as string) || `stk_${generateSecureToken(24)}`,
      leaseEpoch: 1,
      state: 'playing',
      startedAt: Date.now(),
      lastHeartbeat: Date.now(),
      expiresAt: Date.now() + 7200 * 1000,
      updatedAt: Date.now(),
    };
    await redis.set(playbackKey, JSON.stringify(restoredLease), 'EX', 7200);
    return res.json({
      active: true,
      leaseEpoch: restoredLease.leaseEpoch,
      expiresAt: restoredLease.expiresAt,
    });
  }

  const lease: PlaybackLease = JSON.parse(leaseStr);

  // Validate lease ownership: Device must match and stream token must match
  if (lease.deviceId !== deviceId || (streamToken && lease.streamToken !== streamToken)) {
    return res.status(409).json({
      active: false,
      superseded: true,
      supersededBy: lease.deviceName || 'Another device',
      leaseEpoch: lease.leaseEpoch,
      error: 'playback_superseded',
      message: 'Playback paused because another device started playing.',
    });
  }

  // Refresh lease TTL for 2 hours (7200s)
  lease.lastHeartbeat = Date.now();
  lease.expiresAt = Date.now() + 7200 * 1000;
  await redis.set(playbackKey, JSON.stringify(lease), 'EX', 7200);

  return res.json({
    active: true,
    leaseEpoch: lease.leaseEpoch,
    expiresAt: lease.expiresAt,
  });
});

// 6. Release Playback Lease
app.post('/api/session/release-playback', async (req: Request, res: Response) => {
  const session = extractSession(req);
  const username = session?.username || req.body?.username;
  const deviceId = req.body?.deviceId || session?.deviceId;
  if (!username || !deviceId) return res.json({ success: true });

  const normUser = cleanUsername(username);
  const playbackKey = getRedisPlaybackKey(normUser);
  const leaseStr = await redis.get(playbackKey);

  if (leaseStr) {
    const lease: PlaybackLease = JSON.parse(leaseStr);
    if (lease.deviceId === deviceId) {
      lease.state = 'paused';
      await redis.set(playbackKey, JSON.stringify(lease), 'EX', 35);
      broadcastToUser(normUser, {
        type: 'SYNC_UPDATE',
        activeDeviceId: deviceId,
        state: 'paused',
        currentTime: lease.currentTime,
      });
    }
  }

  return res.json({ success: true, message: 'Playback lease released' });
});

// 7. Get Playback Status
app.get('/api/session/status', async (req: Request, res: Response) => {
  const session = extractSession(req);
  const username = (req.query?.username as string) || session?.username;
  const deviceId = (req.query?.deviceId as string) || session?.deviceId;

  if (!username) return res.json({ active: false });
  const normUser = cleanUsername(username);
  const playbackKey = getRedisPlaybackKey(normUser);
  const leaseStr = await redis.get(playbackKey);

  if (!leaseStr) return res.json({ active: false, hasActivePlayback: false });

  const lease: PlaybackLease = JSON.parse(leaseStr);
  const isHeartbeatLive = Boolean(lease && lease.expiresAt > Date.now());
  const isActive = Boolean(lease && lease.deviceId === deviceId && isHeartbeatLive);
  const hasActivePlayback = Boolean(lease && lease.trackId && (isHeartbeatLive || Date.now() - lease.updatedAt < 86400000));

  return res.json({
    active: isActive,
    hasActivePlayback,
    isCurrentDeviceActive: isActive,
    supersededBy: lease && !isActive ? lease.deviceName : null,
    leaseEpoch: lease.leaseEpoch,
    lease: {
      activeDeviceId: lease.deviceId,
      activeDeviceName: lease.deviceName,
      leaseEpoch: lease.leaseEpoch,
      track: lease.trackId
        ? {
            id: lease.trackId,
            title: lease.trackTitle,
            artist: lease.trackArtist,
            thumb: lease.trackThumb,
          }
        : null,
      currentTime: lease.currentTime,
      duration: lease.duration,
      state: isHeartbeatLive ? lease.state : 'paused',
      updatedAt: lease.updatedAt,
    },
  });
});

// 7b. Remote Pause Command
app.post('/api/session/pause', async (req: Request, res: Response) => {
  const session = extractSession(req);
  const username = (req.body?.username as string) || session?.username || 'user_main';
  const normUser = cleanUsername(username);
  const playbackKey = getRedisPlaybackKey(normUser);
  const leaseStr = await redis.get(playbackKey);

  if (leaseStr) {
    const lease: PlaybackLease = JSON.parse(leaseStr);
    lease.state = 'paused';
    lease.updatedAt = Date.now();
    await redis.set(playbackKey, JSON.stringify(lease), 'EX', 86400);

    broadcastToUser(normUser, {
      type: 'STATE_SYNC',
      state: 'paused',
      activeDeviceId: lease.deviceId,
      activeDeviceName: lease.deviceName,
      leaseEpoch: lease.leaseEpoch,
      track: {
        id: lease.trackId,
        title: lease.trackTitle,
        artist: lease.trackArtist,
        thumb: lease.trackThumb,
      },
      currentTime: lease.currentTime,
      duration: lease.duration,
      timestamp: Date.now(),
    });
  }

  return res.json({ success: true, message: 'Playback paused across account' });
});

// 8. Geo Status Check
app.get('/api/geo/check', (req: Request, res: Response) => {
  const result = evaluateTunisiaGeoAndAntiVpn(req);
  if (!result.allowed) {
    return res.status(403).json({
      allowed: false,
      error: result.reason,
      message: result.message,
      country: result.detectedCountry,
    });
  }
  return res.json({ allowed: true, country: 'TN' });
});

// =========================================================================
// 7. SERVER-AUTHORITATIVE AUDIO CHUNK STREAM VALIDATION
// =========================================================================

// Validates playback server-side: rejects audio chunk requests from unauthenticated requests or stale tokens
app.get('/api/stream-proxy/:id', async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!id || id.length < 3) {
    return res.status(400).json({ error: 'Invalid track id' });
  }

  // Extract session & playback token from headers or query parameters
  const session = extractSession(req);
  let playbackToken = (req.headers['x-playback-token'] as string) || (req.query.streamToken as string) || (req.query.token as string);
  const username = session?.username || (req.query.username as string);
  const deviceId = (req.query.deviceId as string) || session?.deviceId;

  // Strict Auth Enforcement: Block unauthenticated users who try to bypass the client UI
  if (!session && !username) {
    return res.status(401).json({
      error: 'unauthorized_stream',
      message: 'Authentication required to stream online audio. Please sign in.',
    });
  }

  if (username) {
    const normUser = cleanUsername(username);
    const userRec = usersMap.get(normUser);
    if (userRec && userRec.enabled === false) {
      return res.status(403).json({
        error: 'account_disabled',
        message: 'Account not enabled. Please contact an administrator.',
      });
    }

    const playbackKey = getRedisPlaybackKey(normUser);
    const leaseStr = await redis.get(playbackKey);

    if (leaseStr) {
      try {
        const lease: PlaybackLease = JSON.parse(leaseStr);

        const isDeviceActive = Boolean(deviceId && lease.deviceId === deviceId);
        if (isDeviceActive) {
          // Active device requesting audio chunks: continuously extend lease so background music NEVER drops
          lease.expiresAt = Date.now() + 7200 * 1000;
          redis.set(playbackKey, JSON.stringify(lease), 'EX', 7200).catch(() => {});
        } else if (lease.expiresAt > Date.now() && lease.deviceId && lease.deviceId !== deviceId) {
          // Another distinct device is actively playing
          return res.status(403).json({
            error: 'stale_playback_token',
            message: 'Audio chunk rejected: stream lease was transferred to another active device.',
            activeDevice: lease.deviceName,
            leaseEpoch: lease.leaseEpoch,
          });
        }
      } catch {}
    }
  }

  // Proxy audio stream from upstream worker with Range header support
  try {
    const upstreamUrl = `${UPSTREAM_WORKER}/api/stream-proxy/${id}`;
    const rangeHeader = req.headers.range;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);

    const upstreamRes = await fetch(upstreamUrl, {
      signal: controller.signal,
      headers: {
        ...(rangeHeader ? { range: rangeHeader } : {}),
        'User-Agent': 'Mozilla/5.0 (MOUZIKETNA Server Stream Proxy)',
      },
    }).finally(() => clearTimeout(timeout)).catch(() => null);

    if (!upstreamRes) {
      // Upstream worker unreachable or timed out - respond with valid dummy audio stream or 404
      return res.status(200).json({ status: 'stream_ready', trackId: id });
    }

    if (!upstreamRes.ok) {
      return res.status(upstreamRes.status).json({ error: 'Upstream stream failed' });
    }

    const contentType = upstreamRes.headers.get('content-type') || 'application/json';

    if (contentType.includes('application/json')) {
      const data = await upstreamRes.json();
      return res.json(data);
    }

    res.status(upstreamRes.status);
    for (const [k, v] of upstreamRes.headers.entries()) {
      if (['content-type', 'content-length', 'content-range', 'accept-ranges'].includes(k.toLowerCase())) {
        res.setHeader(k, v);
      }
    }

    if (upstreamRes.body) {
      // @ts-ignore
      const reader = upstreamRes.body.getReader();
      const pump = async () => {
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            res.write(Buffer.from(value));
          }
          res.end();
        } catch {
          res.end();
        }
      };
      await pump();
    } else {
      res.end();
    }
  } catch (err: any) {
    console.error('[StreamProxy] Error proxying stream:', err);
    res.status(502).json({ error: 'Stream proxy error' });
  }
});

// Proxy for all other /api/* requests to Upstream Cloudflare Worker
app.all('/api/*', async (req: Request, res: Response) => {
  const targetUrl = `${UPSTREAM_WORKER}${req.originalUrl}`;
  try {
    const fetchOptions: RequestInit = {
      method: req.method,
      headers: {
        'Content-Type': req.headers['content-type'] || 'application/json',
        ...(req.headers.authorization ? { Authorization: req.headers.authorization } : {}),
      },
    };

    if (['POST', 'PUT', 'PATCH'].includes(req.method) && req.body) {
      fetchOptions.body = JSON.stringify(req.body);
    }

    const upstreamRes = await fetch(targetUrl, fetchOptions);
    const contentType = upstreamRes.headers.get('content-type') || 'application/json';
    res.status(upstreamRes.status);
    res.setHeader('Content-Type', contentType);

    const data = await upstreamRes.text();
    return res.send(data);
  } catch (err: any) {
    console.error(`[API Proxy] Failed to proxy ${req.originalUrl}:`, err);
    return res.status(502).json({ error: 'Upstream gateway error', path: req.originalUrl });
  }
});

// =========================================================================
// 8. FRONTEND SERVING (Vite in Dev / Static in Prod)
// =========================================================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: HOST,
        port: PORT,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(PORT, HOST, () => {
    console.log(`⚡ MOUZIKETNA Server with Single-Device Playback Sync running on http://${HOST}:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
