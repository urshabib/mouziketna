import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { ArtistPlayStat, CustomPlaylist, DownloadRecord, LyricsData, NavigationPane, Track, UserProfile, UserStats } from '../types';
import { getTranslation, Language } from '../services/i18n';
import {
  NEW_HUB_BACKEND,
  cleanArtistName,
  cleanTitleForLyrics,
  deriveArtistForLyrics,
  fetchLyricsForTrack,
  fetchWithTimeout,
  getCachedStreamUrl,
  cacheStreamUrl,
  prefetchTrackStream,
  resolveMirrorStreams,
  resolveSaavnStream,
  resolveWorkerStream,
  canonicalThumbUrl,
  fetchArtworkBlob,
  FALLBACK_ART,
  fetchJsonRetry,
  normalizeTrack,
  searchTracks,
  getRelatedTracks,
  getTasteProfileRecommendations,
  verifySocialFollow,
} from '../services/api';
import {
  cacheProfileLocally,
  deleteDownload,
  deleteAllDownloads,
  downloadedIds,
  downloadedQualityMap,
  getDownloadQuality,
  ensurePersistentStorageOnce,
  formatBytes,
  getDownload,
  getDownloadedLyrics,
  saveDownloadLyrics,
  initDownloadsRegistry,
  isDownloaded,
  listDownloads,
  loadDeviceSettings,
  loadProgressBarStyle,
  saveProgressBarStyle,
  loadTasteProfile,
  rememberListen,
  restoreProfileFromCache,
  saveGuestProfile,
  restoreGuestProfile,
  clearGuestProfile,
  mergeProfilesSafely,
  extractStatsFromProfile,
  saveDeviceSettings,
  saveDownload,
  tasteArtistKey,
  tasteArtistScore,
  tasteEvent,
  tasteSkippedArtists,
  tasteTopSeeds,
  addExplicitInterested,
  removeExplicitInterested,
  addExplicitNotInterested,
  removeExplicitNotInterested,
  isExplicitInterested,
  isExplicitNotInterested,
  getExplicitInterestedTracks,
  getExplicitNotInterestedTracks,
  getStoredCoverForTrack,
  getOfflineThumbUrlSync,
  downloadsRegistryReady,
} from '../services/storage';
import { ensureAudioGraph, setBaseAudioVolume, resumeAudioContext, isAudioGraphNeeded, isMobileDevice } from '../services/audioEnhancer';
import { sessionManager, SupersededEvent } from '../services/sessionManager';

interface Toast {
  id: string;
  message: string;
  isGray?: boolean;
}

interface MusicContextType {
  // Navigation
  activePane: NavigationPane;
  setActivePane: (pane: NavigationPane) => void;
  collectionTarget: { type: 'liked' | 'downloads' | 'custom-playlist' | 'artist' | 'playlist'; id?: string | null; title?: string; thumb?: string | null; initialTracks?: Track[] } | null;
  openCollection: (type: 'liked' | 'downloads' | 'custom-playlist' | 'artist' | 'playlist', id?: string | null, title?: string, thumb?: string | null, initialTracks?: Track[]) => void;
  goBack: () => void;

  // Profile & Auth
  globalUser: string | null;
  globalPass: string | null;
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  login: (user: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  syncProfile: (updatedProfile?: UserProfile) => void;
  isAuthGateOpen: boolean;
  setIsAuthGateOpen: (open: boolean) => void;
  isAccountSettingsOpen: boolean;
  setIsAccountSettingsOpen: (open: boolean) => void;
  isAccountDisabledModalOpen: boolean;
  setIsAccountDisabledModalOpen: (open: boolean) => void;
  updateUserPassword: (currentPass: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  updateUserEmail: (newEmail: string) => Promise<{ success: boolean; error?: string }>;
  adminResetUserPassword: (targetUsername: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  isSettingsUnlocked: boolean;
  unlockSettingsWithSocial: (platform: 'instagram' | 'tiktok', handle: string) => Promise<{ success: boolean; error?: string }>;

  // Playback
  activeTrack: Track | null;
  isPlaying: boolean;
  isBuffering: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isLooping: boolean;
  isShuffle: boolean;
  playbackQueue: Track[];
  queueIndex: number;
  playTrack: (track: Track, fromQueue?: boolean) => Promise<boolean>;
  togglePlay: () => void;
  seekTo: (time: number) => void;
  seekBy: (delta: number) => void;
  setVolumeLevel: (vol: number) => void;
  toggleMute: () => void;
  toggleLoop: () => void;
  toggleShuffle: () => void;
  playNext: () => void;
  playPrevious: () => void;
  addToQueue: (track: Track, playNext?: boolean) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
  playQueueIndex: (index: number) => void;
  playWholeCollection: (tracks: Track[]) => void;
  playShuffledCollection: (tracks: Track[]) => void;
  playCollectionFromIndex: (tracks: Track[], index: number) => void;

  // Overlays & Sheets
  isFullScreenOpen: boolean;
  setIsFullScreenOpen: (open: boolean) => void;
  isMiniPlayerDismissed: boolean;
  setIsMiniPlayerDismissed: (dismissed: boolean) => void;
  dismissMiniPlayer: () => void;
  isLandscapeStageOpen: boolean;
  setIsLandscapeStageOpen: (open: boolean) => void;
  isLyricsOpen: boolean;
  setIsLyricsOpen: (open: boolean) => void;
  isQueueOpen: boolean;
  setIsQueueOpen: (open: boolean) => void;
  actionSheetTrack: Track | null;
  setActionSheetTrack: (track: Track | null) => void;
  actionSheetMeta: { collectionId?: string } | null;
  setActionSheetMeta: (meta: { collectionId?: string } | null) => void;

  // Modals
  modalCreatePlaylistOpen: boolean;
  setModalCreatePlaylistOpen: (open: boolean) => void;
  modalAddToPlaylistTrack: Track | null;
  setModalAddToPlaylistTrack: (track: Track | null) => void;
  modalImportPlaylistOpen: boolean;
  setModalImportPlaylistOpen: (open: boolean) => void;
  modalAddSongByLinkPlId: string | null;
  setModalAddSongByLinkPlId: (id: string | null) => void;
  modalAudioRecognitionOpen: boolean;
  setModalAudioRecognitionOpen: (open: boolean) => void;
  modalConfirm: { title: string; text: string; onConfirm: () => void } | null;
  setModalConfirm: (conf: { title: string; text: string; onConfirm: () => void } | null) => void;
  isInstallModalOpen: boolean;
  setIsInstallModalOpen: (open: boolean) => void;

  // Internationalization & Language
  t: (key: string, fallback?: string) => string;
  language: Language;
  setLanguage: (lang: Language) => void;

  // Music Taste Tuning
  tuneMusicTaste: (track: Track, direction: 'more' | 'less') => void;
  removeTrackFromTaste: (trackId: string) => void;
  isTuneInterested: (trackId: string) => boolean;
  isTuneDisliked: (trackId: string) => boolean;
  getInterestedTracks: () => Track[];
  getNotInterestedTracks: () => Track[];

  // Listening Stats & Hidden Songs
  hideSongFromStats: (songId: string) => void;
  unhideSongFromStats: (songId: string) => void;

  // Cloud Sync
  forceProfileServerSync: (forcedProfile?: UserProfile) => Promise<boolean>;
  clearListeningStats: () => Promise<boolean>;
  isSyncingToServer: boolean;
  lastServerSyncTime: number | null;

  // Downloads
  downloadedSet: Set<string>;
  downloadQualityMap: Map<string, string>;
  downloadTrack: (track: Track, silent?: boolean, isAutoCache?: boolean) => Promise<boolean>;
  removeDownload: (trackId: string) => Promise<void>;
  removeMultipleDownloads: (trackIds: string[]) => Promise<void>;
  clearAllDownloads: () => Promise<void>;
  downloadPlaylist: (tracks: Track[]) => Promise<void>;
  bulkDownloadState: { done: number; total: number; inProgress: boolean };

  // Lyrics
  currentLyrics: LyricsData;
  retryLyrics: () => void;

  // Sleep Timer
  sleepTimerRemaining: number | null; // seconds
  sleepTimerIsEndOfSong: boolean;
  setSleepTimerMinutes: (mins: number) => void;
  setSleepTimerEndOfSong: () => void;
  cancelSleepTimer: () => void;

  // Toast
  showToast: (msg: string, isGray?: boolean) => void;
  toasts: Toast[];

  // Likes & Playlists
  toggleLikeTrack: (track: Track) => void;
  createPlaylist: (name: string, firstTrack?: Track) => void;
  renamePlaylist: (plId: string, newName: string) => void;
  deletePlaylist: (plId: string) => void;
  removeTrackFromPlaylist: (plId: string, trackId: string) => void;
  addTrackToPlaylist: (plId: string, track: Track) => void;
  updatePlaylistTracks: (plId: string, newTracks: Track[]) => void;
  addMultipleTracksToPlaylist: (plId: string, tracks: Track[]) => void;

  // Single-Device Playback Sessions (Spotify Connect style)
  supersededNotice: SupersededEvent | null;
  setSupersededNotice: (notice: SupersededEvent | null) => void;
  claimPlaybackHere: () => Promise<void>;
  currentDeviceName: string;
  isRemotePlaybackActive: boolean;
  remoteDeviceName: string | null;
}

const MusicContext = createContext<MusicContextType | null>(null);

const defaultProfile: UserProfile = {
  username: '',
  likedSongs: [],
  customPlaylists: [],
  favouriteArtists: [],
  favouriteAlbums: [],
  recentlyPlayed: [],
  dataSaver: false,
  dataSaverLevel: 'off',
  downloadQuality: 'stable',
  autoCacheQuality: 'stable',
  customAppName: 'MOUZIKETNA',
  appLogo: 'default',
  downloadLyricsOffline: true,
  downloadArtOffline: true,
  artQualityOffline: 'low',
  autoCachePlayed: false,
  liquidGlass: true,
  language: 'en',
  theme: 'dark',
  accentColor: 'orange',
  lyricsColor: 'white',
  lyricsGlow: 'default',
  keyPartsDisplay: 'dots',
  progressBarStyle: 'default',
  presetTint: 'none',
  uiScale: 'default',
  activePreset: 'glass',
  avatarUrl: null,
  displayName: '',
};

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePane, setActivePane] = useState<NavigationPane>(() => {
    try {
      if (sessionStorage.getItem('mouzika_restore_after_logo')) {
        return 'settings';
      }
    } catch {}
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return 'offline';
    }
    return 'home';
  });
  const [navHistory, setNavHistory] = useState<NavigationPane[]>(['home']);
  const [collectionTarget, setCollectionTarget] = useState<MusicContextType['collectionTarget']>(null);

  const [globalUser, setGlobalUser] = useState<string | null>(() => {
    try {
      return localStorage.getItem('hub_active_user') || null;
    } catch {
      return null;
    }
  });
  const [globalPass, setGlobalPass] = useState<string | null>(() => {
    try {
      return localStorage.getItem('hub_active_pass') || null;
    } catch {
      return null;
    }
  });
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const dev = loadDeviceSettings();
    let savedUser = null;
    try {
      savedUser = localStorage.getItem('hub_active_user');
    } catch {}
    const cached = savedUser ? restoreProfileFromCache(savedUser) : null;
    const guest = !savedUser ? restoreGuestProfile() : null;
    const isCachedMatch = Boolean(savedUser && cached && (!cached.username || cached.username.toLowerCase() === savedUser.toLowerCase()));
    return {
      ...defaultProfile,
      ...(guest || {}),
      ...(isCachedMatch ? cached : {}),
      ...(dev || {}),
      username: savedUser || '',
      displayName: (isCachedMatch && cached?.displayName) ? cached.displayName : (guest?.displayName || savedUser || ''),
      avatarUrl: (isCachedMatch && cached?.avatarUrl !== undefined) ? cached.avatarUrl : (guest?.avatarUrl !== undefined ? guest.avatarUrl : null),
    };
  });
  const [isAuthGateOpen, setIsAuthGateOpen] = useState(false);
  const [isAccountSettingsOpen, setIsAccountSettingsOpen] = useState(false);
  const [isAccountDisabledModalOpen, setIsAccountDisabledModalOpen] = useState(false);

  // Single-Device Playback Supersession Notice & Cross-Device Sync State
  const [supersededNotice, setSupersededNotice] = useState<SupersededEvent | null>(null);
  const [isRemotePlaybackActive, setIsRemotePlaybackActive] = useState(false);
  const [remoteDeviceName, setRemoteDeviceName] = useState<string | null>(null);
  const currentDeviceName = sessionManager.getDeviceName();

  const syncAccountPlaybackState = useCallback(async () => {
    try {
      const data = await sessionManager.getSessionStatus();
      if (data && data.hasActivePlayback && data.lease?.track) {
        const myDeviceId = sessionManager.getDeviceId();
        const isRemote = data.lease.activeDeviceId !== myDeviceId;
        if (isRemote) {
          setIsRemotePlaybackActive(true);
          setRemoteDeviceName(data.lease.activeDeviceName || 'another device');
          setActiveTrack(data.lease.track);
          setCurrentTime(data.lease.currentTime || 0);
          setDuration(data.lease.duration || 0);
          setIsPlaying(data.lease.state === 'playing');
          if (audioRef.current && !audioRef.current.paused) {
            audioRef.current.pause();
          }
        }
      }
    } catch {}
  }, []);

  // Multi-device playback synchronization listener
  useEffect(() => {
    // Unrestricted multi-device playback
  }, []);

  // Synchronize playback when user account changes
  useEffect(() => {
    // Multi-device playback is fully unrestricted across devices
  }, [globalUser]);

  // Playback state
  const [activeTrack, setActiveTrack] = useState<Track | null>(() => {
    try {
      const saved = localStorage.getItem('mouzika_last_played_track');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id && parsed.title) {
          // If parsed.thumb is missing, empty, generic fallback, or an expired blob URL, recover the persistent cover
          if (
            !parsed.thumb ||
            parsed.thumb.startsWith('blob:') ||
            parsed.thumb.trim().length <= 5 ||
            parsed.thumb === FALLBACK_ART
          ) {
            const recovered = getStoredCoverForTrack(parsed.id);
            if (recovered && !recovered.startsWith('blob:') && recovered !== FALLBACK_ART) {
              parsed.thumb = recovered;
            } else if (parsed.id.length === 11) {
              parsed.thumb = `https://i.ytimg.com/vi/${parsed.id}/hqdefault.jpg`;
            } else {
              parsed.thumb = canonicalThumbUrl(parsed.id);
            }
            try {
              localStorage.setItem('mouzika_last_played_track', JSON.stringify(parsed));
            } catch {}
          }
          return parsed;
        }
      }
    } catch {}
    return null;
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);
  const [currentTime, setCurrentTime] = useState(() => {
    try {
      const savedPos = localStorage.getItem('mouzika_last_played_pos');
      if (savedPos && !isNaN(Number(savedPos))) {
        return Math.max(0, Number(savedPos));
      }
    } catch {}
    return 0;
  });
  const [duration, setDuration] = useState(() => {
    try {
      const saved = localStorage.getItem('mouzika_last_played_track');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.duration) return parsed.duration;
      }
    } catch {}
    return 0;
  });
  const [isMiniPlayerDismissed, setIsMiniPlayerDismissed] = useState(false);
  const dismissMiniPlayer = useCallback(() => {
    setIsMiniPlayerDismissed(true);
  }, []);

  // Ensure activeTrack cover and metadata remain synchronized with recentlyPlayed and offline downloads
  useEffect(() => {
    if (!activeTrack || !activeTrack.id) return;
    const match = userProfile.recentlyPlayed?.find((t) => t.id === activeTrack.id) ||
                  userProfile.likedSongs?.find((t) => t.id === activeTrack.id);
    if (match?.thumb && !match.thumb.startsWith('blob:') && match.thumb.trim().length > 5 && match.thumb !== FALLBACK_ART) {
      if (match.thumb !== activeTrack.thumb || !activeTrack.thumb || activeTrack.thumb === FALLBACK_ART) {
        setActiveTrack((prev) => {
          if (!prev || prev.id !== activeTrack.id) return prev;
          const updated = { ...prev, thumb: match.thumb };
          try {
            localStorage.setItem('mouzika_last_played_track', JSON.stringify(updated));
          } catch {}
          return updated;
        });
      }
    }
  }, [userProfile.recentlyPlayed, userProfile.likedSongs, activeTrack?.id, activeTrack?.thumb]);

  useEffect(() => {
    downloadsRegistryReady.then(() => {
      if (!activeTrack || !activeTrack.id) return;
      const offThumb = getOfflineThumbUrlSync(activeTrack.id);
      if (offThumb && (!activeTrack.thumb || activeTrack.thumb.startsWith('blob:'))) {
        setActiveTrack((prev) => (prev ? { ...prev, thumb: offThumb } : prev));
      }
    });
  }, [activeTrack?.id]);
  const [volume, setVolume] = useState(() => {
    try {
      return Number(localStorage.getItem('hub_volume') ?? 50);
    } catch {
      return 50;
    }
  });
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [playbackQueue, setPlaybackQueue] = useState<Track[]>([]);
  const [queueIndex, setQueueIndex] = useState(-1);

  // Audio elements & Synchronized Refs to avoid stale closures
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const prefetchAudioRef = useRef<HTMLAudioElement | null>(null);
  const carrierAudioRef = useRef<HTMLAudioElement | null>(null);
  const activeBlobUrlRef = useRef<string | null>(null);
  const playTokenRef = useRef(0);
  const hasPrefetchedNextRef = useRef(false);
  const playedHistoryRef = useRef<Track[]>([]);

  const playbackQueueRef = useRef<Track[]>([]);
  const queueIndexRef = useRef(-1);
  const activeTrackRef = useRef<Track | null>(null);
  const isShuffleRef = useRef(false);
  const isLoopingRef = useRef(false);
  const playTrackRef = useRef<((t: Track, isRetry?: boolean) => Promise<boolean>) | null>(null);
  const playNextRef = useRef<() => Promise<void>>(() => Promise.resolve());
  const playPreviousRef = useRef<() => void>(() => {});
  const seekDebounceTimerRef = useRef<number | null>(null);
  const isSeekingRef = useRef(false);
  const lastSeekTimestampRef = useRef<number>(0);
  const volumeRef = useRef<number>(volume);
  const lastTrackTransitionTimeRef = useRef<number>(0);
  const hasNudgedTransitionRef = useRef<boolean>(false);

  // Overlays
  const [isFullScreenOpen, setIsFullScreenOpen] = useState(false);
  const [isLandscapeStageOpen, setIsLandscapeStageOpen] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [actionSheetTrack, setActionSheetTrack] = useState<Track | null>(null);
  const [actionSheetMeta, setActionSheetMeta] = useState<{ collectionId?: string } | null>(null);

  // Modals
  const [modalCreatePlaylistOpen, setModalCreatePlaylistOpen] = useState(false);
  const [modalAddToPlaylistTrack, setModalAddToPlaylistTrack] = useState<Track | null>(null);
  const [modalImportPlaylistOpen, setModalImportPlaylistOpen] = useState(false);
  const [modalAddSongByLinkPlId, setModalAddSongByLinkPlId] = useState<string | null>(null);
  const [modalAudioRecognitionOpen, setModalAudioRecognitionOpen] = useState(false);
  const [modalConfirm, setModalConfirm] = useState<{ title: string; text: string; onConfirm: () => void } | null>(null);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(() => {
    try {
      if (sessionStorage.getItem('mouzika_restore_install_modal')) {
        sessionStorage.removeItem('mouzika_restore_install_modal');
        return true;
      }
    } catch {}
    return false;
  });

  const language = (userProfile.language || 'en') as Language;
  const t = useCallback(
    (key: string, fallback?: string): string => {
      return getTranslation(userProfile.language || 'en', key, fallback);
    },
    [userProfile.language]
  );

  // Cloudflare Batch & Quota-Protected Server Syncing
  const [isSyncingToServer, setIsSyncingToServer] = useState(false);
  const [lastServerSyncTime, setLastServerSyncTime] = useState<number | null>(() => {
    try {
      const saved = localStorage.getItem('mouzika_last_server_sync_time');
      return saved ? Number(saved) : null;
    } catch {
      return null;
    }
  });

  const pendingSyncProfRef = useRef<UserProfile | null>(null);
  const isSyncDirtyRef = useRef(false);
  const lastServerSyncTimestampRef = useRef<number>(0);

  const flushProfileToServer = useCallback(
    async (forcedProfile?: UserProfile): Promise<boolean> => {
      const profToSync = forcedProfile || pendingSyncProfRef.current || userProfile;
      if (!globalUser || globalUser === 'admin') return false;

      // Ensure local cache has the most recent changes immediately
      cacheProfileLocally(globalUser, profToSync);

      try {
        setIsSyncingToServer(true);
        const now = Date.now();
        lastServerSyncTimestampRef.current = now;
        setLastServerSyncTime(now);
        try {
          localStorage.setItem('mouzika_last_server_sync_time', String(now));
        } catch {}

        const activeStats = extractStatsFromProfile({
          ...userProfile,
          ...profToSync,
          favouriteAlbums: profToSync.favouriteAlbums || userProfile.favouriteAlbums,
        });

        const explicitInterested = getExplicitInterestedTracks();
        const explicitNotInterested = getExplicitNotInterestedTracks();
        const activePassword = (profToSync.password && profToSync.password !== 'mouzika')
          ? profToSync.password
          : ((userProfile.password && userProfile.password !== 'mouzika') ? userProfile.password : undefined);

        // System record embedded inside favouriteAlbums:
        // Cloudflare Worker whitelist preserves favouriteAlbums completely across devices!
        // Storing displayName & avatarUrl here guarantees server persistence across accounts and devices
        const cloudStatsRecord: any = {
          id: '__mouzika_cloud_stats_v1__',
          title: '__mouzika_cloud_stats__',
          type: 'system_stats',
          displayName: profToSync.displayName || profToSync.username || globalUser,
          avatarUrl: profToSync.avatarUrl !== undefined ? profToSync.avatarUrl : null,
          email: profToSync.email !== undefined ? profToSync.email : null,
          password: activePassword || null,
          stats: activeStats,
          explicitInterested,
          explicitNotInterested,
          updatedAt: now,
        };

        const rawAlbums = (profToSync.favouriteAlbums || userProfile.favouriteAlbums || []).filter(
          (a: any) => a && a.id !== '__mouzika_cloud_stats_v1__' && a.id !== '__mouzika_cloud_profile_v1__'
        );

        // Full consolidated profile payload with listening stats and explicit music taste
        const savedLang = (profToSync.language || localStorage.getItem('mouzika_app_language') || userProfile.language || 'en') as Language;
        const payload = {
          ...profToSync,
          username: globalUser,
          ...(activePassword ? { password: activePassword } : {}),
          displayName: profToSync.displayName || profToSync.username || globalUser,
          avatarUrl: profToSync.avatarUrl !== undefined ? profToSync.avatarUrl : null,
          email: profToSync.email !== undefined ? profToSync.email : null,
          language: savedLang,
          liquidGlass: profToSync.liquidGlass !== undefined ? profToSync.liquidGlass : true,
          liquidGlassLevel: profToSync.liquidGlassLevel || 'medium',
          stats: activeStats,
          favouriteAlbums: [...rawAlbums, cloudStatsRecord],
          explicitInterested,
          explicitNotInterested,
        };

        const res = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/save-profile`, 8000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (res.ok) {
          isSyncDirtyRef.current = false;
          pendingSyncProfRef.current = null;
          return true;
        }
        return false;
      } catch (err) {
        // Retained safely in localStorage cache to retry later
        return false;
      } finally {
        setIsSyncingToServer(false);
      }
    },
    [globalUser, userProfile]
  );

  const setLanguage = useCallback(
    (lang: Language) => {
      try {
        localStorage.setItem('mouzika_app_language', lang);
      } catch {}
      setUserProfile((prev) => {
        const updated = { ...prev, language: lang };
        saveDeviceSettings({ ...updated, language: lang });
        document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
        document.documentElement.setAttribute('lang', lang);
        if (globalUser && globalUser !== 'admin') {
          cacheProfileLocally(globalUser, updated);
          pendingSyncProfRef.current = updated;
          isSyncDirtyRef.current = true;
          flushProfileToServer(updated);
        }
        return updated;
      });
    },
    [globalUser, flushProfileToServer]
  );

  // Periodic Background Batch Sync:
  // Runs every 5 minutes, checking if local changes are dirty (Quota-efficient)
  useEffect(() => {
    const PERIODIC_SYNC_INTERVAL = 5 * 60 * 1000;
    const intervalId = setInterval(() => {
      if (isSyncDirtyRef.current && globalUser && globalUser !== 'admin') {
        flushProfileToServer();
      }
    }, PERIODIC_SYNC_INTERVAL);

    return () => clearInterval(intervalId);
  }, [globalUser, flushProfileToServer]);

  // Flush pending changes when user switches away, minimizes app, or closes window
  useEffect(() => {
    const handleFlushOnLeave = () => {
      if (audioRef.current && audioRef.current.currentTime >= 0) {
        try {
          localStorage.setItem('mouzika_last_played_pos', String(Math.floor(audioRef.current.currentTime)));
        } catch {}
      }
      if (activeTrack) {
        try {
          const safeThumb = (activeTrack.thumb && !activeTrack.thumb.startsWith('blob:') && activeTrack.thumb.trim().length > 5 && activeTrack.thumb !== FALLBACK_ART)
            ? activeTrack.thumb
            : (getStoredCoverForTrack(activeTrack.id) || (activeTrack.id.length === 11 ? `https://i.ytimg.com/vi/${activeTrack.id}/hqdefault.jpg` : canonicalThumbUrl(activeTrack.id)));
          const safePersistent = { ...activeTrack, thumb: safeThumb };
          localStorage.setItem('mouzika_last_played_track', JSON.stringify(safePersistent));
        } catch {}
      }
      if (isSyncDirtyRef.current && globalUser && globalUser !== 'admin') {
        flushProfileToServer();
      }
    };
    window.addEventListener('beforeunload', handleFlushOnLeave);
    const handleVis = () => {
      if (document.visibilityState === 'hidden') {
        handleFlushOnLeave();
      }
    };
    document.addEventListener('visibilitychange', handleVis);
    return () => {
      window.removeEventListener('beforeunload', handleFlushOnLeave);
      document.removeEventListener('visibilitychange', handleVis);
    };
  }, [globalUser, flushProfileToServer]);

  // Downloads
  const [downloadedSet, setDownloadedSet] = useState<Set<string>>(new Set());
  const [bulkDownloadState, setBulkDownloadState] = useState({ done: 0, total: 0, inProgress: false });

  // Lyrics
  const [currentLyrics, setCurrentLyrics] = useState<LyricsData>({ mode: 'none' });

  // Sleep Timer
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);
  const [sleepTimerIsEndOfSong, setSleepTimerIsEndOfSong] = useState(false);
  const sleepTimerIdRef = useRef<any>(null);

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: string, isGray = false) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, isGray }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 1800);
  }, []);

  // WakeLock & Audio Session Management
  const wakeLockRef = useRef<any>(null);
  const requestWakeLock = async () => {
    try {
      if ('wakeLock' in navigator && (navigator as any).wakeLock?.request) {
        if (!wakeLockRef.current) {
          wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        }
      }
    } catch {}
  };
  const releaseWakeLock = async () => {
    try {
      if (wakeLockRef.current) {
        await wakeLockRef.current.release();
        wakeLockRef.current = null;
      }
    } catch {}
  };

  // Continuous Background Audio Continuity & Watchdog (Android & iOS)
  const userIntentPlayingRef = useRef<boolean>(false);
  const isLoadingTrackRef = useRef<boolean>(false);
  const silentLoopUrlRef = useRef<string | null>(null);

  // Synchronous Pre-buffered Handoff for Android 17 / One UI 9 & iOS
  interface PreloadedNext {
    track: Track;
    url: string;
    isBlob: boolean;
  }
  const preloadedNextRef = useRef<PreloadedNext | null>(null);
  const isPreloadingNextRef = useRef<boolean>(false);

  // Generate a valid 1-second 8kHz mono 8-bit PCM silent WAV blob for unbroken background continuity
  // Generate a valid 1-second 8kHz mono 8-bit PCM silent WAV blob with 1-bit dither
  // The subtle +/- 1 LSB dither is completely inaudible (-48dBFS down at 1% volume),
  // but registers as active PCM frames to Car Bluetooth DSP amplifiers and noise gates,
  // preventing the car's A2DP receiver from ever sleeping, gating, or muting during track switches!
  const createSilentLoopAudioUrl = (): string => {
    try {
      const sampleRate = 8000;
      const numSamples = sampleRate; // 1 second
      const buffer = new ArrayBuffer(44 + numSamples);
      const view = new DataView(buffer);
      view.setUint32(0, 0x52494646, false); // 'RIFF'
      view.setUint32(4, 36 + numSamples, true);
      view.setUint32(8, 0x57415645, false); // 'WAVE'
      view.setUint32(12, 0x666d7420, false); // 'fmt '
      view.setUint32(16, 16, true);
      view.setUint16(20, 1, true); // PCM
      view.setUint16(22, 1, true); // Mono
      view.setUint32(24, sampleRate, true);
      view.setUint32(28, sampleRate, true);
      view.setUint16(32, 1, true);
      view.setUint16(34, 8, true);
      view.setUint32(36, 0x64617461, false); // 'data'
      view.setUint32(40, numSamples, true);
      const bytes = new Uint8Array(buffer, 44);
      for (let i = 0; i < numSamples; i++) {
        // Dither between 127 and 128 (1-bit LSB at 8kHz). Inaudible, but prevents DSP silence gate cutoff
        bytes[i] = (i % 2 === 0) ? 128 : 127;
      }
      const blob = new Blob([buffer], { type: 'audio/wav' });
      return URL.createObjectURL(blob);
    } catch {
      return 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
    }
  };

  // Helper to ensure continuous Bluetooth A2DP carrier stream is active
  const ensureCarrierActive = useCallback(() => {
    if (carrierAudioRef.current && userIntentPlayingRef.current) {
      if (carrierAudioRef.current.paused) {
        carrierAudioRef.current.play().catch(() => {});
      }
    }
  }, []);

  // Initialize audio elements
  useEffect(() => {
    silentLoopUrlRef.current = createSilentLoopAudioUrl();

    // 1. Persistent Bluetooth A2DP Carrier Audio Anchor:
    // Runs an inaudible, dithered silent loop that keeps the Bluetooth hardware stream and
    // Android AudioTrack alive throughout track changes, preventing car stereos from entering sleep mode!
    const carrierAudio = new Audio();
    carrierAudio.loop = true;
    carrierAudio.preload = 'auto';
    (carrierAudio as any).playsInline = true;
    (carrierAudio as any).webkitPlaysInline = true;
    carrierAudio.setAttribute('playsinline', 'true');
    carrierAudio.setAttribute('webkit-playsinline', 'true');
    carrierAudio.volume = 0.01; // Inaudible 1% volume carrier
    carrierAudio.src = silentLoopUrlRef.current;
    carrierAudioRef.current = carrierAudio;

    // 2. Primary Music Playback Element
    const audio = new Audio();
    audio.preload = 'auto';
    // Only set crossOrigin if Web Audio DSP is strictly needed (on desktop).
    // On mobile devices (Android & iOS), omitting crossOrigin allows native hardware audio playback
    // with zero CORS range request stalls, ensuring unbroken background playback and rock-solid Bluetooth A2DP routing!
    if (isAudioGraphNeeded()) {
      audio.crossOrigin = 'anonymous';
    }
    (audio as any).playsInline = true;
    (audio as any).webkitPlaysInline = true;
    audio.setAttribute('playsinline', 'true');
    audio.setAttribute('webkit-playsinline', 'true');
    audio.setAttribute('x-webkit-airplay', 'allow');
    audio.volume = (volumeRef.current || volume || 50) / 100;
    audioRef.current = audio;
    ensureAudioGraph(audio);
    setBaseAudioVolume(volume);

    // Dedicated Web Worker Watchdog:
    // Mobile browsers (Android Chromium & iOS WebKit) heavily throttle or freeze main thread
    // setTimeout and setInterval when screen is locked. A Web Worker timer is NOT frozen
    // while audio is actively playing, allowing us to guarantee unbroken background continuity.
    let watchdogWorker: Worker | null = null;
    try {
      const workerCode = `
        let timer = null;
        self.onmessage = function(e) {
          if (e.data === 'start') {
            if (timer) clearInterval(timer);
            timer = setInterval(function() {
              self.postMessage('watchdog_tick');
            }, 1000);
          } else if (e.data === 'stop') {
            if (timer) clearInterval(timer);
            timer = null;
          }
        };
      `;
      const blob = new Blob([workerCode], { type: 'application/javascript' });
      const workerUrl = URL.createObjectURL(blob);
      watchdogWorker = new Worker(workerUrl);
      let tickCount = 0;
      watchdogWorker.onmessage = () => {
        tickCount++;

        // 1. Maintain Bluetooth A2DP Carrier Anchor while user intends to listen
        if (userIntentPlayingRef.current && carrierAudioRef.current && carrierAudioRef.current.paused) {
          carrierAudioRef.current.play().catch(() => {});
        }

        // 2. Involuntary background pause self-healing:
        // When screen is off / locked, Android battery manager or iOS WebKit may pause the audio element.
        // The Web Worker tick is NOT frozen on background audio.
        if (
          userIntentPlayingRef.current &&
          audioRef.current &&
          audioRef.current.paused &&
          !isSeekingRef.current
        ) {
          const a = audioRef.current;
          // Auto-resume if there is a valid audio source and song hasn't reached the end
          if (a.src && a.src !== '' && !a.ended && (a.duration === 0 || isNaN(a.duration) || a.currentTime < a.duration - 0.5)) {
            a.play().catch(() => {});
          }
        }

        // 3. Autonomous Bluetooth & AudioTrack Continuity Verification:
        // Ensure volume and carrier anchor remain fully engaged without artificial seeking
        if (
          userIntentPlayingRef.current &&
          audioRef.current &&
          !audioRef.current.paused &&
          !isSeekingRef.current &&
          Date.now() - lastTrackTransitionTimeRef.current < 16000
        ) {
          const a = audioRef.current;
          if (a.currentTime >= 2.5 && a.currentTime <= 4.5 && !hasNudgedTransitionRef.current) {
            hasNudgedTransitionRef.current = true;
            try {
              if (a.muted) a.muted = false;
              a.volume = (volumeRef.current || 50) / 100;
              ensureCarrierActive();
            } catch {}
          }
        }

        // 4. Keep AudioContext active if present on desktop
        resumeAudioContext();

        // 5. Periodic background lease heartbeat every 15s so server lease never expires
        if (tickCount % 18 === 0 && userIntentPlayingRef.current) {
          sessionManager.sendHeartbeat().catch(() => {});
        }
      };
      watchdogWorker.postMessage('start');
    } catch {}

    const prefetchAudio = new Audio();
    prefetchAudio.preload = 'auto';
    prefetchAudio.muted = true;
    (prefetchAudio as any).playsInline = true;
    (prefetchAudio as any).webkitPlaysInline = true;
    prefetchAudio.setAttribute('playsinline', 'true');
    prefetchAudio.setAttribute('webkit-playsinline', 'true');
    prefetchAudioRef.current = prefetchAudio;

    const onPlay = () => {
      userIntentPlayingRef.current = true;
      setIsPlaying(true);
      ensureAudioGraph(audio);
      ensureCarrierActive();
      requestWakeLock();
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'playing';
      }
    };
    const onPause = () => {
      // Natural track conclusion: if track reached or is within 0.5s of the end, do NOT re-play; allow onEnded to transition cleanly
      if (audio.ended || (audio.duration > 0 && audio.currentTime >= audio.duration - 0.5)) {
        return;
      }

      // If user still intends to listen, do not accept involuntary OS screen-lock / background tab pause
      if (userIntentPlayingRef.current) {
        if (!isSeekingRef.current) {
          // Immediately attempt auto-resume without relying solely on delayed setTimeout
          try {
            audio.play().catch(() => {});
          } catch {}
          setTimeout(() => {
            if (userIntentPlayingRef.current && audioRef.current && audioRef.current.paused && !isSeekingRef.current) {
              audioRef.current.play().catch(() => {});
            }
          }, 80);
        }
        return;
      }
      setIsPlaying(false);
      setIsBuffering(false);
      releaseWakeLock();
      if (carrierAudioRef.current && !carrierAudioRef.current.paused) {
        carrierAudioRef.current.pause();
      }
      if (audio && audio.currentTime >= 0) {
        try {
          localStorage.setItem('mouzika_last_played_pos', String(Math.floor(audio.currentTime)));
        } catch {}
      }
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'paused';
      }
    };
    const onWaiting = () => {
      // Do not flash the loading spinner on instantaneous seeks or right after user seeks
      if (!isSeekingRef.current && !audio.seeking && Date.now() - lastSeekTimestampRef.current > 3000) {
        setIsBuffering(true);
      }
    };
    const onSeeking = () => {
      isSeekingRef.current = true;
      setIsBuffering(false);
    };
    const onSeeked = () => {
      setIsBuffering(false);
      setTimeout(() => {
        isSeekingRef.current = false;
      }, 600);
    };
    const onPlaying = () => {
      isLoadingTrackRef.current = false;
      userIntentPlayingRef.current = true;
      isSeekingRef.current = false;
      setIsBuffering(false);
      ensureCarrierActive();
      requestWakeLock();
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'playing';
      }
    };
    const updatePositionState = () => {
      if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
        if (audio && isFinite(audio.duration) && audio.duration > 0) {
          try {
            navigator.mediaSession.setPositionState({
              duration: audio.duration,
              playbackRate: audio.playbackRate || 1,
              position: Math.max(0, Math.min(audio.currentTime, audio.duration)),
            });
          } catch {}
        }
      }
    };
    let lastTrackSec = 0;
    let lastSavedPosSec = 0;
    const onTimeUpdate = () => {
      if (isLoadingTrackRef.current && audio.currentTime > 0.3) {
        isLoadingTrackRef.current = false;
      }
      setCurrentTime(audio.currentTime);
      updatePositionState();

      // Persist playback position strictly in localStorage
      const curSec = Math.floor(audio.currentTime);
      if (curSec > 0 && Math.abs(curSec - lastSavedPosSec) >= 1) {
        lastSavedPosSec = curSec;
        try {
          localStorage.setItem('mouzika_last_played_pos', String(curSec));
        } catch {}
      }

      // Accumulate listening seconds
      if (curSec !== lastTrackSec && curSec > 0) {
        lastTrackSec = curSec;
        listeningSecondsAccumRef.current += 1;
        if (listeningSecondsAccumRef.current >= 45) {
          listeningSecondsAccumRef.current = 0;
          recordListeningMinute(1);
        }

        // Cross-device sync broadcast from active device
        if (sessionManager.isCurrentDeviceHoldingLease()) {
          sessionManager.sendStateSync({
            trackId: activeTrackRef.current?.id,
            trackTitle: activeTrackRef.current?.title,
            trackArtist: activeTrackRef.current?.artist,
            trackThumb: activeTrackRef.current?.thumb,
            currentTime: audio.currentTime,
            duration: audio.duration,
            isPlaying: !audio.paused,
          });
        }
      }

      // Autonomous Bluetooth & AudioTrack Continuity Verification:
      // Verify audio un-mute and keep the Bluetooth carrier anchor active without artificial seeking
      if (
        !hasNudgedTransitionRef.current &&
        audio.currentTime >= 2.5 &&
        audio.currentTime <= 4.0 &&
        Date.now() - lastTrackTransitionTimeRef.current < 20000
      ) {
        hasNudgedTransitionRef.current = true;
        if (audio.muted) audio.muted = false;
        if (audio.volume === 0 && volumeRef.current > 0) {
          audio.volume = (volumeRef.current || 50) / 100;
        }
        ensureCarrierActive();
      }

      // Safe prefetch & pre-buffer: triggers safely at 12s after current track is stable
      if (!hasPrefetchedNextRef.current && audio.currentTime >= 12) {
        hasPrefetchedNextRef.current = true;
        prefetchNextSong();
      }

      // Seamless Gapless Handoff at natural track finish (0.35s before duration):
      // Prevents audio element from ever hitting 'ended' or dropping audio focus on Android 17 / One UI 9!
      if (
        !isLoopingRef.current &&
        !(audioRef.current && audioRef.current.loop) &&
        !isSeekingRef.current &&
        audio.duration > 15 &&
        audio.currentTime >= audio.duration - 0.35
      ) {
        if (playNextRef.current) {
          playNextRef.current();
        }
      }
    };
    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      setIsBuffering(false);
      updatePositionState();
    };
    const onEnded = () => {
      // Ignore ended events if audio is currently playing the temporary silent bridging gap
      if (silentLoopUrlRef.current && audio.src === silentLoopUrlRef.current) {
        return;
      }
      try {
        localStorage.setItem('mouzika_last_played_pos', '0');
      } catch {}
      if (isLoopingRef.current || (audioRef.current && audioRef.current.loop)) {
        if (audioRef.current) {
          audioRef.current.currentTime = 0;
          audioRef.current.play().catch(() => {});
        }
      } else {
        if (playNextRef.current) {
          playNextRef.current();
        }
      }
    };

    // Auto-reconnect & self-heal if audio stream encounters an unexpected network stall or disconnect
    const onAudioError = () => {
      // NEVER reconnect or reload track if user was actively seeking or sought recently!
      const timeSinceSeek = Date.now() - lastSeekTimestampRef.current;
      if (isSeekingRef.current || (audio && audio.seeking) || timeSinceSeek < 6000) {
        console.warn('Ignoring transient audio range abort during/after seek');
        return;
      }
      if (audio?.error?.code === 1) {
        console.warn('Ignoring MEDIA_ERR_ABORTED on audio element');
        return;
      }
      const active = activeTrackRef.current;
      if (active && audio && !audio.ended && audio.currentTime > 0) {
        const resumePos = audio.currentTime;
        console.warn('Audio stream drop detected, automatically reconnecting from:', resumePos);
        if (playTrackRef.current) {
          playTrackRef.current(active, true).then((ok) => {
            if (ok && audioRef.current && resumePos > 0) {
              audioRef.current.currentTime = resumePos;
            }
          });
        }
      }
    };

    const onStalled = () => {
      if (userIntentPlayingRef.current && audio && audio.paused && !isSeekingRef.current) {
        audio.play().catch(() => {});
      }
    };

    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('waiting', onWaiting);
    audio.addEventListener('seeking', onSeeking);
    audio.addEventListener('seeked', onSeeked);
    audio.addEventListener('playing', onPlaying);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onAudioError);
    audio.addEventListener('stalled', onStalled);

    // Keep background audio active when screen turns off or locks on iPhone / iOS & Android
    const onVisibilityChange = () => {
      resumeAudioContext();
      if (userIntentPlayingRef.current) {
        ensureCarrierActive();
      }
      if (document.visibilityState === 'visible') {
        if (audioRef.current) {
          if (audioRef.current.muted) audioRef.current.muted = false;
          if (audioRef.current.volume === 0 && volumeRef.current > 0) {
            audioRef.current.volume = (volumeRef.current || 50) / 100;
          }
          if (!audioRef.current.paused) {
            requestWakeLock();
          } else if (userIntentPlayingRef.current && !isSeekingRef.current) {
            audioRef.current.play().catch(() => {});
          }
        }
      } else if (document.visibilityState === 'hidden' && audioRef.current) {
        if (userIntentPlayingRef.current) {
          if ('mediaSession' in navigator) {
            navigator.mediaSession.playbackState = 'playing';
          }
          if (audioRef.current.paused && !isSeekingRef.current && audioRef.current.src) {
            audioRef.current.play().catch(() => {});
          }
        }
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    const onPageShow = () => {
      resumeAudioContext();
      if (userIntentPlayingRef.current) {
        ensureCarrierActive();
      }
      if (userIntentPlayingRef.current && audioRef.current) {
        if (audioRef.current.muted) audioRef.current.muted = false;
        if (audioRef.current.volume === 0 && volumeRef.current > 0) {
          audioRef.current.volume = (volumeRef.current || 50) / 100;
        }
        if (audioRef.current.paused && !isSeekingRef.current && audioRef.current.src) {
          audioRef.current.play().catch(() => {});
        }
      }
    };
    window.addEventListener('pageshow', onPageShow);

    // Init downloads registry
    initDownloadsRegistry().then(() => {
      setDownloadedSet(new Set(downloadedIds));
    });

    // Device settings initialization
    const devSettings = loadDeviceSettings();
    if (devSettings) {
      setUserProfile((prev) => ({ ...prev, ...devSettings }));
      applyTheme(
        devSettings.theme || 'dark',
        devSettings.accentColor || 'orange',
        devSettings.lyricsColor || 'white',
        devSettings.presetTint || 'none',
        devSettings.liquidGlass ?? true,
        devSettings.uiScale || 'default',
        devSettings.customAccentHex,
        devSettings.lyricsFont,
        devSettings.customLyricsHex,
        devSettings.lyricsGlow,
        devSettings.liquidGlassLevel
      );
    }

    const sanitizeTracks = (tracks?: Track[]): Track[] => {
      if (!tracks || !Array.isArray(tracks)) return [];
      return tracks.map((t) => {
        if (t && t.thumb && t.thumb.startsWith('blob:') && t.id) {
          return { ...t, thumb: canonicalThumbUrl(t.id) };
        }
        return t;
      });
    };

    // Auto-login on launch if saved or cached
    let savedUser: string | null = null;
    let savedPass: string | null = null;
    try {
      savedUser = localStorage.getItem('hub_active_user');
      savedPass = localStorage.getItem('hub_active_pass');
    } catch {}

    if (savedUser) {
      // User is already signed in! Keep them directly in their account without showing the welcome screen
      setGlobalUser(savedUser);
      setIsAuthGateOpen(false);

      if (savedUser) {
        const cached = restoreProfileFromCache(savedUser);
        if (cached) {
          if (cached.recentlyPlayed) {
            cached.recentlyPlayed = sanitizeTracks(cached.recentlyPlayed);
          }
          setUserProfile((prev) => ({ ...prev, ...cached }));
        }
      }

      if (savedPass) {
        // Silently sync profile in background
        login(savedUser, savedPass).catch(() => {});
      }
    } else {
      // New visitor or logged out: require sign in
      setIsAuthGateOpen(true);
    }

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pageshow', onPageShow);
      audio.removeEventListener('stalled', onStalled);
      audio.removeEventListener('suspend', onStalled);
      audio.pause();
      audio.src = '';
      if (carrierAudioRef.current) {
        carrierAudioRef.current.pause();
        carrierAudioRef.current.src = '';
      }
    };
  }, []);

  const applyTheme = (
    theme: string,
    accent: string,
    lyricsColor: string,
    presetTint: string,
    liquidGlass: boolean,
    uiScale: string = 'default',
    customAccentHex?: string,
    lyricsFont?: string,
    customLyricsHex?: string,
    lyricsGlow?: string,
    liquidGlassLevel?: 'off' | 'medium' | 'ultra'
  ) => {
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-accent', accent);
    document.documentElement.setAttribute('data-lyrics-color', lyricsColor);
    document.documentElement.setAttribute('data-preset-tint', presetTint);
    document.documentElement.setAttribute('data-ui-scale', uiScale || 'default');
    document.documentElement.setAttribute('data-lyrics-glow', lyricsGlow || 'default');
    document.documentElement.setAttribute('dir', (userProfile?.language || 'en') === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', userProfile?.language || 'en');
    if (lyricsFont) {
      document.documentElement.setAttribute('data-lyrics-font', lyricsFont);
    }
    const accentRgbMap: Record<string, string> = {
      orange: '255, 107, 26',
      purple: '168, 85, 247',
      green: '34, 197, 94',
      blue: '59, 130, 246',
      red: '239, 68, 68',
      pink: '236, 72, 153',
      teal: '20, 184, 166',
      cyan: '6, 182, 212',
      violet: '139, 92, 246',
      emerald: '16, 185, 129',
    };
    if (customAccentHex || (accent && accent.startsWith('#'))) {
      const hex = customAccentHex || accent;
      document.documentElement.style.setProperty('--accent', hex);
      document.documentElement.style.setProperty('--accent-hover', hex);
      document.documentElement.style.setProperty('--accent-soft', `${hex}28`);
      const cleanHex = hex.replace('#', '');
      if (cleanHex.length === 6) {
        const r = parseInt(cleanHex.slice(0, 2), 16);
        const g = parseInt(cleanHex.slice(2, 4), 16);
        const b = parseInt(cleanHex.slice(4, 6), 16);
        document.documentElement.style.setProperty('--accent-rgb', `${r}, ${g}, ${b}`);
      }
    } else {
      const rgb = accentRgbMap[accent] || '255, 107, 26';
      document.documentElement.style.setProperty('--accent-rgb', rgb);
      document.documentElement.style.removeProperty('--accent');
      document.documentElement.style.removeProperty('--accent-hover');
      document.documentElement.style.removeProperty('--accent-soft');
    }

    if (customLyricsHex || (lyricsColor && lyricsColor.startsWith('#'))) {
      const lyrHex = customLyricsHex || lyricsColor;
      document.documentElement.style.setProperty('--lyrics-color', lyrHex);
      const cleanHex = lyrHex.replace('#', '');
      if (cleanHex.length === 6) {
        const r = parseInt(cleanHex.slice(0, 2), 16);
        const g = parseInt(cleanHex.slice(2, 4), 16);
        const b = parseInt(cleanHex.slice(4, 6), 16);
        document.documentElement.style.setProperty('--lyrics-color-rgb', `${r}, ${g}, ${b}`);
      }
    } else {
      document.documentElement.style.removeProperty('--lyrics-color');
      document.documentElement.style.removeProperty('--lyrics-color-rgb');
    }

    const isGlassOff = liquidGlassLevel === 'off' || liquidGlass === false;
    const isUltra = liquidGlassLevel === 'ultra';
    const isMedium = !isGlassOff && !isUltra;
    document.body.classList.toggle('liquid-glass', isMedium);
    document.body.classList.toggle('liquid-glass-ultra', isUltra);
  };

  const syncProfile = useCallback((updated?: UserProfile) => {
    const prof = updated || userProfile;
    setUserProfile(prof);
    saveDeviceSettings(prof);
    if (prof.language) {
      try { localStorage.setItem('mouzika_app_language', prof.language); } catch {}
    }
    if (prof.progressBarStyle) {
      saveProgressBarStyle(prof.progressBarStyle);
    }
    applyTheme(
      prof.theme,
      prof.accentColor,
      prof.lyricsColor,
      prof.presetTint,
      prof.liquidGlass,
      prof.uiScale,
      prof.customAccentHex,
      prof.lyricsFont,
      prof.customLyricsHex,
      prof.lyricsGlow,
      prof.liquidGlassLevel
    );
    if (!globalUser) {
      saveGuestProfile(prof);
      return;
    }
    cacheProfileLocally(globalUser, prof);
    pendingSyncProfRef.current = prof;
    isSyncDirtyRef.current = true;
    flushProfileToServer(prof);
  }, [userProfile, globalUser, flushProfileToServer]);

  const login = async (user: string, pass: string) => {
    try {
      const localCached = restoreProfileFromCache(user);
      const guest = restoreGuestProfile();
      const clientProfileToSend = localCached || ((userProfile.customPlaylists?.length > 0 || userProfile.likedSongs?.length > 0) ? userProfile : null) || guest || null;

      let data: any = null;
      try {
        const localRes = await fetchWithTimeout('/api/auth/login', 5000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: user,
            password: pass,
            deviceId: sessionManager.getDeviceId(),
            deviceName: sessionManager.getDeviceName(),
            clientProfile: clientProfileToSend,
          }),
        });
        if (localRes.ok) {
          data = await localRes.json().catch(() => null);
        }
      } catch {}

      if (!data || data.error) {
        const cloudUrl = NEW_HUB_BACKEND
          ? `${NEW_HUB_BACKEND}/api/login`
          : 'https://new-music-space-api.urshabib.workers.dev/api/login';
        const res = await fetchWithTimeout(cloudUrl, 9000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: user, password: pass }),
        });
        const cloudData = await res.json().catch(() => ({}));
        if (res.ok && !cloudData.error) {
          data = cloudData;
        } else if (!data) {
          data = cloudData;
        }
      }

      if (data.error) {
        return { success: false, error: data.error };
      }
      setGlobalUser(user);
      setGlobalPass(pass);
      const sessionToken = data.sessionToken || `sess_${user}_${Date.now()}`;
      sessionManager.setSession(sessionToken, user);
      try {
        localStorage.setItem('hub_active_user', user);
        localStorage.setItem('hub_active_pass', pass);
      } catch {}
      syncAccountPlaybackState();
      setIsAuthGateOpen(false);

      const isUserAdmin = Boolean(data.isAdmin || user.toLowerCase() === 'admin' || data.profile?.isAdmin);
      const userEnabledStatus = data.enabled !== undefined ? data.enabled !== false : (data.profile?.enabled !== undefined ? data.profile.enabled !== false : true);

      const devSettings = loadDeviceSettings() || {};
      const sanitizeTracks = (tracks?: Track[]): Track[] => {
        if (!tracks || !Array.isArray(tracks)) return [];
        return tracks.map((t) => {
          if (t && t.thumb && t.thumb.startsWith('blob:') && t.id) {
            return { ...t, thumb: canonicalThumbUrl(t.id) };
          }
          return t;
        });
      };

      const serverProfile = data.profile || null;

      // Extract cloud stats, explicit taste, and server-persisted profile data from favouriteAlbums system record if present
      let cloudTasteInterested: any = undefined;
      let cloudTasteNotInterested: any = undefined;
      if (serverProfile && Array.isArray(serverProfile.favouriteAlbums)) {
        const cloudRecord = serverProfile.favouriteAlbums.find(
          (a: any) => a && (a.id === '__mouzika_cloud_stats_v1__' || a.id === '__mouzika_cloud_profile_v1__')
        );
        if (cloudRecord) {
          if (cloudRecord.stats) {
            serverProfile.stats = extractStatsFromProfile({
              stats: serverProfile.stats,
              favouriteAlbums: [cloudRecord],
            });
          }
          if (cloudRecord.password && !serverProfile.password) serverProfile.password = cloudRecord.password;
          if (cloudRecord.explicitInterested) cloudTasteInterested = cloudRecord.explicitInterested;
          if (cloudRecord.explicitNotInterested) cloudTasteNotInterested = cloudRecord.explicitNotInterested;
          if (cloudRecord.displayName && !serverProfile.displayName) serverProfile.displayName = cloudRecord.displayName;
          if (cloudRecord.avatarUrl !== undefined && serverProfile.avatarUrl === undefined) serverProfile.avatarUrl = cloudRecord.avatarUrl;
          if (cloudRecord.email && !serverProfile.email) serverProfile.email = cloudRecord.email;
        }
      }

      if (cloudTasteInterested && Array.isArray(cloudTasteInterested)) {
        try { localStorage.setItem('mouzika_taste_explicit_interested', JSON.stringify(cloudTasteInterested)); } catch {}
      }
      if (cloudTasteNotInterested && Array.isArray(cloudTasteNotInterested)) {
        try { localStorage.setItem('mouzika_taste_explicit_not_interested', JSON.stringify(cloudTasteNotInterested)); } catch {}
      }

      // Comprehensive lossless merge: NEVER wipes customPlaylists, likedSongs, recentlyPlayed, or favorites!
      const merged = mergeProfilesSafely(
        user,
        defaultProfile,
        serverProfile,
        localCached,
        guest,
        userProfile
      );

      // Sanitize track thumbnail references
      merged.likedSongs = sanitizeTracks(merged.likedSongs);
      merged.recentlyPlayed = sanitizeTracks(merged.recentlyPlayed);
      merged.customPlaylists = (merged.customPlaylists || []).map((pl) => ({
        ...pl,
        tracks: sanitizeTracks(pl.tracks),
      }));

      merged.isAdmin = isUserAdmin;
      merged.enabled = userEnabledStatus;

      // Apply device-specific preferences
      if (devSettings.theme) merged.theme = devSettings.theme;
      if (devSettings.accentColor) merged.accentColor = devSettings.accentColor;
      if (devSettings.lyricsColor) merged.lyricsColor = devSettings.lyricsColor;
      if (devSettings.lyricsGlow) merged.lyricsGlow = devSettings.lyricsGlow;
      if (devSettings.presetTint) merged.presetTint = devSettings.presetTint;
      if (devSettings.uiScale) merged.uiScale = devSettings.uiScale;
      if (devSettings.liquidGlass !== undefined) merged.liquidGlass = !!devSettings.liquidGlass;
      if (devSettings.liquidGlassLevel) merged.liquidGlassLevel = devSettings.liquidGlassLevel;
      if (devSettings.customAccentHex) merged.customAccentHex = devSettings.customAccentHex;
      if (devSettings.lyricsFont) merged.lyricsFont = devSettings.lyricsFont;
      if (devSettings.customLyricsHex) merged.customLyricsHex = devSettings.customLyricsHex;
      if (devSettings.progressBarStyle) merged.progressBarStyle = devSettings.progressBarStyle;
      if (devSettings.progressBarColor) merged.progressBarColor = devSettings.progressBarColor;
      if (devSettings.customProgressBarHex) merged.customProgressBarHex = devSettings.customProgressBarHex;

      const localSavedLang = localStorage.getItem('mouzika_app_language') as Language | null;
      const resolvedLanguage =
        merged.language ||
        devSettings.language ||
        localSavedLang ||
        userProfile.language ||
        'en';
      merged.language = resolvedLanguage as Language;

      document.documentElement.setAttribute('dir', resolvedLanguage === 'ar' ? 'rtl' : 'ltr');
      document.documentElement.setAttribute('lang', resolvedLanguage);

      setUserProfile(merged);
      saveDeviceSettings(merged);
      if (merged.progressBarStyle) {
        saveProgressBarStyle(merged.progressBarStyle);
      }
      applyTheme(
        merged.theme,
        merged.accentColor,
        merged.lyricsColor,
        merged.presetTint,
        merged.liquidGlass,
        merged.uiScale,
        merged.customAccentHex,
        merged.lyricsFont,
        merged.customLyricsHex,
        merged.lyricsGlow,
        merged.liquidGlassLevel
      );
      cacheProfileLocally(user, merged);
      clearGuestProfile();

      // Immediately sync merged profile back to server to ensure cloud persistence
      setTimeout(() => flushProfileToServer(merged), 400);

      return { success: true };
    } catch {
      return { success: false, error: "Can't reach server. Working in offline mode." };
    }
  };

  // Two-way synchronization: pull latest cloud state, then push consolidated updates
  const forceProfileServerSync = useCallback(async (forcedProfile?: UserProfile): Promise<boolean> => {
    if (!globalUser) return false;
    if (forcedProfile) {
      return flushProfileToServer(forcedProfile);
    }
    let savedPass = globalPass;
    if (!savedPass) {
      try {
        savedPass = localStorage.getItem('hub_active_pass');
      } catch {}
    }
    if (savedPass) {
      try {
        await login(globalUser, savedPass);
      } catch {}
    }
    return flushProfileToServer();
  }, [globalUser, globalPass, flushProfileToServer]);

  // Clear listening statistics: resets minutes, plays, top songs, and top artists
  // while keeping recently played, liked songs, and playlists completely untouched
  const clearListeningStats = useCallback(async (): Promise<boolean> => {
    const resetStats: UserStats = {
      totalMinutesListened: 0,
      totalTracksPlayed: 0,
      topSongs: [],
      topArtists: [],
      lastUpdated: Date.now(),
    };

    const targetUser = globalUser || userProfile.username;

    setUserProfile((prev) => {
      const cleanAlbums = (prev.favouriteAlbums || []).filter((a: any) => a && a.id !== '__mouzika_cloud_stats_v1__');
      const updated: UserProfile = {
        ...prev,
        stats: resetStats,
        favouriteAlbums: cleanAlbums,
      };
      saveDeviceSettings(updated);
      if (targetUser) {
        cacheProfileLocally(targetUser, updated);
      }
      return updated;
    });

    if (targetUser) {
      const cleanProf: UserProfile = {
        ...userProfile,
        stats: resetStats,
        favouriteAlbums: (userProfile.favouriteAlbums || []).filter((a: any) => a && a.id !== '__mouzika_cloud_stats_v1__'),
      };
      await flushProfileToServer(cleanProf);
    }

    return true;
  }, [globalUser, userProfile, flushProfileToServer]);

  // Hide song from listening stats (deducts time & plays, moves to hiddenStatsSongs)
  const hideSongFromStats = useCallback((songId: string) => {
    if (!songId) return;
    setUserProfile((prev) => {
      const stats = prev.stats || {
        totalMinutesListened: 0,
        totalTracksPlayed: 0,
        topSongs: [],
        topArtists: [],
      };
      const currentTop = stats.topSongs || [];
      const songToHide = currentTop.find((s) => s.id === songId);
      if (!songToHide) return prev;

      const newTop = currentTop.filter((s) => s.id !== songId);
      const existingHidden = prev.hiddenStatsSongs || [];
      const newHidden = [songToHide, ...existingHidden.filter((s) => s.id !== songId)];

      // Deduct song's minutes and play count from total statistics
      const deductedMins = Math.max(0, (stats.totalMinutesListened || 0) - (songToHide.minutesListened || 0));
      const deductedPlays = Math.max(0, (stats.totalTracksPlayed || 0) - (songToHide.playCount || 0));

      // Recompute topArtists based on visible newTop songs
      const artistMap = new Map<string, ArtistPlayStat>();
      newTop.forEach((s) => {
        const art = (s.artist || 'Unknown').trim();
        const key = art.toLowerCase();
        const ex = artistMap.get(key);
        if (ex) {
          ex.playCount = (ex.playCount || 0) + (s.playCount || 1);
          ex.minutesListened = (ex.minutesListened || 0) + (s.minutesListened || 0);
          if (!ex.thumb && s.thumb) ex.thumb = s.thumb;
        } else {
          artistMap.set(key, {
            name: art,
            playCount: s.playCount || 1,
            minutesListened: s.minutesListened || 0,
            thumb: s.thumb,
          });
        }
      });
      const newTopArtists = Array.from(artistMap.values()).sort(
        (a, b) => (b.minutesListened || 0) - (a.minutesListened || 0)
      );

      const updatedStats: UserStats = {
        ...stats,
        totalMinutesListened: deductedMins,
        totalTracksPlayed: deductedPlays,
        topSongs: newTop,
        topArtists: newTopArtists.slice(0, 20),
        lastUpdated: Date.now(),
      };

      const updated: UserProfile = {
        ...prev,
        stats: updatedStats,
        hiddenStatsSongs: newHidden,
      };

      saveDeviceSettings(updated);
      const targetUser = globalUser || prev.username;
      if (targetUser) {
        cacheProfileLocally(targetUser, updated);
        pendingSyncProfRef.current = updated;
        isSyncDirtyRef.current = true;
      }
      return updated;
    });
  }, [globalUser]);

  // Restore hidden song back to listening stats (restores time & plays, moves back to topSongs)
  const unhideSongFromStats = useCallback((songId: string) => {
    if (!songId) return;
    setUserProfile((prev) => {
      const existingHidden = prev.hiddenStatsSongs || [];
      const songToRestore = existingHidden.find((s) => s.id === songId);
      if (!songToRestore) return prev;

      const newHidden = existingHidden.filter((s) => s.id !== songId);
      const stats = prev.stats || {
        totalMinutesListened: 0,
        totalTracksPlayed: 0,
        topSongs: [],
        topArtists: [],
      };

      const currentTop = [...(stats.topSongs || [])];
      if (!currentTop.some((s) => s.id === songId)) {
        currentTop.push(songToRestore);
      }
      currentTop.sort((a, b) => ((b.playCount || 0) * 3 + (b.minutesListened || 0)) - ((a.playCount || 0) * 3 + (a.minutesListened || 0)));

      const restoredMins = (stats.totalMinutesListened || 0) + (songToRestore.minutesListened || 0);
      const restoredPlays = (stats.totalTracksPlayed || 0) + (songToRestore.playCount || 0);

      // Recompute topArtists based on visible currentTop songs
      const artistMap = new Map<string, ArtistPlayStat>();
      currentTop.forEach((s) => {
        const art = (s.artist || 'Unknown').trim();
        const key = art.toLowerCase();
        const ex = artistMap.get(key);
        if (ex) {
          ex.playCount = (ex.playCount || 0) + (s.playCount || 1);
          ex.minutesListened = (ex.minutesListened || 0) + (s.minutesListened || 0);
          if (!ex.thumb && s.thumb) ex.thumb = s.thumb;
        } else {
          artistMap.set(key, {
            name: art,
            playCount: s.playCount || 1,
            minutesListened: s.minutesListened || 0,
            thumb: s.thumb,
          });
        }
      });
      const newTopArtists = Array.from(artistMap.values()).sort(
        (a, b) => (b.minutesListened || 0) - (a.minutesListened || 0)
      );

      const updatedStats: UserStats = {
        ...stats,
        totalMinutesListened: restoredMins,
        totalTracksPlayed: restoredPlays,
        topSongs: currentTop,
        topArtists: newTopArtists.slice(0, 20),
        lastUpdated: Date.now(),
      };

      const updated: UserProfile = {
        ...prev,
        stats: updatedStats,
        hiddenStatsSongs: newHidden,
      };

      saveDeviceSettings(updated);
      const targetUser = globalUser || prev.username;
      if (targetUser) {
        cacheProfileLocally(targetUser, updated);
        pendingSyncProfRef.current = updated;
        isSyncDirtyRef.current = true;
      }
      return updated;
    });
  }, [globalUser]);

  const logout = () => {
    try {
      if (globalUser && globalUser !== 'admin') {
        cacheProfileLocally(globalUser, userProfile);
      }
      localStorage.removeItem('hub_active_user');
      localStorage.removeItem('hub_active_pass');
      localStorage.removeItem('hub_is_guest');
      const rawDev = localStorage.getItem('mouzika_device_settings');
      if (rawDev) {
        try {
          const parsed = JSON.parse(rawDev);
          delete parsed.displayName;
          delete parsed.avatarUrl;
          delete parsed.username;
          localStorage.setItem('mouzika_device_settings', JSON.stringify(parsed));
        } catch {}
      }
    } catch {}
    setGlobalUser(null);
    setGlobalPass(null);
    sessionManager.clearSession();
    setSupersededNotice(null);
    setUserProfile({
      ...defaultProfile,
      username: '',
      displayName: '',
      avatarUrl: null,
    });
    setIsAuthGateOpen(true);
    showToast('Logged out', true);
  };

  const updateUserEmail = useCallback(async (newEmail: string): Promise<{ success: boolean; error?: string }> => {
    if (!globalUser) {
      return { success: false, error: 'You must be logged in to update your email.' };
    }
    const cleanEmail = newEmail.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }

    const updated: UserProfile = {
      ...userProfile,
      email: cleanEmail,
    };
    syncProfile(updated);

    try {
      fetchWithTimeout(`${NEW_HUB_BACKEND}/api/update-email`, 8000, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: globalUser,
          email: cleanEmail,
        }),
      }).catch(() => {});
    } catch {}

    await forceProfileServerSync(updated);
    showToast('Email address linked & synced to cloud');
    return { success: true };
  }, [globalUser, userProfile, syncProfile, forceProfileServerSync, showToast]);

  const updateUserPassword = useCallback(async (currentPass: string, newPass: string): Promise<{ success: boolean; error?: string }> => {
    if (!globalUser) {
      return { success: false, error: 'You must be logged in to change your password.' };
    }
    if (!currentPass) {
      return { success: false, error: 'Please enter your current password.' };
    }
    if (!newPass || newPass.length < 6) {
      return { success: false, error: 'New password must be at least 6 characters long for security.' };
    }
    if (currentPass === newPass) {
      return { success: false, error: 'New password must be different from your current password.' };
    }

    // 1. Verify current credentials against server first
    try {
      const verifyRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/login`, 6000, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: globalUser, password: currentPass }),
      });
      const verifyData = await verifyRes.json().catch(() => null);
      if (verifyData && verifyData.error) {
        return { success: false, error: verifyData.error || 'Current password is incorrect.' };
      }
    } catch {
      const cachedPass = globalPass || localStorage.getItem('hub_active_pass');
      if (cachedPass && currentPass !== cachedPass) {
        return { success: false, error: 'Current password is incorrect.' };
      }
    }

    try {
      const profSnapshot = { ...userProfile };
      const isUserAdmin = Boolean(userProfile.isAdmin || globalUser.toLowerCase() === 'admin');

      let updatedOnServer = false;
      // 2. Try dedicated endpoint first if supported
      try {
        const res = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/change-password`, 5000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: globalUser,
            currentPassword: currentPass,
            newPassword: newPass,
          }),
        });
        const resData = await res.json().catch(() => null);
        if (res.ok && resData && !resData.error && resData.success) {
          updatedOnServer = true;
        }
      } catch {}

      // 3. Perform atomic recreate to reliably update credentials on Cloudflare while preserving profile & roles
      if (!updatedOnServer) {
        // Delete user
        const delRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/delete-user`, 8000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: globalUser }),
        });
        const delData = await delRes.json().catch(() => null);
        if (!delRes.ok || (delData && delData.error)) {
          throw new Error(delData?.error || 'Failed to update credentials on server');
        }

        // Re-create user with new password
        const createRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/create-user`, 8000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: globalUser,
            password: newPass,
            isAdmin: isUserAdmin,
          }),
        });
        const createData = await createRes.json().catch(() => null);
        if (!createRes.ok || (createData && createData.error)) {
          throw new Error(createData?.error || 'Failed to set new password on server');
        }

        // Preserve admin role if applicable
        if (isUserAdmin) {
          await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/set-admin`, 8000, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: globalUser, isAdmin: true }),
          }).catch(() => {});
        }

        // Restore full profile data
        await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/save-profile`, 8000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...profSnapshot,
            username: globalUser,
          }),
        }).catch(() => {});

        updatedOnServer = true;
      }

      // 4. Verify authentication with the NEW password
      const verifyNew = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/login`, 6000, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: globalUser, password: newPass }),
      });
      const verifyNewData = await verifyNew.json().catch(() => null);
      if (!verifyNew.ok || !verifyNewData || verifyNewData.error || !verifyNewData.success) {
        throw new Error(verifyNewData?.error || 'Verification with new password failed');
      }

      // 5. Verify the OLD password NO LONGER works
      try {
        const verifyOld = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/login`, 5000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: globalUser, password: currentPass }),
        });
        const verifyOldData = await verifyOld.json().catch(() => null);
        if (verifyOldData && verifyOldData.success) {
          throw new Error('Security check failed: Old password is still active on server.');
        }
      } catch (oldErr: any) {
        if (oldErr.message && oldErr.message.includes('Security check failed')) {
          throw oldErr;
        }
      }

      // 6. Update global password state and website cache so active session remains valid
      setGlobalPass(newPass);
      try {
        localStorage.setItem('hub_active_pass', newPass);
      } catch {}

      cacheProfileLocally(globalUser, { ...profSnapshot, isAdmin: isUserAdmin });
      setUserProfile((prev) => ({ ...prev, isAdmin: isUserAdmin }));
      showToast('Password updated successfully');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to update password.' };
    }
  }, [globalUser, globalPass, userProfile, showToast]);

  const adminResetUserPassword = useCallback(async (targetUsername: string, newPass: string): Promise<{ success: boolean; error?: string }> => {
    if (!targetUsername || !newPass) {
      return { success: false, error: 'Target username and new password are required.' };
    }
    if (newPass.length < 4) {
      return { success: false, error: 'Password must be at least 4 characters long.' };
    }

    // Verify caller is authorized
    const isCallerAdmin = Boolean(
      (globalUser && globalUser.toLowerCase() === 'admin') ||
      userProfile.isAdmin
    );
    if (!isCallerAdmin) {
      return { success: false, error: 'Unauthorized: Admin privileges required to modify user passwords.' };
    }

    try {
      let updatedOnServer = false;
      const sessionToken = sessionManager.getSessionToken();
      // 1. Try dedicated admin reset-password endpoint first
      try {
        const resetHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
        if (!NEW_HUB_BACKEND && sessionToken) {
          resetHeaders.Authorization = `Bearer ${sessionToken}`;
        }
        const res = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/admin/reset-password`, 6000, {
          method: 'POST',
          headers: resetHeaders,
          body: JSON.stringify({
            username: targetUsername,
            password: newPass,
            sessionToken: sessionToken || '',
          }),
        });
        const resData = await res.json().catch(() => null);
        if (res.ok && resData && !resData.error && resData.success) {
          updatedOnServer = true;
        }
      } catch {}

      if (!updatedOnServer) {
        try {
          const res = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/change-password`, 5000, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              username: targetUsername,
              newPassword: newPass,
              password: newPass,
              force: true,
              sessionToken: sessionToken || '',
            }),
          });
          const resData = await res.json().catch(() => null);
          if (res.ok && resData && !resData.error && resData.success) {
            updatedOnServer = true;
          }
        } catch {}
      }

      // 2. Perform atomic recreate while preserving target user's admin status and profile
      if (!updatedOnServer) {
        let wasAdmin = targetUsername.toLowerCase() === 'admin';
        try {
          const listRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/list-users`, 5000, {
            headers: { 'Content-Type': 'application/json' },
          });
          const listData = await listRes.json().catch(() => null);
          const userEntry = listData?.users?.find(
            (u: any) => u.username.toLowerCase() === targetUsername.toLowerCase()
          );
          if (userEntry) wasAdmin = wasAdmin || Boolean(userEntry.isAdmin);
        } catch {}

        const cachedTarget = targetUsername.toLowerCase() === globalUser?.toLowerCase()
          ? userProfile
          : restoreProfileFromCache(targetUsername);

        // Delete user
        const delRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/delete-user`, 8000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: targetUsername, sessionToken: sessionToken || '' }),
        });
        const delData = await delRes.json().catch(() => null);
        if (!delRes.ok || (delData && delData.error)) {
          throw new Error(delData?.error || 'Failed to update user credentials on server');
        }

        // Re-create user with new password
        const createRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/create-user`, 8000, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: targetUsername,
            password: newPass,
            isAdmin: wasAdmin,
            sessionToken: sessionToken || '',
          }),
        });
        const createData = await createRes.json().catch(() => null);
        if (!createRes.ok || (createData && createData.error)) {
          throw new Error(createData?.error || 'Failed to set user password on server');
        }

        // Restore admin role if applicable
        if (wasAdmin) {
          await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/set-admin`, 8000, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: targetUsername, isAdmin: true }),
          }).catch(() => {});
        }

        // Restore profile if cached
        if (cachedTarget) {
          await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/save-profile`, 8000, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              ...cachedTarget,
              username: targetUsername,
            }),
          }).catch(() => {});
        }

        updatedOnServer = true;
      }

      // 3. Verify authentication with new password
      const verifyRes = await fetchWithTimeout(`${NEW_HUB_BACKEND}/api/login`, 6000, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: targetUsername, password: newPass }),
      });
      const verifyData = await verifyRes.json().catch(() => null);
      if (!verifyRes.ok || !verifyData || verifyData.error || !verifyData.success) {
        throw new Error(verifyData?.error || 'Authentication verification failed with new password');
      }

      // If updating the currently logged-in account, keep active session in sync
      if (globalUser && targetUsername.toLowerCase() === globalUser.toLowerCase()) {
        setGlobalPass(newPass);
        try {
          localStorage.setItem('hub_active_pass', newPass);
        } catch {}
        setUserProfile((prev) => ({ ...prev, isAdmin: true }));
      }

      showToast(`Password updated for "${targetUsername}"`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to update user password.' };
    }
  }, [globalUser, globalPass, userProfile, showToast]);

  // Music Taste Tuning
  const tuneMusicTaste = useCallback((track: Track, direction: 'more' | 'less') => {
    if (!track || !track.id) return;
    if (direction === 'more') {
      addExplicitInterested(track);
      showToast(`Added to your Music Taste — More like this`, true);
    } else {
      addExplicitNotInterested(track);
      showToast(`Marked as Not Interested — Less like this`, true);
      if (activeTrackRef.current?.id === track.id) {
        if (playNextRef.current) playNextRef.current();
      }
    }
    syncProfile();
  }, [showToast, syncProfile]);

  const removeTrackFromTaste = useCallback((trackId: string) => {
    if (!trackId) return;
    removeExplicitInterested(trackId);
    removeExplicitNotInterested(trackId);
    showToast(`Removed from Music Taste preferences`, true);
    syncProfile();
  }, [showToast, syncProfile]);

  const isTuneInterested = useCallback((trackId: string) => {
    return isExplicitInterested(trackId);
  }, []);

  const isTuneDisliked = useCallback((trackId: string) => {
    return isExplicitNotInterested(trackId);
  }, []);

  const getInterestedTracks = useCallback(() => {
    return getExplicitInterestedTracks();
  }, []);

  const getNotInterestedTracks = useCallback(() => {
    return getExplicitNotInterestedTracks();
  }, []);

  // Next Track Algorithmic Discovery with explicit taste prioritization
  const getNextAlgorithmTrack = async (seed: Track): Promise<Track | null> => {
    try {
      const res = await fetchWithTimeout(
        `${NEW_HUB_BACKEND}/api/similar-proxy?title=${encodeURIComponent(seed.title)}&artist=${encodeURIComponent(seed.artist)}`,
        5000
      );
      if (res.ok) {
        const data = await res.json();
        const list = Array.isArray(data) ? data : data.items || [];
        const candidates = list
          .map((it: any) => ({
            id: it.id || it.videoId,
            title: it.title || it.name,
            artist: it.artist || it.author || 'Various Artists',
            thumb: canonicalThumbUrl(it.id || it.videoId),
            type: 'song' as const,
          }))
          .filter((t: Track) => t.id && t.id !== seed.id && !isExplicitNotInterested(t.id));

        if (candidates.length > 0) {
          // Sort candidates: prioritize explicit interested songs & artists, avoid disliked
          const sorted = candidates.sort((a: Track, b: Track) => {
            const aScore = (isExplicitInterested(a.id) ? 15 : 0) + tasteArtistScore(a.artist);
            const bScore = (isExplicitInterested(b.id) ? 15 : 0) + tasteArtistScore(b.artist);
            return bScore - aScore;
          });
          return sorted[Math.floor(Math.random() * Math.min(3, sorted.length))];
        }
      }
    } catch {}
    return null;
  };

  // Prefetch & Pre-buffer stream for next queued or algorithmic song
  const prefetchNextSong = async () => {
    const active = activeTrackRef.current;
    if (!active) return;
    if (isPreloadingNextRef.current) return;
    isPreloadingNextRef.current = true;

    try {
      const queue = playbackQueueRef.current;
      const idx = queueIndexRef.current;
      const shuffle = isShuffleRef.current;
      let nextTrack: Track | null = null;

      if (queue && queue.length > 0) {
        if (shuffle && queue.length > 1) {
          const randomIdx = Math.floor(Math.random() * queue.length);
          nextTrack = queue[randomIdx];
        } else if (idx >= 0 && idx < queue.length - 1) {
          nextTrack = queue[idx + 1];
        }
      }

      if (!nextTrack) {
        nextTrack = await getNextAlgorithmTrack(active);
      }

      if (!nextTrack || !nextTrack.id) {
        isPreloadingNextRef.current = false;
        return;
      }

      // 1. If downloaded offline track: preload Blob URL directly into preloadedNextRef
      if (isDownloaded(nextTrack.id)) {
        try {
          const record = await getDownload(nextTrack.id);
          if (record?.audioBlob) {
            const blobUrl = URL.createObjectURL(record.audioBlob);
            preloadedNextRef.current = {
              track: nextTrack,
              url: blobUrl,
              isBlob: true,
            };
            isPreloadingNextRef.current = false;
            return;
          }
        } catch {}
      }

      // 2. If online track: resolve and cache stream URL into preloadedNextRef
      const level = userProfile.dataSaverLevel || 'off';
      const q = level === 'ultra' ? '48' : level === 'saver' ? '96' : '320';

      let streamUrl = getCachedStreamUrl(nextTrack.id);
      if (!streamUrl) {
        streamUrl = await resolveWorkerStream(nextTrack.id).catch(() => null);
        if (!streamUrl) {
          const mirrors = await resolveMirrorStreams(nextTrack.id).catch(() => []);
          if (mirrors.length > 0) streamUrl = mirrors[0];
        }
        if (!streamUrl) {
          const cleanT = cleanTitleForLyrics(nextTrack.title) || nextTrack.title;
          const cleanA = cleanArtistName(nextTrack.artist);
          streamUrl = await resolveSaavnStream(cleanT, cleanA, q, nextTrack.title, nextTrack.artist).catch(() => null);
        }
      }

      if (streamUrl) {
        cacheStreamUrl(nextTrack.id, streamUrl);
        preloadedNextRef.current = {
          track: nextTrack,
          url: streamUrl,
          isBlob: false,
        };
      }
    } catch {} finally {
      isPreloadingNextRef.current = false;
    }
  };

  const tryPlayCandidates = async (candidates: string[], token: number, targetTrackId: string, idx = 0): Promise<boolean> => {
    if (idx >= candidates.length) return false;
    if (token !== playTokenRef.current) return false;
    const url = candidates[idx];
    const audio = audioRef.current;
    if (!audio) return false;

    return new Promise((resolve) => {
      let settled = false;
      const cleanup = () => {
        audio.removeEventListener('playing', onPlaying);
        audio.removeEventListener('canplay', onCanPlay);
        audio.removeEventListener('loadeddata', onCanPlay);
        audio.removeEventListener('error', onError);
        clearTimeout(timer);
      };

      const finish = async (ok: boolean) => {
        if (settled) return;
        settled = true;
        cleanup();
        if (token !== playTokenRef.current) {
          resolve(false);
          return;
        }
        if (ok) {
          if (targetTrackId) cacheStreamUrl(targetTrackId, url);
          resolve(true);
        } else {
          try {
            audio.pause();
            audio.removeAttribute('src');
            audio.load();
          } catch {}
          const nextOk = await tryPlayCandidates(candidates, token, targetTrackId, idx + 1);
          resolve(nextOk);
        }
      };

      const onPlaying = () => finish(true);
      const onCanPlay = () => finish(true);
      const onError = () => finish(false);
      // Give candidates ample time (5.5s on cold start, 4.0s for fallbacks) to avoid false negative "sources down"
      const timer = setTimeout(() => finish(false), idx === 0 ? 5500 : 4000);

      audio.addEventListener('playing', onPlaying, { once: true });
      audio.addEventListener('canplay', onCanPlay, { once: true });
      audio.addEventListener('loadeddata', onCanPlay, { once: true });
      audio.addEventListener('error', onError, { once: true });

      try {
        audio.loop = Boolean(isLoopingRef.current);
        audio.src = url;
        audio.load();
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise.catch(() => {
            // Might be autoplay policy or transient network error, wait for listeners or timer
          });
        }
      } catch {
        finish(false);
      }
    });
  };

  const generateRadioQueue = async (seedTrack: Track) => {
    try {
      const candidates: Track[] = [];
      const seenIds = new Set<string>([seedTrack.id]);
      const artistCounts: Record<string, number> = {};

      const seedArtistKey = tasteArtistKey(seedTrack.artist);
      if (seedArtistKey) artistCounts[seedArtistKey] = 1;

      // Collect playlist / liked song IDs so we prioritize fresh & new songs over repeating existing ones
      const existingPlaylistSongIds = new Set<string>();
      (userProfile.likedSongs || []).forEach((s) => s.id && existingPlaylistSongIds.add(s.id));
      (userProfile.customPlaylists || []).forEach((pl) => {
        (pl.tracks || []).forEach((s) => s.id && existingPlaylistSongIds.add(s.id));
      });

      let existingPlaylistTracksAdded = 0;

      // 1. Fetch direct authentic related tracks for seedTrack (Invidious / YouTube radio algorithm)
      try {
        const related = await getRelatedTracks(seedTrack.id);
        for (const it of related) {
          if (!it.id || seenIds.has(it.id)) continue;
          if (existingPlaylistSongIds.has(it.id)) {
            if (existingPlaylistTracksAdded >= 1) continue;
            existingPlaylistTracksAdded++;
          }
          const aKey = tasteArtistKey(it.artist);
          if (aKey && (artistCounts[aKey] || 0) >= 2) continue;
          seenIds.add(it.id);
          if (aKey) artistCounts[aKey] = (artistCounts[aKey] || 0) + 1;
          candidates.push(it);
        }
      } catch {}

      // 2. Fetch acoustic & thematic recommendations via similar-proxy
      try {
        const simRes = await fetchWithTimeout(
          `${NEW_HUB_BACKEND}/api/similar-proxy?title=${encodeURIComponent(seedTrack.title)}&artist=${encodeURIComponent(seedTrack.artist || '')}`,
          4500
        );
        if (simRes.ok) {
          const simData = await simRes.json();
          const list = Array.isArray(simData) ? simData : simData.items || [];
          for (const it of list) {
            const id = it.id || it.videoId;
            if (!id || seenIds.has(id)) continue;
            if (existingPlaylistSongIds.has(id)) {
              if (existingPlaylistTracksAdded >= 2) continue;
              existingPlaylistTracksAdded++;
            }
            const norm = normalizeTrack(it, 'song');
            const aKey = tasteArtistKey(norm.artist);
            if (aKey && (artistCounts[aKey] || 0) >= 2) continue;
            seenIds.add(id);
            if (aKey) artistCounts[aKey] = (artistCounts[aKey] || 0) + 1;
            candidates.push(norm);
          }
        }
      } catch {}

      // 3. Blend in fresh taste profile recommendations based on user history and overall musical vibe
      try {
        const tasteRecs = await getTasteProfileRecommendations(userProfile, seenIds, 12);
        for (const tRec of tasteRecs) {
          if (candidates.length >= 22) break;
          if (!tRec.id || seenIds.has(tRec.id)) continue;
          if (existingPlaylistSongIds.has(tRec.id)) {
            if (existingPlaylistTracksAdded >= 2) continue;
            existingPlaylistTracksAdded++;
          }
          const aKey = tasteArtistKey(tRec.artist);
          if (aKey && (artistCounts[aKey] || 0) >= 2) continue;
          seenIds.add(tRec.id);
          if (aKey) artistCounts[aKey] = (artistCounts[aKey] || 0) + 1;
          candidates.push(tRec);
        }
      } catch {}

      // 4. Fallback / supplement with radio mix search if fewer than 10 tracks
      if (candidates.length < 10) {
        const cleanTitle = cleanTitleForLyrics(seedTrack.title) || seedTrack.title;
        const query = cleanTitle ? `${cleanTitle} radio mix` : `${seedTrack.artist || 'popular'} mix`;
        const res = await fetchJsonRetry<any>(
          `${NEW_HUB_BACKEND}/api/search-proxy?q=${encodeURIComponent(query)}&f=song`,
          2
        ).catch(() => ({ items: [] }));
        const items = Array.isArray(res) ? res : res.items || [];
        for (const it of items) {
          const id = it.videoId || it.id;
          if (!id || seenIds.has(id)) continue;
          if (existingPlaylistSongIds.has(id)) {
            if (existingPlaylistTracksAdded >= 2) continue;
            existingPlaylistTracksAdded++;
          }
          const norm = normalizeTrack(it, 'song');
          const aKey = tasteArtistKey(norm.artist);
          if (aKey && (artistCounts[aKey] || 0) >= 2) continue;
          seenIds.add(id);
          if (aKey) artistCounts[aKey] = (artistCounts[aKey] || 0) + 1;
          candidates.push(norm);
          if (candidates.length >= 25) break;
        }
      }

      if (candidates.length > 0) {
        // Keep top 2 most immediate related tracks in front, then randomly interleave the remaining recommendations
        const head = candidates.slice(0, 2);
        const tail = candidates.slice(2);
        // Fisher-Yates gentle shuffle of tail to provide an organic, dynamic radio queue
        for (let i = tail.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [tail[i], tail[j]] = [tail[j], tail[i]];
        }
        const finalQueue = [...head, ...tail].slice(0, 25);

        setPlaybackQueue((current) => {
          if (current.length <= 1) {
            return [seedTrack, ...finalQueue];
          }
          return current;
        });
      }
    } catch {}
  };

  const lastStatsSyncTimeRef = useRef(0);
  const listeningSecondsAccumRef = useRef(0);

  const recordListeningMinute = useCallback((mins = 1) => {
    const track = activeTrackRef.current;
    if (!track || !track.id) return;

    setUserProfile((prev) => {
      const stats = extractStatsFromProfile(prev);
      const hiddenSongIds = new Set((prev.hiddenStatsSongs || []).map((s) => s.id));

      // 1. Update top songs (only for visible, non-hidden songs)
      const topSongs = [...(stats.topSongs || [])].filter((s) => !hiddenSongIds.has(s.id));
      if (!hiddenSongIds.has(track.id)) {
        const songIdx = topSongs.findIndex((s) => s.id === track.id);
        if (songIdx >= 0) {
          topSongs[songIdx] = {
            ...topSongs[songIdx],
            minutesListened: (topSongs[songIdx].minutesListened || 0) + mins,
            lastPlayed: Date.now(),
          };
        } else {
          topSongs.push({
            id: track.id,
            title: track.title,
            artist: track.artist,
            thumb: track.thumb,
            playCount: 1,
            minutesListened: mins,
            lastPlayed: Date.now(),
          });
        }
        topSongs.sort((a, b) => ((b.minutesListened || 0) * 3 + (b.playCount || 0) * 2) - ((a.minutesListened || 0) * 3 + (a.playCount || 0) * 2));
      }

      // 2. Derive top artists strictly from visible (non-hidden) songs so hidden songs never skew top artist
      const artistMap = new Map<string, ArtistPlayStat>();
      topSongs.forEach((s) => {
        const art = (s.artist || 'Unknown').trim();
        if (!art || art.toLowerCase() === 'various artists') return;
        const key = art.toLowerCase();
        const ex = artistMap.get(key);
        if (ex) {
          ex.playCount = (ex.playCount || 0) + (s.playCount || 1);
          ex.minutesListened = (ex.minutesListened || 0) + (s.minutesListened || 0);
          if (!ex.thumb && s.thumb) ex.thumb = s.thumb;
        } else {
          artistMap.set(key, {
            name: art,
            playCount: s.playCount || 1,
            minutesListened: s.minutesListened || 0,
            thumb: s.thumb,
          });
        }
      });
      // Also retain any other top artists previously tracked
      if (Array.isArray(stats.topArtists)) {
        stats.topArtists.forEach((a) => {
          if (!a || !a.name) return;
          const key = a.name.toLowerCase().trim();
          if (!artistMap.has(key)) {
            artistMap.set(key, { ...a });
          }
        });
      }

      const topArtists = Array.from(artistMap.values()).sort(
        (a, b) => ((b.minutesListened || 0) * 3 + (b.playCount || 0) * 2) - ((a.minutesListened || 0) * 3 + (a.playCount || 0) * 2)
      );

      const updatedStats = {
        totalMinutesListened: (stats.totalMinutesListened || 0) + mins,
        totalTracksPlayed: stats.totalTracksPlayed || 0,
        topSongs: topSongs.slice(0, 50),
        topArtists: topArtists.slice(0, 30),
        lastUpdated: Date.now(),
      };

      const cloudStatsRecord = {
        id: '__mouzika_cloud_stats_v1__',
        title: '__mouzika_cloud_stats__',
        type: 'system_stats',
        displayName: prev.displayName || prev.username || globalUser,
        avatarUrl: prev.avatarUrl !== undefined ? prev.avatarUrl : null,
        email: prev.email !== undefined ? prev.email : null,
        password: (prev.password && prev.password !== 'mouzika') ? prev.password : null,
        stats: updatedStats,
        updatedAt: Date.now(),
      };

      const cleanAlbums = (prev.favouriteAlbums || []).filter(
        (a: any) => a && a.id !== '__mouzika_cloud_stats_v1__' && a.id !== '__mouzika_cloud_profile_v1__'
      );

      const updatedProf = {
        ...prev,
        stats: updatedStats,
        favouriteAlbums: [...cleanAlbums, cloudStatsRecord],
      };
      saveDeviceSettings(updatedProf);

      // Save locally immediately; batch sync periodically without hammering server on each track click
      if (globalUser && globalUser !== 'admin') {
        cacheProfileLocally(globalUser, updatedProf);
        pendingSyncProfRef.current = updatedProf;
        isSyncDirtyRef.current = true;
      }
      return updatedProf;
    });
  }, [globalUser]);

  const recordPlaybackSync = useCallback((track: Track) => {
    if (!track || !track.id) return;
    rememberListen(track);
    resumeAudioContext();

    setUserProfile((prev) => {
      const prevRecent = prev.recentlyPlayed || [];
      const matchIdx = prevRecent.findIndex((t) => t.id === track.id);

      let mergedThumb = (track.thumb && !track.thumb.startsWith('blob:') && track.thumb.trim().length > 5 && track.thumb !== FALLBACK_ART)
        ? track.thumb
        : null;

      if (!mergedThumb && matchIdx >= 0 && prevRecent[matchIdx]?.thumb && !prevRecent[matchIdx].thumb.startsWith('blob:') && prevRecent[matchIdx].thumb !== FALLBACK_ART) {
        mergedThumb = prevRecent[matchIdx].thumb;
      }
      if (!mergedThumb) {
        mergedThumb = getStoredCoverForTrack(track.id);
      }
      if (!mergedThumb && track.id.length === 11) {
        mergedThumb = `https://i.ytimg.com/vi/${track.id}/hqdefault.jpg`;
      }
      if (!mergedThumb) {
        mergedThumb = canonicalThumbUrl(track.id);
      }

      const mergedTrack = { ...track, thumb: mergedThumb };
      const updated = [mergedTrack, ...prevRecent.filter((t) => t.id !== track.id)].slice(0, 30);

      const stats = extractStatsFromProfile(prev);

      const hiddenSongIds = new Set((prev.hiddenStatsSongs || []).map((s) => s.id));
      const topSongs = [...(stats.topSongs || [])].filter((s) => !hiddenSongIds.has(s.id));

      if (!hiddenSongIds.has(track.id)) {
        const songIdx = topSongs.findIndex((s) => s.id === track.id);
        if (songIdx >= 0) {
          topSongs[songIdx] = {
            ...topSongs[songIdx],
            playCount: (topSongs[songIdx].playCount || 0) + 1,
            lastPlayed: Date.now(),
          };
        } else {
          topSongs.push({
            id: track.id,
            title: track.title,
            artist: track.artist,
            thumb: mergedThumb,
            playCount: 1,
            minutesListened: 1,
            lastPlayed: Date.now(),
          });
        }
        topSongs.sort((a, b) => ((b.playCount || 0) * 3 + (b.minutesListened || 0)) - ((a.playCount || 0) * 3 + (a.minutesListened || 0)));
      }

      const updatedStats = {
        ...stats,
        totalTracksPlayed: (stats.totalTracksPlayed || 0) + 1,
        topSongs: topSongs.slice(0, 50),
        lastUpdated: Date.now(),
      };

      const cloudStatsRecord = {
        id: '__mouzika_cloud_stats_v1__',
        title: '__mouzika_cloud_stats__',
        type: 'system_stats',
        displayName: prev.displayName || prev.username || globalUser,
        avatarUrl: prev.avatarUrl !== undefined ? prev.avatarUrl : null,
        email: prev.email !== undefined ? prev.email : null,
        password: (prev.password && prev.password !== 'mouzika') ? prev.password : null,
        stats: updatedStats,
        updatedAt: Date.now(),
      };

      const cleanAlbums = (prev.favouriteAlbums || []).filter(
        (a: any) => a && a.id !== '__mouzika_cloud_stats_v1__' && a.id !== '__mouzika_cloud_profile_v1__'
      );

      const updatedProf = {
        ...prev,
        recentlyPlayed: updated,
        stats: updatedStats,
        favouriteAlbums: [...cleanAlbums, cloudStatsRecord],
      };
      saveDeviceSettings(updatedProf);

      // Keep last played track synchronized in storage with recentlyPlayed
      try {
        localStorage.setItem('mouzika_last_played_track', JSON.stringify(mergedTrack));
      } catch {}

      // Keep activeTrack synchronized with the verified merged cover
      setActiveTrack((current) => {
        if (current && current.id === track.id) {
          return { ...current, thumb: mergedThumb };
        }
        return current;
      });

      // Save locally immediately; batch sync periodically without hammering server on each track click
      if (globalUser && globalUser !== 'admin') {
        cacheProfileLocally(globalUser, updatedProf);
        pendingSyncProfRef.current = updatedProf;
        isSyncDirtyRef.current = true;
      }
      return updatedProf;
    });
  }, [globalUser]);

  // Primary playback execution
  const playTrack = async (track: Track, fromQueue = false): Promise<boolean> => {
    if (!track || !track.id) return false;

    // Playback Gating: Unapproved/Disabled accounts cannot play tracks
    if (userProfile.enabled === false) {
      setIsAccountDisabledModalOpen(true);
      showToast(t('modal.accountDisabledToast', 'Account not enabled. Please contact an administrator.'), true);
      return false;
    }

    const audio = audioRef.current;
    if (!audio) return false;

    // Claim playback lease asynchronously without blocking playback
    sessionManager.claimPlaybackLease({
      id: track.id,
      title: track.title,
      artist: track.artist,
    }).catch(() => {});

    // Mark user playback intent and track loading transition
    userIntentPlayingRef.current = true;
    isLoadingTrackRef.current = true;
    lastTrackTransitionTimeRef.current = Date.now();
    hasNudgedTransitionRef.current = false;
    audio.muted = false;
    audio.volume = (volumeRef.current || 50) / 100;
    ensureCarrierActive();

    // Immediately anchor MediaSession metadata and declare 'playing' state to OS
    // Crucial for Android 17 / One UI 9 Background Audio Hardening and iOS WebKit audio persistence
    updateMediaSession(track);
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'playing';
      if ('setPositionState' in navigator.mediaSession) {
        try {
          navigator.mediaSession.setPositionState({
            duration: track.duration || 180,
            playbackRate: 1,
            position: 0.001,
          });
        } catch {}
      }
    }

    hasPrefetchedNextRef.current = false;
    const token = ++playTokenRef.current;

    // Safety timeout: ensure isLoadingTrackRef is never stuck true even if network or candidate resolution lags
    const loadingSafetyTimer = setTimeout(() => {
      if (token === playTokenRef.current) {
        isLoadingTrackRef.current = false;
      }
    }, 3500);

    // When playing directly from outside queue (search or home), create autoplay queue
    if (!fromQueue) {
      setPlaybackQueue([track]);
      setQueueIndex(0);
      generateRadioQueue(track);
    }

    // Push to history
    if (activeTrack && activeTrack.id !== track.id) {
      playedHistoryRef.current.push(activeTrack);
      if (playedHistoryRef.current.length > 50) playedHistoryRef.current.shift();
    }

    // Ensure we never store a dead blob URL into persistent storage and recover best available cover
    const safeInitialThumb = (track.thumb && !track.thumb.startsWith('blob:') && track.thumb.trim().length > 5 && track.thumb !== FALLBACK_ART)
      ? track.thumb
      : (userProfile.recentlyPlayed?.find((t) => t.id === track.id)?.thumb ||
         userProfile.likedSongs?.find((t) => t.id === track.id)?.thumb ||
         getStoredCoverForTrack(track.id) ||
         (track.id.length === 11 ? `https://i.ytimg.com/vi/${track.id}/hqdefault.jpg` : canonicalThumbUrl(track.id)));
    const persistentInitialTrack = { ...track, thumb: safeInitialThumb };

    setActiveTrack(persistentInitialTrack);
    setIsMiniPlayerDismissed(false);
    try {
      localStorage.setItem('mouzika_last_played_track', JSON.stringify(persistentInitialTrack));
    } catch {}
    setIsBuffering(true);
    setCurrentTime(0);

    // Lyrics Resolver with Instant Offline Cache Fallback
    const resolveTrackLyrics = async (targetTrack: Track, targetDuration?: number): Promise<LyricsData> => {
      if (!targetTrack || !targetTrack.id) return { mode: 'none' };
      
      // 1. Check if stored in offline downloads first (instant offline availability)
      try {
        const offlineLyrics = await getDownloadedLyrics(targetTrack.id);
        if (offlineLyrics && (offlineLyrics.mode === 'synced' || offlineLyrics.mode === 'plain')) {
          return offlineLyrics;
        }
      } catch {}

      // 2. Online fetch if network is available
      try {
        const fetched = await fetchLyricsForTrack(targetTrack, targetDuration);
        if (fetched && (fetched.mode === 'synced' || fetched.mode === 'plain')) {
          // If the track is downloaded, persist these fetched lyrics to IndexedDB
          if (isDownloaded(targetTrack.id)) {
            saveDownloadLyrics(targetTrack.id, fetched).catch(() => {});
          }
          return fetched;
        }
      } catch {}

      // 3. Fallback to offline download record if network query failed
      try {
        const offlineLyrics = await getDownloadedLyrics(targetTrack.id);
        if (offlineLyrics && offlineLyrics.mode && offlineLyrics.mode !== 'none') {
          return offlineLyrics;
        }
      } catch {}

      return { mode: 'none' };
    };

    // Reset lyrics and resolve with offline priority
    setCurrentLyrics({ mode: 'loading' });
    resolveTrackLyrics(track, track.duration).then((l) => {
      if (token === playTokenRef.current) {
        setCurrentLyrics(l);
      }
    });

    // Safely defer previous blob URL revocation so ongoing chunks are never cut off mid-decode
    const oldBlob = activeBlobUrlRef.current;
    if (oldBlob) {
      setTimeout(() => {
        try { URL.revokeObjectURL(oldBlob); } catch {}
      }, 15000);
      activeBlobUrlRef.current = null;
    }

    // 1. Offline playback if downloaded
    if (isDownloaded(track.id)) {
      try {
        const record = await getDownload(track.id);
        if (record?.audioBlob) {
          const blobUrl = URL.createObjectURL(record.audioBlob);
          activeBlobUrlRef.current = blobUrl;
          if (token !== playTokenRef.current) return false;
          clearTimeout(loadingSafetyTimer);
          audio.loop = Boolean(isLoopingRef.current);
          audio.src = blobUrl;
          audio.play().catch(() => {});

          isLoadingTrackRef.current = false;
          userIntentPlayingRef.current = true;
          setIsBuffering(false);

          let activeThumb = safeInitialThumb;
          if (record.thumbLowRes) {
            try {
              activeThumb = URL.createObjectURL(record.thumbLowRes);
            } catch {}
          }
          // Note: Keep track.thumb persistent (do not store blob: URL in profile/recentlyPlayed)
          const playingTrack = { ...track, thumb: activeThumb };
          const persistentTrack = { ...track, thumb: safeInitialThumb };
          setActiveTrack(playingTrack);
          recordPlaybackSync(persistentTrack);
          updateMediaSession(playingTrack);
          try {
            localStorage.setItem('mouzika_last_played_track', JSON.stringify(persistentTrack));
          } catch {}
          return true;
        }
      } catch (err) {
        console.warn('Failed to play offline download, falling back to online streams:', err);
      }
    }

    // 2. Memory cached stream URL check
    const cachedUrl = getCachedStreamUrl(track.id);
    if (cachedUrl) {
      if (token !== playTokenRef.current) return false;
      clearTimeout(loadingSafetyTimer);
      audio.loop = Boolean(isLoopingRef.current);
      audio.src = cachedUrl;
      audio.play().catch(() => {});
      isLoadingTrackRef.current = false;
      userIntentPlayingRef.current = true;
      setIsBuffering(false);
      recordPlaybackSync(persistentInitialTrack);
      updateMediaSession(persistentInitialTrack);
      return true;
    }

    // 3. Fast Parallel Resolving with Startup Race Protection & Low-Network Notification
    const level = userProfile.dataSaverLevel || 'off';
    const quality = level === 'ultra' ? '48' : level === 'saver' ? '96' : '320';
    const cleanedArtist = cleanArtistName(track.artist);
    let resolvedTrack = { ...track, thumb: safeInitialThumb };

    // Gentle loading feedback if page or network is slow/loading
    const slowNoticeTimer = setTimeout(() => {
      if (token === playTokenRef.current && audioRef.current?.paused) {
        showToast(t('player.connecting', 'Connecting to audio stream... Please wait'), true);
      }
    }, 1400);

    // If track has an imported ID (like Spotify "sp_...") or is still resolving metadata, resolve properly
    if (!resolvedTrack.id || resolvedTrack.title === 'Loading...' || resolvedTrack.id.startsWith('sp_') || resolvedTrack.id.length !== 11) {
      try {
        const queryTerm = `${resolvedTrack.title !== 'Loading...' ? resolvedTrack.title : ''} ${cleanedArtist}`.trim();
        if (queryTerm) {
          const found = await searchTracks(queryTerm, 'song');
          if (found.length > 0 && found[0].id) {
            resolvedTrack.id = found[0].id;
            if (!resolvedTrack.thumb || resolvedTrack.thumb === FALLBACK_ART) resolvedTrack.thumb = found[0].thumb || safeInitialThumb;
            if (resolvedTrack.title === 'Loading...') resolvedTrack.title = found[0].title;
          }
        }
      } catch {}
    }

    const candidates: string[] = [];

    // Parallel Stream Resolution across Worker Proxy, JioSaavn and Global Invidious/Piped Mirrors
    const [workerUrl, saavnUrl, mirrors] = await Promise.all([
      resolveWorkerStream(resolvedTrack.id).catch(() => null),
      resolveSaavnStream(
        cleanTitleForLyrics(resolvedTrack.title) || resolvedTrack.title,
        cleanedArtist,
        quality,
        resolvedTrack.title,
        resolvedTrack.artist
      ).catch(() => null),
      resolveMirrorStreams(resolvedTrack.id).catch(() => []),
    ]);

    if (workerUrl) candidates.push(workerUrl);
    if (saavnUrl) candidates.push(saavnUrl);
    if (mirrors && mirrors.length > 0) candidates.push(...mirrors);

    if (token !== playTokenRef.current) {
      clearTimeout(slowNoticeTimer);
      return false;
    }

    // Startup Race Condition Deferral: fallback search if no candidates were found
    if (candidates.length === 0) {
      try {
        const fallbackSearch = await searchTracks(`${resolvedTrack.title} ${cleanedArtist}`, 'song').catch(() => []);
        if (fallbackSearch.length > 0 && fallbackSearch[0].id) {
          const fbTrack = fallbackSearch[0];
          const [altWorker, altSaavn, altMirrors] = await Promise.all([
            resolveWorkerStream(fbTrack.id).catch(() => null),
            resolveSaavnStream(
              cleanTitleForLyrics(fbTrack.title) || fbTrack.title,
              cleanArtistName(fbTrack.artist),
              quality,
              fbTrack.title,
              fbTrack.artist
            ).catch(() => null),
            resolveMirrorStreams(fbTrack.id).catch(() => []),
          ]);
          if (altWorker) candidates.push(altWorker);
          if (altSaavn) candidates.push(altSaavn);
          if (altMirrors && altMirrors.length > 0) candidates.push(...altMirrors);
        }
      } catch {}
    }

    if (candidates.length === 0) {
      clearTimeout(slowNoticeTimer);
      if (token === playTokenRef.current) {
        setIsBuffering(false);
        try {
          audio.pause();
        } catch {}
        showToast('Sources are resolving. Please wait a moment or tap track again.', true);
      }
      return false;
    }

    // Play first working candidate
    let ok = await tryPlayCandidates(candidates, token, resolvedTrack.id, 0);

    // Auto-retry once with refreshed mirror list if first cycle had a network warmup hiccup
    if (!ok && token === playTokenRef.current) {
      try {
        const freshMirrors = await resolveMirrorStreams(resolvedTrack.id).catch(() => []);
        if (freshMirrors.length > 0) {
          ok = await tryPlayCandidates(freshMirrors, token, resolvedTrack.id, 0);
        }
      } catch {}
    }

    clearTimeout(slowNoticeTimer);
    clearTimeout(loadingSafetyTimer);
    if (token !== playTokenRef.current) return false;

    if (ok) {
      isLoadingTrackRef.current = false;
      userIntentPlayingRef.current = true;
      setIsBuffering(false);
      setActiveTrack(resolvedTrack);
      recordPlaybackSync(resolvedTrack);
      updateMediaSession(resolvedTrack);
      try {
        localStorage.setItem('mouzika_last_played_track', JSON.stringify(resolvedTrack));
      } catch {}
      // Auto cache if enabled
      if (userProfile.autoCachePlayed && !isDownloaded(resolvedTrack.id)) {
        setTimeout(() => {
          downloadTrack(resolvedTrack, true, true).catch(() => {});
        }, 3000);
      }
      return true;
    } else {
      isLoadingTrackRef.current = false;
      setIsBuffering(false);
      try {
        audio.pause();
      } catch {}
      showToast('Playback connection issue. Tap track to retry.', true);
      return false;
    }
  };

  useEffect(() => {
    playTrackRef.current = playTrack;
  });

  const updateMediaSession = (t: Track) => {
    if (!('mediaSession' in navigator)) return;

    let artUrl = t.thumb || FALLBACK_ART;
    // Upgrade JioSaavn thumbnails to 500x500 square HD
    if (artUrl.includes('150x150.jpg')) {
      artUrl = artUrl.replace('150x150.jpg', '500x500.jpg');
    } else if (artUrl.includes('50x50.jpg')) {
      artUrl = artUrl.replace('50x50.jpg', '500x500.jpg');
    } else if (!artUrl.startsWith('blob:') && !artUrl.startsWith('data:')) {
      // Crop to perfect 512x512 square so Samsung/Android/iOS lock screen displays crisp full square artwork
      try {
        if (artUrl.includes('wsrv.nl/?url=')) {
          const parsed = new URL(artUrl);
          parsed.searchParams.set('w', '512');
          parsed.searchParams.set('h', '512');
          parsed.searchParams.set('fit', 'cover');
          artUrl = parsed.toString();
        } else {
          artUrl = `https://wsrv.nl/?url=${encodeURIComponent(artUrl)}&w=512&h=512&fit=cover`;
        }
      } catch {}
    }

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: t.title,
        artist: t.artist,
        album: t.album || 'MOUZIKETNA',
        artwork: [
          { src: artUrl, sizes: '96x96', type: 'image/jpeg' },
          { src: artUrl, sizes: '128x128', type: 'image/jpeg' },
          { src: artUrl, sizes: '192x192', type: 'image/jpeg' },
          { src: artUrl, sizes: '256x256', type: 'image/jpeg' },
          { src: artUrl, sizes: '384x384', type: 'image/jpeg' },
          { src: artUrl, sizes: '512x512', type: 'image/jpeg' },
        ],
      });
      navigator.mediaSession.playbackState = 'playing';

      navigator.mediaSession.setActionHandler('play', () => {
        userIntentPlayingRef.current = true;
        ensureCarrierActive();
        if (audioRef.current && audioRef.current.paused) {
          audioRef.current.play().catch(() => {});
        }
        setIsPlaying(true);
        if ('mediaSession' in navigator) {
          navigator.mediaSession.playbackState = 'playing';
        }
      });
      navigator.mediaSession.setActionHandler('pause', () => {
        userIntentPlayingRef.current = false;
        if (carrierAudioRef.current && !carrierAudioRef.current.paused) {
          carrierAudioRef.current.pause();
        }
        if (audioRef.current && !audioRef.current.paused) {
          audioRef.current.pause();
        }
        setIsPlaying(false);
        releaseWakeLock();
        if ('mediaSession' in navigator) {
          navigator.mediaSession.playbackState = 'paused';
        }
      });
      navigator.mediaSession.setActionHandler('stop', () => {
        userIntentPlayingRef.current = false;
        if (carrierAudioRef.current && !carrierAudioRef.current.paused) {
          carrierAudioRef.current.pause();
        }
        if (audioRef.current && !audioRef.current.paused) {
          audioRef.current.pause();
        }
        setIsPlaying(false);
        releaseWakeLock();
        if ('mediaSession' in navigator) {
          navigator.mediaSession.playbackState = 'paused';
        }
      });
      navigator.mediaSession.setActionHandler('nexttrack', playNext);
      navigator.mediaSession.setActionHandler('previoustrack', playPrevious);
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined) seekTo(details.seekTime);
      });
      navigator.mediaSession.setActionHandler('seekbackward', (details) => {
        seekBy(-(details.seekOffset || 10));
      });
      navigator.mediaSession.setActionHandler('seekforward', (details) => {
        seekBy(details.seekOffset || 10);
      });
    } catch {}
  };

  const togglePlay = async () => {
    if (userProfile.enabled === false) {
      setIsAccountDisabledModalOpen(true);
      showToast(t('modal.accountDisabledToast', 'Account not enabled. Please contact an administrator.'), true);
      return;
    }

    if (isRemotePlaybackActive) {
      if (isPlaying) {
        // Remotely playing: send pause command across account to pause it for him!
        sessionManager.sendRemotePause();
        setIsPlaying(false);
      } else {
        // Remotely paused: transfer audio here and resume!
        await claimPlaybackHere();
      }
      return;
    }
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      userIntentPlayingRef.current = true;
      ensureCarrierActive();
      setSupersededNotice(null);
      setIsRemotePlaybackActive(false);
      setRemoteDeviceName(null);
      setIsPlaying(true);
      setIsBuffering(false);

      // Claim lease asynchronously without blocking audio play
      sessionManager.claimPlaybackLease(activeTrack || undefined, currentTime).catch(() => {});
      resumeAudioContext();

      if (audio.error || !audio.src || audio.networkState === HTMLMediaElement.NETWORK_NO_SOURCE) {
        if (activeTrack) {
          const resumePos = currentTime;
          playTrack(activeTrack, true).then((ok) => {
            if (ok && resumePos > 0 && audioRef.current) {
              audioRef.current.currentTime = resumePos;
            }
          });
          return;
        }
      }
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Audio play() error, reloading track:', err);
          if (activeTrack) {
            const resumePos = currentTime;
            playTrack(activeTrack, true).then((ok) => {
              if (ok && resumePos > 0 && audioRef.current) {
                audioRef.current.currentTime = resumePos;
              }
            });
          }
        });
      }
    } else {
      userIntentPlayingRef.current = false;
      if (carrierAudioRef.current && !carrierAudioRef.current.paused) {
        carrierAudioRef.current.pause();
      }
      audio.pause();
      setIsPlaying(false);
      releaseWakeLock();
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'paused';
      }
      sessionManager.releasePlaybackLease();
    }
  };

  const seekTo = (time: number) => {
    const audio = audioRef.current;
    if (!audio || !isFinite(audio.duration) || audio.duration <= 0) return;
    const targetTime = Math.max(0, Math.min(audio.duration, time));

    // Cancel any previous seek timer
    if (seekDebounceTimerRef.current) {
      clearTimeout(seekDebounceTimerRef.current);
      seekDebounceTimerRef.current = null;
    }

    isSeekingRef.current = true;
    lastSeekTimestampRef.current = Date.now();

    // Immediately synchronize UI scrub position for zero perceived latency
    setCurrentTime(targetTime);
    setIsBuffering(false);
    try {
      localStorage.setItem('mouzika_last_played_pos', String(Math.floor(targetTime)));
    } catch {}

    if (Math.abs(audio.currentTime - targetTime) < 0.05) {
      isSeekingRef.current = false;
      return;
    }

    // Set currentTime directly for exact target point precision
    try {
      if ('fastSeek' in audio && typeof (audio as any).fastSeek === 'function') {
        (audio as any).fastSeek(targetTime);
      } else {
        audio.currentTime = targetTime;
      }
    } catch (err) {
      try {
        audio.currentTime = targetTime;
      } catch (e) {
        console.warn('Direct currentTime seek error:', e);
      }
    }

    // Keep isSeekingRef true for a safety window so transient aborted socket errors from previous range requests are suppressed
    seekDebounceTimerRef.current = window.setTimeout(() => {
      isSeekingRef.current = false;
      setIsBuffering(false);
    }, 1200);
  };

  const seekBy = (delta: number) => {
    const audio = audioRef.current;
    if (audio) {
      seekTo(audio.currentTime + delta);
    }
  };

  const setVolumeLevel = (vol: number) => {
    const v = Math.max(0, Math.min(100, vol));
    setVolume(v);
    volumeRef.current = v;
    setIsMuted(v === 0);
    try {
      localStorage.setItem('hub_volume', String(v));
    } catch {}
    setBaseAudioVolume(v);
    if (audioRef.current) {
      audioRef.current.volume = v / 100;
      audioRef.current.muted = v === 0;
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setVolumeLevel(volume || 50);
    } else {
      setVolumeLevel(0);
    }
  };

  const toggleLoop = () => {
    setIsLooping((prev) => {
      const next = !prev;
      isLoopingRef.current = next;
      if (audioRef.current) audioRef.current.loop = next;
      return next;
    });
  };

  const toggleShuffle = () => {
    setIsShuffle((prev) => {
      const next = !prev;
      isShuffleRef.current = next;
      return next;
    });
  };

  const playNext = async () => {
    const queue = playbackQueueRef.current;
    const idx = queueIndexRef.current;
    const shuffle = isShuffleRef.current;
    const active = activeTrackRef.current;

    let nextTrackToPlay: Track | null = null;
    let targetIdx = idx;

    if (queue && queue.length > 0) {
      if (shuffle) {
        targetIdx = Math.floor(Math.random() * queue.length);
        nextTrackToPlay = queue[targetIdx];
      } else if (idx >= 0 && idx < queue.length - 1) {
        targetIdx = idx + 1;
        nextTrackToPlay = queue[targetIdx];
      } else if (active) {
        // Queue reached end: check if preloaded algorithm track is ready
        if (preloadedNextRef.current && preloadedNextRef.current.track.id !== active.id) {
          nextTrackToPlay = preloadedNextRef.current.track;
          const newQueue = [...queue, nextTrackToPlay];
          setPlaybackQueue(newQueue);
          playbackQueueRef.current = newQueue;
          targetIdx = newQueue.length - 1;
        }
      }
    } else if (active) {
      if (preloadedNextRef.current && preloadedNextRef.current.track.id !== active.id) {
        nextTrackToPlay = preloadedNextRef.current.track;
        setPlaybackQueue([nextTrackToPlay]);
        playbackQueueRef.current = [nextTrackToPlay];
        targetIdx = 0;
      }
    }

    const preloaded = preloadedNextRef.current;
    const audio = audioRef.current;

    // SYNCHRONOUS MEDIA CHAINING (ZERO ASYNC TICK):
    // If next track is pre-resolved and audio element is ready, execute immediate source swap and play()!
    // This executes synchronously within the ended / near-end handler, preserving browser user-activation
    // and preventing Android 17 / One UI 9 background audio freeze!
    if (audio && preloaded && nextTrackToPlay && preloaded.track.id === nextTrackToPlay.id) {
      preloadedNextRef.current = null;
      setQueueIndex(targetIdx);
      queueIndexRef.current = targetIdx;

      // Safely defer previous blob URL revocation so ongoing chunks are never cut off mid-decode
      const oldBlob = activeBlobUrlRef.current;
      if (oldBlob && oldBlob !== preloaded.url) {
        setTimeout(() => {
          try { URL.revokeObjectURL(oldBlob); } catch {}
        }, 15000);
      }
      if (preloaded.isBlob) {
        activeBlobUrlRef.current = preloaded.url;
      }

      lastTrackTransitionTimeRef.current = Date.now();
      hasNudgedTransitionRef.current = false;
      ensureCarrierActive();

      // Synchronously set volume, un-mute, src, loop, and call play()
      audio.loop = Boolean(isLoopingRef.current);
      audio.muted = false;
      audio.volume = (volumeRef.current || 50) / 100;
      audio.src = preloaded.url;
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {});
      }

      // Synchronously update MediaSession with next track
      updateMediaSession(preloaded.track);
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'playing';
        if ('setPositionState' in navigator.mediaSession) {
          try {
            navigator.mediaSession.setPositionState({
              duration: preloaded.track.duration || 180,
              playbackRate: 1,
              position: 0.001,
            });
          } catch {}
        }
      }

      setActiveTrack(preloaded.track);
      userIntentPlayingRef.current = true;
      isLoadingTrackRef.current = false;
      setIsBuffering(false);
      setCurrentTime(0);

      // Non-blocking async background operations
      recordPlaybackSync(preloaded.track);
      sessionManager.claimPlaybackLease({
        id: preloaded.track.id,
        title: preloaded.track.title,
        artist: preloaded.track.artist,
      }).catch(() => {});
      try {
        localStorage.setItem('mouzika_last_played_track', JSON.stringify(preloaded.track));
      } catch {}

      // Reset prefetch flag so onTimeUpdate will safely prefetch next track at 12s without competing for initial startup bandwidth
      hasPrefetchedNextRef.current = false;

      return;
    }

    // Fallback: standard playTrack flow if preloaded track was not ready
    if (nextTrackToPlay) {
      setQueueIndex(targetIdx);
      queueIndexRef.current = targetIdx;
      const ok = await playTrack(nextTrackToPlay, true);
      if (!ok && queue && queue.length > 1) {
        const fallbackIdx = (targetIdx + 1) % queue.length;
        setQueueIndex(fallbackIdx);
        queueIndexRef.current = fallbackIdx;
        await playTrack(queue[fallbackIdx], true);
      }
    } else if (active) {
      const next = await getNextAlgorithmTrack(active);
      if (next) {
        const newQueue = queue ? [...queue, next] : [next];
        setPlaybackQueue(newQueue);
        playbackQueueRef.current = newQueue;
        const nIdx = newQueue.length - 1;
        setQueueIndex(nIdx);
        queueIndexRef.current = nIdx;
        await playTrack(next, true);
      } else if (queue && queue.length > 0) {
        setQueueIndex(0);
        queueIndexRef.current = 0;
        await playTrack(queue[0], true);
      }
    }
  };

  const playPrevious = async () => {
    const audio = audioRef.current;
    if (audio && audio.currentTime > 3) {
      audio.currentTime = 0;
      setCurrentTime(0);
      return;
    }

    const queue = playbackQueueRef.current;
    const idx = queueIndexRef.current;
    const shuffle = isShuffleRef.current;

    if (queue && queue.length > 0) {
      if (shuffle) {
        const prevIdx = Math.floor(Math.random() * queue.length);
        setQueueIndex(prevIdx);
        queueIndexRef.current = prevIdx;
        await playTrack(queue[prevIdx], true);
        return;
      } else if (idx > 0) {
        const prevIdx = idx - 1;
        setQueueIndex(prevIdx);
        queueIndexRef.current = prevIdx;
        await playTrack(queue[prevIdx], true);
        return;
      }
    }

    if (playedHistoryRef.current.length > 0) {
      const prev = playedHistoryRef.current.pop();
      if (prev) {
        await playTrack(prev);
        return;
      }
    }

    if (audio) {
      audio.currentTime = 0;
      setCurrentTime(0);
    }
  };

  useEffect(() => {
    playbackQueueRef.current = playbackQueue;
  }, [playbackQueue]);

  useEffect(() => {
    queueIndexRef.current = queueIndex;
  }, [queueIndex]);

  useEffect(() => {
    activeTrackRef.current = activeTrack;
  }, [activeTrack]);

  useEffect(() => {
    isShuffleRef.current = isShuffle;
  }, [isShuffle]);

  useEffect(() => {
    isLoopingRef.current = isLooping;
  }, [isLooping]);

  useEffect(() => {
    volumeRef.current = volume;
  }, [volume]);

  useEffect(() => {
    playNextRef.current = playNext;
    playPreviousRef.current = playPrevious;
  });

  const addToQueue = (track: Track, playNext = false) => {
    setPlaybackQueue((prev) => {
      const filtered = prev.filter((t) => t.id !== track.id);
      if (playNext) {
        const insertAt = queueIndex >= 0 ? queueIndex + 1 : 0;
        const copy = [...filtered];
        copy.splice(insertAt, 0, track);
        playbackQueueRef.current = copy;
        return copy;
      }
      const copy = [...filtered, track];
      playbackQueueRef.current = copy;
      return copy;
    });
  };

  const removeFromQueue = (idx: number) => {
    setPlaybackQueue((prev) => {
      const copy = prev.filter((_, i) => i !== idx);
      playbackQueueRef.current = copy;
      return copy;
    });
    if (idx < queueIndex) {
      setQueueIndex((q) => {
        const next = q - 1;
        queueIndexRef.current = next;
        return next;
      });
    }
  };

  const clearQueue = () => {
    setPlaybackQueue([]);
    playbackQueueRef.current = [];
    setQueueIndex(-1);
    queueIndexRef.current = -1;
  };

  const playQueueIndex = (idx: number) => {
    if (idx >= 0 && idx < playbackQueue.length) {
      setQueueIndex(idx);
      queueIndexRef.current = idx;
      playTrack(playbackQueue[idx], true);
    }
  };

  const playWholeCollection = (tracks: Track[]) => {
    if (!tracks.length) return;
    setPlaybackQueue(tracks);
    playbackQueueRef.current = tracks;
    setQueueIndex(0);
    queueIndexRef.current = 0;
    playTrack(tracks[0], true);
  };

  const playShuffledCollection = (tracks: Track[]) => {
    if (!tracks.length) return;
    const shuffled = [...tracks].sort(() => Math.random() - 0.5);
    setPlaybackQueue(shuffled);
    playbackQueueRef.current = shuffled;
    setQueueIndex(0);
    queueIndexRef.current = 0;
    setIsShuffle(true);
    isShuffleRef.current = true;
    playTrack(shuffled[0], true);
  };

  const playCollectionFromIndex = (tracks: Track[], index: number) => {
    if (!tracks.length) return;
    const clampedIndex = Math.max(0, Math.min(index, tracks.length - 1));
    setPlaybackQueue(tracks);
    playbackQueueRef.current = tracks;
    setQueueIndex(clampedIndex);
    queueIndexRef.current = clampedIndex;
    playTrack(tracks[clampedIndex], true);
  };

  // Downloads Engine
  const downloadTrack = async (
    track: Track,
    silent = false,
    isAutoCache = false
  ): Promise<boolean> => {
    if (!track?.id) return false;

    // Calculate quality target
    let quality: '320' | '160' | '96' | '48' = '160';
    if (isAutoCache) {
      const ac = userProfile.autoCacheQuality || 'stable';
      quality = ac === 'high' ? '320' : ac === 'ultra' ? '48' : ac === 'saver' ? '96' : '160';
    } else {
      const dq =
        userProfile.downloadQuality ||
        (userProfile.dataSaverLevel === 'ultra'
          ? 'ultra'
          : userProfile.dataSaverLevel === 'saver'
          ? 'saver'
          : 'stable');
      quality = dq === 'high' ? '320' : dq === 'ultra' ? '48' : dq === 'saver' ? '96' : '160';
    }

    const currentQuality = getDownloadQuality(track.id);

    if (isDownloaded(track.id)) {
      // Check if user is manually upgrading a saver quality track to high quality
      if (!isAutoCache && (currentQuality === '96' || currentQuality === '48') && quality === '320') {
        if (!silent) showToast(`Upgrading "${track.title}" to High Quality (320 kbps)…`);
      } else {
        if (!silent) {
          const isHigh = currentQuality === '320' || currentQuality === 'high';
          showToast(`Already downloaded (${isHigh ? 'High Quality' : 'Saver Quality'})`);
        }
        return true;
      }
    } else {
      if (!silent) showToast(`Downloading "${track.title}"…`);
    }

    ensurePersistentStorageOnce();
    const cleanedArtist = cleanArtistName(track.artist);

    // Resolve real YouTube ID if track has external/Spotify ID
    let ytTrackId = track.id;
    if (!ytTrackId || ytTrackId.startsWith('sp_') || ytTrackId.length !== 11) {
      try {
        const found = await searchTracks(`${track.title} ${cleanedArtist}`, 'song');
        if (found.length > 0 && found[0].id) {
          ytTrackId = found[0].id;
          if (!track.thumb) track.thumb = found[0].thumb;
        }
      } catch {}
    }

    try {
      const candidates: string[] = [];

      // 1. Cached in-memory stream if available
      const cached = getCachedStreamUrl(track.id);
      if (cached) candidates.push(cached);

      // 2. Parallel stream resolution for maximum speed (Saavn + Mirrors + Worker proxy)
      const [saavnRes, mirrorRes, workerRes] = await Promise.allSettled([
        resolveSaavnStream(
          cleanTitleForLyrics(track.title) || track.title,
          cleanedArtist,
          quality,
          track.title,
          track.artist
        ),
        resolveMirrorStreams(ytTrackId || track.id),
        fetchWithTimeout(`${NEW_HUB_BACKEND}/api/stream-proxy/${ytTrackId || track.id}`, 6000).then(async (r) => {
          if (!r.ok) return null;
          const j = await r.json();
          const audio = (j?.adaptiveFormats || []).filter((f: any) => f.type && f.type.startsWith('audio'));
          if (audio.length) {
            audio.sort((a: any, b: any) => parseInt(b.bitrate) - parseInt(a.bitrate));
            return audio[0].url;
          }
          return null;
        }),
      ]);

      if (saavnRes.status === 'fulfilled' && saavnRes.value && !candidates.includes(saavnRes.value)) {
        candidates.push(saavnRes.value);
      }
      if (workerRes.status === 'fulfilled' && workerRes.value && !candidates.includes(workerRes.value)) {
        candidates.push(workerRes.value);
      }
      if (mirrorRes.status === 'fulfilled' && Array.isArray(mirrorRes.value)) {
        for (const m of mirrorRes.value) {
          if (m && !candidates.includes(m)) {
            candidates.push(m);
          }
        }
      }

      if (candidates.length === 0) throw new Error('No stream source available');

      // Attempt to download audio from candidate sources with fast timeout
      let audioBlob: Blob | null = null;
      for (const url of candidates) {
        try {
          const res = await fetchWithTimeout(url, 12000);
          if (res.ok) {
            const blob = await res.blob();
            if (blob && blob.size > 2000) {
              audioBlob = blob;
              break;
            }
          }
        } catch {}
      }

      if (!audioBlob) throw new Error('Failed to download audio content');

      // Parallel fetch for offline artwork and lyrics (non-blocking)
      const [artResult, lyricsResult] = await Promise.allSettled([
        userProfile.downloadArtOffline !== false
          ? fetchArtworkBlob(ytTrackId || track.id, track.thumb, userProfile.artQualityOffline || 'low')
          : Promise.resolve(null),
        userProfile.downloadLyricsOffline !== false
          ? fetchLyricsForTrack(track)
          : Promise.resolve(null),
      ]);

      const thumbBlob = artResult.status === 'fulfilled' ? artResult.value : null;
      const lyricsData = lyricsResult.status === 'fulfilled' ? lyricsResult.value : null;

      const record: DownloadRecord = {
        id: track.id,
        title: track.title,
        artist: track.artist,
        thumbLowRes: thumbBlob,
        audioBlob,
        quality,
        lyricsData,
        sizeBytes: (audioBlob.size || 0) + (thumbBlob?.size || 0),
        downloadedAt: Date.now(),
      };

      await saveDownload(record);
      setDownloadedSet((prev) => new Set([...prev, track.id]));
      if (!silent) {
        showToast(
          quality === '320'
            ? `Downloaded "${track.title}" (320 kbps)`
            : `Downloaded "${track.title}" (Saver Quality)`
        );
      }
      return true;
    } catch {
      if (!silent) showToast(`Couldn't download "${track.title}"`, true);
      return false;
    }
  };

  const removeDownload = async (trackId: string) => {
    await deleteDownload(trackId);
    setDownloadedSet((prev) => {
      const next = new Set(prev);
      next.delete(trackId);
      return next;
    });
    showToast('Download removed', true);
  };

  const removeMultipleDownloads = async (trackIds: string[]) => {
    for (const id of trackIds) {
      await deleteDownload(id);
    }
    setDownloadedSet((prev) => {
      const next = new Set(prev);
      trackIds.forEach((id) => next.delete(id));
      return next;
    });
    showToast(`Removed ${trackIds.length} downloads`, true);
  };

  const clearAllDownloads = async () => {
    await deleteAllDownloads();
    setDownloadedSet(new Set());
  };

  // Concurrent Multi-Song Download Queue (3 concurrent workers)
  const downloadPlaylist = async (tracks: Track[]) => {
    const unDownloaded = tracks.filter((t) => !isDownloaded(t.id));
    if (!unDownloaded.length) {
      showToast('All tracks are already downloaded');
      return;
    }

    const total = unDownloaded.length;
    setBulkDownloadState({ done: 0, total, inProgress: true });

    let successCount = 0;
    let failCount = 0;
    let finishedCount = 0;

    const concurrency = Math.min(3, total);
    let queueIdx = 0;

    const worker = async () => {
      while (queueIdx < total) {
        const itemIdx = queueIdx++;
        const trackToDownload = unDownloaded[itemIdx];
        if (!trackToDownload) break;

        try {
          const ok = await downloadTrack(trackToDownload, true);
          if (ok) {
            successCount++;
          } else {
            failCount++;
          }
        } catch {
          failCount++;
        } finally {
          finishedCount++;
          setBulkDownloadState({
            done: finishedCount,
            total,
            inProgress: true,
          });
        }
      }
    };

    // Run 3 workers in parallel
    await Promise.all(Array.from({ length: concurrency }, () => worker()));

    setBulkDownloadState({ done: total, total, inProgress: false });

    if (failCount === 0) {
      showToast(`Downloaded all ${successCount} songs for offline listening`);
    } else if (successCount > 0) {
      showToast(`Downloaded ${successCount} songs (${failCount} unavailable on servers)`);
    } else {
      showToast(`Unable to download tracks. Please check connection.`, true);
    }
  };

  const retryLyrics = () => {
    if (activeTrack) {
      setCurrentLyrics({ mode: 'loading' });
      // Check offline store first, then LRCLIB
      getDownloadedLyrics(activeTrack.id).then((cached) => {
        if (cached && (cached.mode === 'synced' || cached.mode === 'plain')) {
          setCurrentLyrics(cached);
        } else {
          fetchLyricsForTrack(activeTrack, duration).then((fetched) => {
            setCurrentLyrics(fetched);
            if (isDownloaded(activeTrack.id) && fetched && (fetched.mode === 'synced' || fetched.mode === 'plain')) {
              saveDownloadLyrics(activeTrack.id, fetched).catch(() => {});
            }
          });
        }
      });
    }
  };

  // Sleep Timer
  const cancelSleepTimer = () => {
    if (sleepTimerIdRef.current) {
      clearInterval(sleepTimerIdRef.current);
      sleepTimerIdRef.current = null;
    }
    setSleepTimerRemaining(null);
    setSleepTimerIsEndOfSong(false);
    showToast('Sleep timer turned off', true);
  };

  const setSleepTimerMinutes = (mins: number) => {
    cancelSleepTimer();
    let leftSecs = mins * 60;
    setSleepTimerRemaining(leftSecs);
    showToast(`Sleep timer set to ${mins} minutes`);
    sleepTimerIdRef.current = setInterval(() => {
      leftSecs -= 1;
      if (leftSecs <= 0) {
        clearInterval(sleepTimerIdRef.current);
        sleepTimerIdRef.current = null;
        setSleepTimerRemaining(null);
        if (audioRef.current) audioRef.current.pause();
        showToast('Sleep timer ended', true);
      } else {
        setSleepTimerRemaining(leftSecs);
      }
    }, 1000);
  };

  const setSleepTimerEndOfSong = () => {
    cancelSleepTimer();
    setSleepTimerIsEndOfSong(true);
    showToast('Sleep timer: End of current song');
  };

  // Likes & Playlists
  const toggleLikeTrack = (track: Track) => {
    const isLiked = userProfile.likedSongs.some((s) => s.id === track.id);
    let updatedSongs: Track[] = [];
    if (isLiked) {
      updatedSongs = userProfile.likedSongs.filter((s) => s.id !== track.id);
      tasteEvent('unlike', track);
      showToast('Removed from Liked Songs', true);
    } else {
      updatedSongs = [track, ...userProfile.likedSongs];
      tasteEvent('like', track);
      showToast('Saved to Liked Songs');
    }
    syncProfile({ ...userProfile, likedSongs: updatedSongs });
  };

  const createPlaylist = (name: string, firstTrack?: Track) => {
    const pl: CustomPlaylist = {
      id: 'pl_' + Date.now(),
      name,
      tracks: firstTrack ? [firstTrack] : [],
      thumb: null,
      customCover: null,
    };
    syncProfile({ ...userProfile, customPlaylists: [pl, ...userProfile.customPlaylists] });
    showToast(`Created playlist "${name}"`);
  };

  const renamePlaylist = (plId: string, newName: string) => {
    const pl = userProfile.customPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    const cleanName = newName.trim();
    if (!cleanName) return;
    const updated = { ...pl, name: cleanName };
    syncProfile({
      ...userProfile,
      customPlaylists: userProfile.customPlaylists.map((p) => (p.id === plId ? updated : p)),
    });
    if (collectionTarget?.id === plId) {
      setCollectionTarget({ ...collectionTarget, title: cleanName });
    }
    showToast(`Playlist renamed to "${cleanName}"`);
  };

  const deletePlaylist = (plId: string) => {
    syncProfile({
      ...userProfile,
      customPlaylists: userProfile.customPlaylists.filter((p) => p.id !== plId),
    });
    if (activePane === 'collection' && collectionTarget?.id === plId) {
      setActivePane('library');
    }
    showToast('Playlist deleted', true);
  };

  const removeTrackFromPlaylist = (plId: string, trackId: string) => {
    const pl = userProfile.customPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    const updated = {
      ...pl,
      tracks: pl.tracks.filter((t) => t.id !== trackId),
    };
    syncProfile({
      ...userProfile,
      customPlaylists: userProfile.customPlaylists.map((p) => (p.id === plId ? updated : p)),
    });
    showToast('Removed from playlist', true);
  };

  const addTrackToPlaylist = (plId: string, track: Track) => {
    const pl = userProfile.customPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    if (pl.tracks.some((t) => t.id === track.id)) {
      showToast('Already in that playlist', true);
      return;
    }
    const updated = {
      ...pl,
      tracks: [...pl.tracks, track],
      thumb: pl.customCover || pl.thumb || null,
    };
    syncProfile({
      ...userProfile,
      customPlaylists: userProfile.customPlaylists.map((p) => (p.id === plId ? updated : p)),
    });
    showToast(`Added to "${pl.name}"`);
  };

  const updatePlaylistTracks = (plId: string, newTracks: Track[]) => {
    const pl = userProfile.customPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    const updated = {
      ...pl,
      tracks: newTracks,
      thumb: pl.customCover || pl.thumb || null,
    };
    syncProfile({
      ...userProfile,
      customPlaylists: userProfile.customPlaylists.map((p) => (p.id === plId ? updated : p)),
    });
  };

  const addMultipleTracksToPlaylist = (plId: string, tracksToAdd: Track[]) => {
    const pl = userProfile.customPlaylists.find((p) => p.id === plId);
    if (!pl) return;
    const existingIds = new Set(pl.tracks.map((t) => t.id));
    const uniqueNew = tracksToAdd.filter((t) => !existingIds.has(t.id));
    const updated = {
      ...pl,
      tracks: [...pl.tracks, ...uniqueNew],
      thumb: pl.customCover || pl.thumb || null,
    };
    syncProfile({
      ...userProfile,
      customPlaylists: userProfile.customPlaylists.map((p) => (p.id === plId ? updated : p)),
    });
    showToast(`Added ${uniqueNew.length} tracks to "${pl.name}"`);
  };

  const openCollection = (
    type: 'liked' | 'downloads' | 'custom-playlist' | 'artist' | 'playlist',
    id?: string | null,
    title?: string,
    thumb?: string | null,
    initialTracks?: Track[]
  ) => {
    setCollectionTarget({ type, id, title, thumb, initialTracks });
    setNavHistory((prev) => [...prev, activePane]);
    setActivePane('collection');
  };

  const goBack = () => {
    if (navHistory.length > 0) {
      const prev = navHistory[navHistory.length - 1];
      setNavHistory((h) => h.slice(0, -1));
      setActivePane(prev);
    } else {
      setActivePane('home');
    }
  };

  // Transfer playback lease back to this device (Spotify "Play Here Instead" style)
  const claimPlaybackHere = useCallback(async () => {
    setSupersededNotice(null);
    setIsRemotePlaybackActive(false);
    setRemoteDeviceName(null);
    setIsPlaying(true);
    showToast(`Playback transferred to ${sessionManager.getDeviceName()}`);

    // Claim lease to notify remote device to stop immediately
    sessionManager.claimPlaybackLease(activeTrack || undefined, currentTime).catch(() => {});

    if (audioRef.current) {
      resumeAudioContext();
      if (audioRef.current.error || !audioRef.current.src || audioRef.current.networkState === HTMLMediaElement.NETWORK_NO_SOURCE) {
        if (activeTrack) {
          playTrack(activeTrack, true);
        }
      } else {
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlaying(true);
            })
            .catch(() => {
              if (activeTrack) {
                playTrack(activeTrack, true);
              }
            });
        }
      }
    } else if (activeTrack) {
      playTrack(activeTrack, true);
    }
  }, [activeTrack, currentTime, playTrack, showToast]);

  const isSettingsUnlocked = Boolean(
    globalUser === 'admin' ||
    globalUser === 'habib' ||
    userProfile?.isSettingsUnlocked
  );

  const unlockSettingsWithSocial = async (platform: 'instagram' | 'tiktok', handle?: string) => {
    setUserProfile((prev) => {
      const next = {
        ...prev,
        isSettingsUnlocked: true,
        unlockedSocialHandle: handle || platform,
        unlockedPlatform: platform,
        unlockedAt: Date.now(),
      };
      if (globalUser) cacheProfileLocally(globalUser, next);
      return next;
    });

    const updatedProfile = {
      ...userProfile,
      isSettingsUnlocked: true,
      unlockedSocialHandle: handle || platform,
      unlockedPlatform: platform,
      unlockedAt: Date.now(),
    };

    syncProfile(updatedProfile);
    showToast('✓ Customization settings unlocked permanently!');
    return { success: true };
  };

  return (
    <MusicContext.Provider
      value={{
        activePane,
        setActivePane: (pane) => {
          setNavHistory((prev) => [...prev, activePane]);
          setActivePane(pane);
        },
        t,
        language,
        setLanguage,
        collectionTarget,
        openCollection,
        goBack,
        globalUser,
        globalPass,
        userProfile,
        setUserProfile,
        login,
        logout,
        syncProfile,
        isAuthGateOpen,
        setIsAuthGateOpen,
        isAccountSettingsOpen,
        setIsAccountSettingsOpen,
        isAccountDisabledModalOpen,
        setIsAccountDisabledModalOpen,
        updateUserPassword,
        updateUserEmail,
        adminResetUserPassword,
        activeTrack,
        isPlaying,
        isBuffering,
        currentTime,
        duration,
        volume,
        isMuted,
        isLooping,
        isShuffle,
        playbackQueue,
        queueIndex,
        playTrack,
        togglePlay,
        seekTo,
        seekBy,
        setVolumeLevel,
        toggleMute,
        toggleLoop,
        toggleShuffle,
        playNext,
        playPrevious,
        addToQueue,
        removeFromQueue,
        clearQueue,
        playQueueIndex,
        playWholeCollection,
        playShuffledCollection,
        playCollectionFromIndex,
        isFullScreenOpen,
        setIsFullScreenOpen,
        isMiniPlayerDismissed,
        setIsMiniPlayerDismissed,
        dismissMiniPlayer,
        isLandscapeStageOpen,
        setIsLandscapeStageOpen,
        isLyricsOpen,
        setIsLyricsOpen,
        isQueueOpen,
        setIsQueueOpen,
        actionSheetTrack,
        setActionSheetTrack,
        actionSheetMeta,
        setActionSheetMeta,
        modalCreatePlaylistOpen,
        setModalCreatePlaylistOpen,
        modalAddToPlaylistTrack,
        setModalAddToPlaylistTrack,
        modalImportPlaylistOpen,
        setModalImportPlaylistOpen,
        modalAddSongByLinkPlId,
        setModalAddSongByLinkPlId,
        modalAudioRecognitionOpen,
        setModalAudioRecognitionOpen,
        modalConfirm,
        setModalConfirm,
        isInstallModalOpen,
        setIsInstallModalOpen,
        hideSongFromStats,
        unhideSongFromStats,
        tuneMusicTaste,
        removeTrackFromTaste,
        isTuneInterested,
        isTuneDisliked,
        getInterestedTracks,
        getNotInterestedTracks,
        forceProfileServerSync,
        clearListeningStats,
        isSyncingToServer,
        lastServerSyncTime,
        downloadedSet,
        downloadQualityMap: downloadedQualityMap,
        downloadTrack,
        removeDownload,
        removeMultipleDownloads,
        clearAllDownloads,
        downloadPlaylist,
        bulkDownloadState,
        currentLyrics,
        retryLyrics,
        sleepTimerRemaining,
        sleepTimerIsEndOfSong,
        setSleepTimerMinutes,
        setSleepTimerEndOfSong,
        cancelSleepTimer,
        showToast,
        toasts,
        toggleLikeTrack,
        createPlaylist,
        renamePlaylist,
        deletePlaylist,
        removeTrackFromPlaylist,
        addTrackToPlaylist,
        updatePlaylistTracks,
        addMultipleTracksToPlaylist,
        supersededNotice,
        setSupersededNotice,
        claimPlaybackHere,
        currentDeviceName,
        isRemotePlaybackActive,
        remoteDeviceName,
        isSettingsUnlocked,
        unlockSettingsWithSocial,
      }}
    >
      {children}
    </MusicContext.Provider>
  );
};

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (!context) throw new Error('useMusic must be used within a MusicProvider');
  return context;
};
