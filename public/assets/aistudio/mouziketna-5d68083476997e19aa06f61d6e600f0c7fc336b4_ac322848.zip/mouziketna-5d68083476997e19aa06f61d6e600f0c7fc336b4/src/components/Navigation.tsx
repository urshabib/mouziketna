import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useMusic } from '../context/MusicContext';
import {
  Home,
  Search,
  Library,
  Settings,
  ShieldAlert,
  Plus,
  Heart,
  Download,
  Music,
  User,
  Loader2,
  Smartphone,
  WifiOff,
  ChevronLeft,
} from 'lucide-react';
import { NavigationPane } from '../types';
import { getAppLogoSrc } from '../services/pwa';
import { PlaylistCover } from './PlaylistCover';

export const Sidebar: React.FC = () => {
  const {
    activePane,
    setActivePane,
    openCollection,
    userProfile,
    globalUser,
    setModalCreatePlaylistOpen,
    setIsInstallModalOpen,
    t,
  } = useMusic();

  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    const check =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsStandalone(check);
  }, []);

  const likedCount = userProfile.likedSongs?.length || 0;
  const customPlaylists = userProfile.customPlaylists || [];
  const followedArtists = userProfile.favouriteArtists || [];

  return (
    <aside className="hidden md:flex w-56 lg:w-64 xl:w-72 flex-col gap-3 p-3 lg:p-4 flex-shrink-0 select-none">
      {/* Brand & Nav */}
      <div className="bg-[#131317]/85 glass-panel rounded-3xl p-5 border border-white/10 shadow-2xl backdrop-blur-2xl">
        <button
          onClick={() => setActivePane('home')}
          className="logo hover:opacity-90 transition-opacity text-left mb-6 flex items-center gap-2.5 cursor-pointer"
        >
          <i className="ri-pulse-fill"></i>
          <span className="logo-textblock">
            MOUZIKETNA
            <span className="logo-signature">by habib</span>
          </span>
        </button>

        <nav className="flex flex-col gap-1.5">
          <button
            onClick={() => setActivePane('home')}
            className={`flex items-center gap-3.5 px-3.5 py-2.5 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
              activePane === 'home'
                ? 'bg-[var(--accent)] text-black font-extrabold shadow-lg shadow-[var(--accent)]/20 scale-[1.02]'
                : 'text-white/70 hover:text-white hover:bg-white/10'
            }`}
          >
            <Home className="w-5 h-5" /> {t('nav.home', 'Home')}
          </button>
          <button
            onClick={() => setActivePane('search')}
            className={`flex items-center gap-3.5 px-3.5 py-2.5 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
              activePane === 'search'
                ? 'bg-[var(--accent)] text-black font-extrabold shadow-lg shadow-[var(--accent)]/20 scale-[1.02]'
                : 'text-white/70 hover:text-white hover:bg-white/10'
            }`}
          >
            <Search className="w-5 h-5" /> {t('nav.search', 'Search')}
          </button>
          <button
            onClick={() => setActivePane('settings')}
            className={`flex items-center gap-3.5 px-3.5 py-2.5 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
              activePane === 'settings'
                ? 'bg-[var(--accent)] text-black font-extrabold shadow-lg shadow-[var(--accent)]/20 scale-[1.02]'
                : 'text-white/70 hover:text-white hover:bg-white/10'
            }`}
          >
            <Settings className="w-5 h-5" /> {t('nav.settings', 'Settings')}
          </button>

          {(typeof navigator !== 'undefined' && !navigator.onLine) && (
            <button
              onClick={() => setActivePane('offline')}
              className={`flex items-center gap-3.5 px-3.5 py-2.5 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
                activePane === 'offline'
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 shadow-sm'
                  : 'text-amber-400/80 hover:text-amber-400 hover:bg-amber-500/10'
              }`}
            >
              <WifiOff className="w-5 h-5 text-amber-400" /> Offline Hub
            </button>
          )}

          <button
            id="sidebar-install-app-btn"
            onClick={() => setIsInstallModalOpen(true)}
            className="flex items-center gap-3.5 px-3.5 py-2.5 rounded-2xl font-bold text-sm text-[var(--accent)] hover:bg-[var(--accent-soft)] transition-all border border-[var(--accent)]/20 cursor-pointer"
          >
            <Download className="w-5 h-5 text-[var(--accent)]" /> {t('modal.installApp', 'Install App')}
          </button>

          {(globalUser === 'admin' || userProfile.isAdmin) && (
            <button
              onClick={() => setActivePane('admin')}
              className={`flex items-center gap-3.5 px-3.5 py-2.5 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
                activePane === 'admin'
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                  : 'text-red-400/80 hover:text-red-400 hover:bg-red-500/10'
              }`}
            >
              <ShieldAlert className="w-5 h-5" /> {t('nav.admin', 'Admin')}
            </button>
          )}
        </nav>
      </div>

      {/* Library Shelf */}
      <div className="bg-[#131317]/85 glass-panel rounded-3xl p-4 flex-1 flex flex-col min-h-0 border border-white/10 shadow-2xl backdrop-blur-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-white/5 px-1">
          <button
            onClick={() => setActivePane('library')}
            className="flex items-center gap-2 text-white/80 hover:text-white font-bold text-sm transition-colors cursor-pointer"
          >
            <Library className="w-4 h-4 text-[var(--accent)]" /> {t('library.title', 'Your Library')}
          </button>
          <button
            onClick={() => setModalCreatePlaylistOpen(true)}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
            title={t('library.createPlaylist', 'Create Playlist')}
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-1 mt-2 pr-1">
          {/* Liked Songs */}
          <div
            onClick={() => openCollection('liked')}
            className="flex items-center gap-3 p-2 rounded-2xl hover:bg-white/8 cursor-pointer group transition-all"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[var(--accent)] to-black/80 flex items-center justify-center flex-shrink-0 text-white shadow-md group-hover:scale-105 transition-transform">
              <Heart className="w-5 h-5 fill-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h5 className="text-sm font-semibold truncate text-white group-hover:text-[var(--accent)] transition-colors">
                {t('library.likedSongs', 'Liked Songs')}
              </h5>
              <p className="text-xs text-white/50 truncate">
                {t('common.playlist', 'Playlist')} • {likedCount} {t('common.tracks', 'tracks')}
              </p>
            </div>
          </div>

          {/* Downloaded Songs */}
          <div
            onClick={() => openCollection('downloads')}
            className="flex items-center gap-3 p-2 rounded-2xl hover:bg-white/8 cursor-pointer group transition-all"
          >
            <div className="w-11 h-11 rounded-xl bg-[#1c1c20] flex items-center justify-center flex-shrink-0 text-[var(--accent)] shadow-md border border-white/10 group-hover:scale-105 transition-transform">
              <Download className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <h5 className="text-sm font-semibold truncate text-white group-hover:text-[var(--accent)] transition-colors">
                {t('library.downloads', 'Downloaded')}
              </h5>
              <p className="text-xs text-white/50 truncate">{t('common.offline', 'Offline music')}</p>
            </div>
          </div>

          {/* Custom Playlists */}
          {customPlaylists.map((pl) => (
            <div
              key={pl.id}
              onClick={() => openCollection('custom-playlist', pl.id, pl.name, pl.thumb)}
              className="flex items-center gap-3 p-2 rounded-2xl hover:bg-white/8 cursor-pointer group transition-all"
            >
              <PlaylistCover
                cover={pl.thumb}
                tracks={pl.tracks}
                sizeClass="w-11 h-11"
                roundedClass="rounded-xl"
                alt={pl.name}
                className="flex-shrink-0 shadow-sm group-hover:scale-105 transition-transform"
              />
              <div className="min-w-0 flex-1">
                <h5 className="text-sm font-semibold truncate text-white group-hover:text-[var(--accent)] transition-colors">
                  {pl.name}
                </h5>
                <p className="text-xs text-white/50 truncate">
                  Playlist • {pl.tracks?.length || 0} tracks
                </p>
              </div>
            </div>
          ))}

          {/* Followed Artists */}
          {followedArtists.map((artist) => (
            <div
              key={artist.id}
              onClick={() => openCollection('artist', artist.id, artist.title, artist.thumb)}
              className="flex items-center gap-3 p-2 rounded-2xl hover:bg-white/8 cursor-pointer group transition-all"
            >
              {artist.thumb ? (
                <img src={artist.thumb} alt={artist.title} className="w-11 h-11 rounded-full object-cover flex-shrink-0 shadow-sm group-hover:scale-105 transition-transform" />
              ) : (
                <div className="w-11 h-11 rounded-full bg-[#242426] flex items-center justify-center flex-shrink-0 text-white/40">
                  <User className="w-5 h-5" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <h5 className="text-sm font-semibold truncate text-white group-hover:text-[var(--accent)] transition-colors">
                  {artist.title}
                </h5>
                <p className="text-xs text-white/50 truncate">Artist</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};

export const MobileNav: React.FC = () => {
  const { activePane, setActivePane, userProfile, t } = useMusic();
  const isLiquidGlass = userProfile.liquidGlass !== false && userProfile.liquidGlassLevel !== 'off';

  // Home, Library, and Settings are grouped together in the pill
  const pillItems: { id: NavigationPane; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: t('nav.home', 'Home'), icon: <Home className="w-5 h-5" /> },
    { id: 'library', label: t('nav.library', 'Library'), icon: <Library className="w-5 h-5" /> },
    { id: 'settings', label: t('nav.settings', 'Settings'), icon: <Settings className="w-5 h-5" /> },
  ];

  const isSearchActive = activePane === 'search';

  if (isLiquidGlass) {
    return (
      <nav className="md:hidden fixed left-3 right-3 bottom-[calc(0.65rem+env(safe-area-inset-bottom))] z-40 flex items-center justify-between gap-3 max-w-sm mx-auto pointer-events-none select-none">
        {/* iOS-Style Liquid Glass Unified Capsule Pill for Home, Library, Settings */}
        <div className="flex-1 h-14 bg-[#141418]/85 glass-panel rounded-full px-1.5 py-1 flex items-center justify-around border border-white/10 shadow-2xl backdrop-blur-2xl pointer-events-auto relative min-w-0">
          {pillItems.map((item) => {
            const isActive = activePane === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActivePane(item.id)}
                className={`relative flex flex-col items-center justify-center flex-1 h-full py-0.5 rounded-full transition-colors duration-200 cursor-pointer z-10 ${
                  isActive
                    ? 'text-[var(--accent)] font-bold'
                    : 'text-white/50 hover:text-white/80 font-medium'
                }`}
                title={item.label}
                aria-label={item.label}
              >
                {/* Clean, smooth glass bubble transfer with zero stretching distortion */}
                {isActive && (
                  <motion.div
                    layoutId="liquid-nav-bubble"
                    className="absolute inset-0.5 rounded-full bg-[var(--accent)]/15 border border-[var(--accent)]/35 shadow-[0_0_20px_var(--accent-soft),inset_0_0_12px_var(--accent-soft)] backdrop-blur-xl -z-10"
                    transition={{
                      type: 'spring',
                      stiffness: 400,
                      damping: 32,
                    }}
                  >
                    <div className="absolute -inset-1 rounded-full bg-[var(--accent-soft)] blur-md -z-10 opacity-60" />
                  </motion.div>
                )}

                <div
                  className={`relative transition-transform duration-200 ${
                    isActive ? 'scale-110 drop-shadow-[0_0_10px_var(--accent-soft)] text-[var(--accent)]' : 'scale-100'
                  }`}
                >
                  {item.icon}
                </div>
                <span
                  className={`text-[9.5px] leading-tight tracking-tight mt-0.5 transition-colors ${
                    isActive ? 'text-[var(--accent)] font-black' : 'text-white/50'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Standalone Circular Search Icon Alone on the Right with Matching Accent Glow */}
        <button
          type="button"
          onClick={() => setActivePane('search')}
          className={`w-14 h-14 rounded-full flex flex-col items-center justify-center transition-all duration-300 pointer-events-auto cursor-pointer flex-shrink-0 relative ${
            isSearchActive
              ? 'bg-[var(--accent)]/20 border border-[var(--accent)]/60 text-[var(--accent)] shadow-[0_0_20px_var(--accent-soft),inset_0_1.5px_2px_rgba(255,255,255,0.45)] backdrop-blur-2xl scale-105'
              : 'bg-[#141418]/85 glass-panel border border-white/10 text-white/50 hover:text-white/80 shadow-2xl backdrop-blur-2xl hover:scale-105'
          }`}
          title={t('nav.search', 'Search')}
          aria-label={t('nav.search', 'Search')}
        >
          {isSearchActive && (
            <div className="absolute -inset-1 rounded-full bg-[var(--accent-soft)] blur-md -z-10 opacity-75" />
          )}
          <div
            className={`relative transition-transform duration-200 ${
              isSearchActive ? 'scale-110 drop-shadow-[0_0_10px_var(--accent-soft)] text-[var(--accent)]' : 'scale-100'
            }`}
          >
            <Search className="w-5 h-5" />
          </div>
          <span
            className={`text-[9px] leading-tight tracking-tight mt-0.5 transition-colors ${
              isSearchActive ? 'text-[var(--accent)] font-black' : 'text-white/50'
            }`}
          >
            {t('nav.search', 'Search')}
          </span>
        </button>
      </nav>
    );
  }

  // Classic Standard Bottom Bar when Liquid Glass is OFF
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-black/90 border-t border-white/10 px-6 py-2 pb-[max(0.6rem,env(safe-area-inset-bottom))] flex justify-between items-center select-none">
      <div className="flex items-center gap-8">
        {pillItems.map((item) => {
          const isActive = activePane === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActivePane(item.id)}
              className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
                isActive ? 'text-[var(--accent)] scale-105 font-bold drop-shadow-[0_0_8px_var(--accent-soft)]' : 'text-white/50 hover:text-white/80'
              }`}
            >
              {item.icon}
              <span className="text-[10px] font-bold tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Standalone Circular Search button */}
      <button
        type="button"
        onClick={() => setActivePane('search')}
        className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer ${
          isSearchActive
            ? 'bg-[var(--accent)]/25 border border-[var(--accent)] text-[var(--accent)] shadow-[0_0_12px_var(--accent-soft)]'
            : 'bg-white/10 text-white/50 hover:text-white'
        }`}
        title={t('nav.search', 'Search')}
        aria-label={t('nav.search', 'Search')}
      >
        <Search className="w-5 h-5" />
      </button>
    </nav>
  );
};

export const TopBar: React.FC = () => {
  const {
    userProfile,
    globalUser,
    setActivePane,
    goBack,
    bulkDownloadState,
    openCollection,
    setIsAuthGateOpen,
    setIsInstallModalOpen,
    t,
  } = useMusic();

  const [isStandalone, setIsStandalone] = useState(false);
  const isLiquidGlass = userProfile.liquidGlass !== false && userProfile.liquidGlassLevel !== 'off';

  useEffect(() => {
    const check =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsStandalone(check);
  }, []);

  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 12) return t('home.goodMorning', 'Good morning');
    if (h < 18) return t('home.goodAfternoon', 'Good afternoon');
    return t('home.goodEvening', 'Good evening');
  };

  const effectiveDisplayName = userProfile.displayName || userProfile.username || '';

  return (
    <header
      className={`sticky top-0 z-30 flex items-center justify-between transition-all select-none ${
        isLiquidGlass
          ? 'mx-3 sm:mx-6 my-2 mt-[max(0.5rem,env(safe-area-inset-top))] px-4 sm:px-6 py-2.5 bg-[#141418]/85 glass-panel rounded-full border border-white/10 shadow-2xl backdrop-blur-2xl md:mx-4 md:my-3 md:px-6 md:py-3'
          : 'px-4 sm:px-8 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3.5 bg-black/85 md:bg-[#141418]/85 md:glass-panel md:rounded-full md:mx-4 md:my-3 md:px-6 md:py-3 md:border md:border-white/10 md:shadow-xl backdrop-blur-xl'
      }`}
    >
      {/* Left side: Mobile Logo vs Desktop Navigation Cluster */}
      <div className="flex items-center gap-3">
        {/* Mobile-only Logo (hidden on desktop because sidebar has it) */}
        <div className="md:hidden flex items-center">
          <button
            onClick={() => setActivePane('home')}
            className="logo hover:opacity-90 transition-opacity text-left flex items-center gap-2 cursor-pointer"
          >
            <i className="ri-pulse-fill"></i>
            <span className="logo-textblock text-xs">
              MOUZIKETNA
              <span className="logo-signature">by habib</span>
            </span>
          </button>
        </div>

        {/* Desktop Navigation Cluster */}
        <div className="hidden md:flex items-center gap-2.5">
          <button
            type="button"
            onClick={goBack}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 active:scale-95 text-white/70 hover:text-white flex items-center justify-center border border-white/10 transition-all cursor-pointer shadow-sm"
            title="Go back"
            aria-label="Go back"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <h2 className="font-extrabold text-sm text-white/80 max-w-[180px] lg:max-w-[260px] truncate pl-1">
            {getGreeting()}{effectiveDisplayName ? `, ${effectiveDisplayName}` : ''}
          </h2>
        </div>

        {/* Desktop Quick Search Pill */}
        <div
          onClick={() => setActivePane('search')}
          className="hidden md:flex items-center gap-2.5 px-4 py-2 rounded-full bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 text-white/50 hover:text-white transition-all cursor-pointer w-44 lg:w-60 xl:w-72 shadow-inner group ml-2"
          title="Search songs, artists, playlists"
        >
          <Search className="w-3.5 h-3.5 text-white/40 group-hover:text-[var(--accent)] transition-colors" />
          <span className="text-xs font-medium truncate">Search songs, artists...</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Offline Mode Indicator Badge */}
        {(typeof navigator !== 'undefined' && !navigator.onLine) && (
          <button
            onClick={() => setActivePane('offline')}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-400 font-extrabold text-xs shadow-sm hover:scale-105 active:scale-95 transition-all cursor-pointer"
            title="Offline Mode Active"
          >
            <WifiOff className="w-3.5 h-3.5" />
            <span>Offline</span>
          </button>
        )}

        {/* Install App Button */}
        {!isStandalone && (
          <button
            id="topbar-install-btn"
            onClick={() => setIsInstallModalOpen(true)}
            className="flex items-center justify-center gap-1.5 bg-[var(--accent)] hover:brightness-110 active:scale-95 text-black p-2 sm:px-3.5 sm:py-1.5 rounded-full font-black text-xs transition-all shadow-md shadow-[var(--accent)]/25 flex-shrink-0 cursor-pointer"
            title={t('modal.installApp', 'Install App')}
            aria-label={t('modal.installApp', 'Install App')}
          >
            <Download className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="hidden sm:inline">{t('modal.installApp', 'Install App')}</span>
          </button>
        )}

        {/* Bulk Download Indicator */}
        {bulkDownloadState.inProgress && (
          <button
            onClick={() => openCollection('downloads')}
            className="flex items-center gap-2 bg-[var(--accent-soft)] text-[var(--accent)] text-xs font-bold px-3 py-1.5 rounded-full border border-[var(--accent)]/30 animate-pulse"
          >
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span>{bulkDownloadState.done}/{bulkDownloadState.total}</span>
          </button>
        )}

        {/* Profile Chip with Display Name */}
        <button
          onClick={() => setActivePane('account')}
          className="flex items-center gap-2 bg-white/10 hover:bg-white/15 px-2.5 sm:px-3 py-1.5 rounded-full border border-white/10 transition-colors max-w-[120px] sm:max-w-[170px] cursor-pointer"
          title="View Listening Statistics & Profile"
        >
          {userProfile.avatarUrl ? (
            <img
              src={userProfile.avatarUrl}
              alt={effectiveDisplayName || 'Avatar'}
              className="w-6 h-6 rounded-full object-cover flex-shrink-0"
            />
          ) : (
            <div className="w-6 h-6 rounded-full bg-[var(--accent)] text-black font-bold text-xs flex items-center justify-center flex-shrink-0">
              {effectiveDisplayName ? effectiveDisplayName.charAt(0).toUpperCase() : <User className="w-3.5 h-3.5" />}
            </div>
          )}
          <span className="text-xs font-bold text-white truncate overflow-hidden whitespace-nowrap text-ellipsis">
            {effectiveDisplayName || t('nav.account', 'Profile')}
          </span>
        </button>
      </div>
    </header>
  );
};
