import React, { useState } from 'react';
import { useMusic } from '../context/MusicContext';
import {
  X,
  Plus,
  Music,
  FolderPlus,
  DownloadCloud,
  Link as LinkIcon,
  AlertTriangle,
  Loader2,
  Gift,
  ShieldAlert,
  UserPlus,
  LogIn,
  CheckCircle2,
  Eye,
  EyeOff,
  ExternalLink,
  Globe,
  ChevronDown,
  Check,
} from 'lucide-react';
import {
  importPlaylistFromYoutube,
  importPlaylistFromSpotify,
  resolveSingleSongLink,
  extractSpotifyPlaylistUrl,
  fetchWithTimeout,
  NEW_HUB_BACKEND,
  registerUser,
} from '../services/api';
import { PlaylistCover } from './PlaylistCover';
import { getPersistentPlaylistCover } from '../services/storage';

export const Modals: React.FC = () => {
  const {
    modalCreatePlaylistOpen,
    setModalCreatePlaylistOpen,
    modalAddToPlaylistTrack,
    setModalAddToPlaylistTrack,
    modalImportPlaylistOpen,
    setModalImportPlaylistOpen,
    modalAddSongByLinkPlId,
    setModalAddSongByLinkPlId,
    modalAudioRecognitionOpen,
    setModalAudioRecognitionOpen,
    modalConfirm,
    setModalConfirm,
    isAuthGateOpen,
    setIsAuthGateOpen,
    isAccountDisabledModalOpen,
    setIsAccountDisabledModalOpen,
    login,
    createPlaylist,
    addTrackToPlaylist,
    userProfile,
    syncProfile,
    forceProfileServerSync,
    showToast,
    language,
    setLanguage,
    t,
  } = useMusic();

  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);

  // Add/Create Playlist state
  const [newPlaylistName, setNewPlaylistName] = useState('');

  // Import Playlist state
  const [importPlatform, setImportPlatform] = useState<'youtube' | 'spotify' | 'deezer' | 'apple'>('youtube');
  const [importUrl, setImportUrl] = useState('');
  const [importLoading, setImportLoading] = useState(false);
  const [importError, setImportError] = useState('');

  // Password visibility states
  const [showGatePass, setShowGatePass] = useState(false);
  const [showRegPass, setShowRegPass] = useState(false);
  const [showRegConfirmPass, setShowRegConfirmPass] = useState(false);

  // Add song by link state
  const [songLink, setSongLink] = useState('');
  const [songLinkLoading, setSongLinkLoading] = useState(false);
  const [songLinkError, setSongLinkError] = useState('');

  // Audio Recognition state
  const [isListening, setIsListening] = useState(false);

  // Auth gate state (Login vs Public Sign Up)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [gateUser, setGateUser] = useState('');
  const [gatePass, setGatePass] = useState('');
  const [gateLoading, setGateLoading] = useState(false);
  const [gateError, setGateError] = useState('');

  // Public Sign Up state
  const [regUser, setRegUser] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regConfirmPass, setRegConfirmPass] = useState('');
  const [regLoading, setRegLoading] = useState(false);
  const [regError, setRegError] = useState('');
  const [regSuccessMsg, setRegSuccessMsg] = useState('');

  // Anti-spam & anti-bot protection states
  const [botTrap, setBotTrap] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutSeconds, setLockoutSeconds] = useState(0);
  const lastRegTimeRef = React.useRef(0);

  React.useEffect(() => {
    if (lockoutSeconds <= 0) return;
    const timer = setInterval(() => {
      setLockoutSeconds((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [lockoutSeconds]);

  // Handle Add to Playlist
  const handleAddToExisting = (plId: string) => {
    if (!modalAddToPlaylistTrack) return;
    addTrackToPlaylist(plId, modalAddToPlaylistTrack);
    setModalAddToPlaylistTrack(null);
  };

  const handleCreateAndAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    createPlaylist(newPlaylistName.trim(), modalAddToPlaylistTrack || undefined);
    setNewPlaylistName('');
    setModalCreatePlaylistOpen(false);
    setModalAddToPlaylistTrack(null);
  };

  // Handle Import Playlist
  const handleImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!importUrl.trim()) return;
    setImportLoading(true);
    setImportError('');

    try {
      const spotifyUrl = extractSpotifyPlaylistUrl(importUrl);
      if (spotifyUrl) {
        const importedPl = await importPlaylistFromSpotify(spotifyUrl);
        const updatedProf = {
          ...userProfile,
          customPlaylists: [importedPl, ...userProfile.customPlaylists],
        };
        syncProfile(updatedProf);
        forceProfileServerSync(updatedProf).catch(() => {});
        showToast(`Imported "${importedPl.name}" (${importedPl.tracks.length} tracks from Spotify)!`);
        setModalImportPlaylistOpen(false);
        setImportUrl('');
        return;
      }

      // YouTube / YouTube Music playlist import with multiple fallback tiers
      const importedPl = await importPlaylistFromYoutube(importUrl);
      const updatedProf = {
        ...userProfile,
        customPlaylists: [importedPl, ...userProfile.customPlaylists],
      };
      syncProfile(updatedProf);
      forceProfileServerSync(updatedProf).catch(() => {});
      showToast(`Imported "${importedPl.name}" (${importedPl.tracks.length} tracks)!`);
      setModalImportPlaylistOpen(false);
      setImportUrl('');
    } catch (err: any) {
      setImportError(err.message || "Couldn't import that playlist.");
    } finally {
      setImportLoading(false);
    }
  };

  // Handle Add Song by Link
  const handleAddSongByLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!songLink.trim() || !modalAddSongByLinkPlId) return;
    setSongLinkLoading(true);
    setSongLinkError('');

    try {
      const track = await resolveSingleSongLink(songLink.trim());
      addTrackToPlaylist(modalAddSongByLinkPlId, track);
      setModalAddSongByLinkPlId(null);
      setSongLink('');
    } catch (err: any) {
      setSongLinkError(err.message || "Couldn't resolve that track link.");
    } finally {
      setSongLinkLoading(false);
    }
  };

  // Handle Gate Login
  const handleGateLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (botTrap) {
      setGateError('Automated request blocked.');
      return;
    }
    if (lockoutSeconds > 0) {
      setGateError(`Too many failed attempts. Please wait ${lockoutSeconds}s before retrying.`);
      return;
    }
    const u = gateUser.trim();
    const p = gatePass.trim();
    if (!u || !p) return;
    setGateLoading(true);
    setGateError('');

    try {
      const res = await login(u, p);
      if (!res.success) {
        const nextAttempts = failedAttempts + 1;
        setFailedAttempts(nextAttempts);
        if (nextAttempts >= 5) {
          setLockoutSeconds(30);
          setGateError('Too many failed attempts. Entry locked for 30 seconds.');
        } else {
          setGateError(res.error || 'Login failed. Please check your username and password.');
        }
      } else {
        setFailedAttempts(0);
        setLockoutSeconds(0);
      }
    } catch (err: any) {
      setGateError(err.message || 'Connection error. Please try again.');
    } finally {
      setGateLoading(false);
    }
  };

  // Handle Public Registration
  const handlePublicRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (botTrap) {
      setRegError('Automated registration blocked.');
      return;
    }
    const now = Date.now();
    if (now - lastRegTimeRef.current < 2500) {
      setRegError('Please wait a moment before submitting again.');
      return;
    }
    lastRegTimeRef.current = now;

    const u = regUser.trim().toLowerCase();
    const p = regPass.trim();
    const cp = regConfirmPass.trim();

    if (!u || !p) {
      setRegError('Please fill in all fields.');
      return;
    }
    if (u.length < 3 || u.length > 30) {
      setRegError('Username must be between 3 and 30 characters.');
      return;
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(u)) {
      setRegError('Username may only contain letters, numbers, underscores, and hyphens.');
      return;
    }
    if (u === '__proto__' || u === 'constructor' || u === 'prototype') {
      setRegError('Invalid username chosen.');
      return;
    }
    if (p.length < 4) {
      setRegError('Password must be at least 4 characters.');
      return;
    }
    if (p !== cp) {
      setRegError('Passwords do not match.');
      return;
    }

    setRegLoading(true);
    setRegError('');
    setRegSuccessMsg('');

    try {
      const res = await registerUser(u, p, botTrap);
      if (!res.success) {
        setRegError(res.error || 'Registration failed.');
      } else {
        setRegSuccessMsg(res.message || 'Account registered successfully!');
        if (res.enabled) {
          await login(u, p);
        } else {
          setRegUser('');
          setRegPass('');
          setRegConfirmPass('');
        }
      }
    } catch (err: any) {
      setRegError(err.message || 'Connection error.');
    } finally {
      setRegLoading(false);
    }
  };

  return (
    <>
      {/* 1. ADD / CREATE PLAYLIST MODAL */}
      {(modalCreatePlaylistOpen || modalAddToPlaylistTrack) && (
        <div
          onClick={() => {
            setModalCreatePlaylistOpen(false);
            setModalAddToPlaylistTrack(null);
          }}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in select-none"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-[#18181b] glass-panel border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="font-bold text-lg text-white">
                {modalAddToPlaylistTrack ? t('modal.addToPlaylist', 'Add to Playlist') : t('library.createPlaylist', 'Create Playlist')}
              </h3>
              <button
                onClick={() => {
                  setModalCreatePlaylistOpen(false);
                  setModalAddToPlaylistTrack(null);
                }}
                className="p-1.5 text-white/40 hover:text-white rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List existing playlists if adding a track */}
            {modalAddToPlaylistTrack && userProfile.customPlaylists.length > 0 && (
              <div className="max-h-48 overflow-y-auto flex flex-col gap-1 pr-1">
                {userProfile.customPlaylists.map((pl) => {
                  const customCover = (pl.id ? getPersistentPlaylistCover(pl.id) : null) || pl.customCover;
                  return (
                    <button
                      key={pl.id}
                      onClick={() => handleAddToExisting(pl.id)}
                      className="flex items-center justify-between p-2.5 rounded-xl hover:bg-white/10 text-left transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0 bg-[#252528] shadow-sm flex items-center justify-center">
                          <PlaylistCover
                            cover={customCover}
                            tracks={pl.tracks}
                            sizeClass="w-8 h-8"
                            roundedClass="rounded-lg"
                            alt={pl.name}
                          />
                        </div>
                        <span className="font-semibold text-sm text-white truncate">{pl.name}</span>
                      </div>
                      <span className="text-xs text-white/40 group-hover:text-white/60">
                        {pl.tracks.length} {t('common.tracks', 'tracks')}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Create new playlist form */}
            <form onSubmit={handleCreateAndAdd} className="flex flex-col gap-3 pt-2">
              <label className="text-xs font-bold uppercase tracking-wider text-white/50">
                {t('library.newPlaylist', 'New Playlist')}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder={t('library.playlistName', 'Playlist name')}
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors"
                />
                <button
                  type="submit"
                  disabled={!newPlaylistName.trim()}
                  className="px-5 py-2.5 bg-[var(--accent)] text-black font-extrabold text-sm rounded-xl hover:scale-105 active:scale-95 disabled:opacity-50 disabled:scale-100 transition-all cursor-pointer"
                >
                  {t('common.save', 'Create')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. IMPORT PLAYLIST MODAL */}
      {modalImportPlaylistOpen && (
        <div
          onClick={() => setModalImportPlaylistOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in select-none"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-[#18181b] glass-panel border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <DownloadCloud className="w-5 h-5 text-[var(--accent)]" />
                <h3 className="font-bold text-lg text-white">Import Playlist</h3>
              </div>
              <button
                onClick={() => setModalImportPlaylistOpen(false)}
                className="p-1.5 text-white/40 hover:text-white rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Platform Selection Tabs */}
            <div className="grid grid-cols-4 gap-1.5 bg-black/40 p-1.5 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => { setImportPlatform('youtube'); setImportError(''); }}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  importPlatform === 'youtube'
                    ? 'bg-red-500/20 text-red-400 border border-red-500/40 shadow'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                YouTube
              </button>
              <button
                type="button"
                onClick={() => { setImportPlatform('spotify'); setImportError(''); }}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  importPlatform === 'spotify'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                Spotify
              </button>
              <button
                type="button"
                onClick={() => { setImportPlatform('deezer'); setImportError(''); }}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  importPlatform === 'deezer'
                    ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40 shadow'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                Deezer
              </button>
              <button
                type="button"
                onClick={() => { setImportPlatform('apple'); setImportError(''); }}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  importPlatform === 'apple'
                    ? 'bg-pink-500/20 text-pink-400 border border-pink-500/40 shadow'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                Apple
              </button>
            </div>

            {importPlatform === 'youtube' ? (
              <>
                <p className="text-xs text-white/60 leading-relaxed">
                  Paste a public YouTube Music or YouTube playlist URL. Songs will be imported directly
                  into your library with multi-tier mirror fallback so it never fails.
                </p>

                <form onSubmit={handleImportSubmit} className="flex flex-col gap-3">
                  <input
                    type="text"
                    placeholder="https://music.youtube.com/playlist?list=..."
                    value={importUrl}
                    onChange={(e) => setImportUrl(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors"
                  />

                  {importError && (
                    <p className="text-xs text-red-400 font-medium bg-red-500/10 p-2.5 rounded-lg border border-red-500/20">
                      {importError}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={importLoading || !importUrl.trim()}
                    className="w-full py-3 bg-[var(--accent)] text-black font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 transition-all shadow-lg cursor-pointer"
                  >
                    {importLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Importing Playlist…</span>
                      </>
                    ) : (
                      <span>Import Tracks</span>
                    )}
                  </button>
                </form>
              </>
            ) : (
              <div className="flex flex-col items-center text-center p-4 rounded-2xl bg-white/5 border border-white/10 gap-3 animate-in fade-in">
                <div className="w-12 h-12 rounded-2xl bg-[var(--accent)]/15 border border-[var(--accent)]/30 flex items-center justify-center text-[var(--accent)]">
                  <DownloadCloud className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-base">Contact the admin to get your playlist</h4>
                  <p className="text-xs text-white/60 mt-1 leading-relaxed">
                    Direct {importPlatform === 'spotify' ? 'Spotify' : importPlatform === 'deezer' ? 'Deezer' : 'Apple Music'} playlist conversion is handled personally by our admin team. Reach out via Instagram or TikTok with your playlist link!
                  </p>
                </div>

                <div className="flex gap-2 w-full mt-2">
                  <a
                    href="https://instagram.com/mouziketna"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-500 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md hover:opacity-95 transition-opacity"
                  >
                    <span>Instagram</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href="https://www.tiktok.com/@mouziketna.app"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 px-3 rounded-xl bg-black border border-white/20 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md hover:bg-white/10 transition-colors"
                  >
                    <span>TikTok</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. ADD SONG BY LINK MODAL */}
      {modalAddSongByLinkPlId && (
        <div
          onClick={() => setModalAddSongByLinkPlId(null)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in select-none"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-[#18181b] glass-panel border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <LinkIcon className="w-5 h-5 text-[var(--accent)]" />
                <h3 className="font-bold text-lg text-white">Add Song by Link</h3>
              </div>
              <button
                onClick={() => setModalAddSongByLinkPlId(null)}
                className="p-1.5 text-white/40 hover:text-white rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-white/60 leading-relaxed">
              Paste a YouTube or YouTube Music song link to add it to this playlist.
            </p>

            <form onSubmit={handleAddSongByLink} className="flex flex-col gap-3">
              <input
                type="text"
                placeholder="https://music.youtube.com/watch?v=..."
                value={songLink}
                onChange={(e) => setSongLink(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors"
              />

              {songLinkError && (
                <p className="text-xs text-red-400 font-medium bg-red-500/10 p-2.5 rounded-lg border border-red-500/20">
                  {songLinkError}
                </p>
              )}

              <button
                type="submit"
                disabled={songLinkLoading || !songLink.trim()}
                className="w-full py-3 bg-[var(--accent)] text-black font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 transition-all shadow-lg"
              >
                {songLinkLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Resolving Track…</span>
                  </>
                ) : (
                  <span>Add to Playlist</span>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 4. CONFIRM MODAL */}
      {modalConfirm && (
        <div
          onClick={() => setModalConfirm(null)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in select-none"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#18181b] glass-panel border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center gap-3 animate-in zoom-in-95 duration-200"
          >
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mb-1">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-lg text-white">{modalConfirm.title}</h3>
            <p className="text-xs text-white/60 leading-relaxed">{modalConfirm.text}</p>
            <div className="flex gap-2 w-full mt-3">
              <button
                onClick={() => setModalConfirm(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-sm transition-colors cursor-pointer"
              >
                {t('modal.cancel', 'Cancel')}
              </button>
              <button
                onClick={() => {
                  modalConfirm.onConfirm();
                  setModalConfirm(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold text-sm transition-colors cursor-pointer"
              >
                {t('modal.confirm', 'Confirm')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. AUTH GATE MODAL (WITH PUBLIC SIGN UP) */}
      {isAuthGateOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in select-none">
          <div className="w-full max-w-sm bg-[#18181b] glass-panel border border-white/10 rounded-3xl p-7 shadow-2xl flex flex-col items-center text-center gap-4 relative overflow-visible">
            
            {/* Top Right Language Selector Button */}
            <div className="absolute top-4 right-4 z-20">
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsLangMenuOpen((prev) => !prev)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-xs font-bold text-white transition-all cursor-pointer shadow-md"
                  title={t('settings.language', 'Language')}
                >
                  <Globe className="w-3.5 h-3.5 text-[var(--accent)]" />
                  <span className="uppercase text-[10px] font-extrabold">{language || 'en'}</span>
                  <ChevronDown className="w-3 h-3 text-white/60" />
                </button>

                {isLangMenuOpen && (
                  <div className="absolute right-0 mt-1.5 w-36 bg-[#18181b] border border-white/15 rounded-2xl p-1.5 shadow-2xl flex flex-col gap-1 z-30 animate-in fade-in zoom-in-95">
                    <button
                      type="button"
                      onClick={() => {
                        setLanguage('en');
                        setIsLangMenuOpen(false);
                      }}
                      className={`flex items-center justify-between w-full px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                        language === 'en' ? 'bg-[var(--accent)] text-black font-extrabold' : 'text-white/80 hover:bg-white/10'
                      }`}
                    >
                      <span>English</span>
                      {language === 'en' && <Check className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setLanguage('fr');
                        setIsLangMenuOpen(false);
                      }}
                      className={`flex items-center justify-between w-full px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                        language === 'fr' ? 'bg-[var(--accent)] text-black font-extrabold' : 'text-white/80 hover:bg-white/10'
                      }`}
                    >
                      <span>Français</span>
                      {language === 'fr' && <Check className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setLanguage('ar');
                        setIsLangMenuOpen(false);
                      }}
                      className={`flex items-center justify-between w-full px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                        language === 'ar' ? 'bg-[var(--accent)] text-black font-extrabold' : 'text-white/80 hover:bg-white/10'
                      }`}
                    >
                      <span>العربية</span>
                      {language === 'ar' && <Check className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[var(--accent)] to-black/80 flex items-center justify-center shadow-lg text-white mb-1">
              <Gift className="w-7 h-7" />
            </div>

            {/* Mode Switcher Tabs */}
            <div className="flex bg-black/40 p-1 rounded-xl border border-white/10 w-full">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setGateError('');
                  setRegError('');
                  setRegSuccessMsg('');
                }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  authMode === 'login'
                    ? 'bg-[var(--accent)] text-black font-extrabold shadow-md'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{t('modal.signIn', 'Sign In')}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('register');
                  setGateError('');
                  setRegError('');
                  setRegSuccessMsg('');
                }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  authMode === 'register'
                    ? 'bg-[var(--accent)] text-black font-extrabold shadow-md'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{t('modal.signUp', 'Sign Up')}</span>
              </button>
            </div>

            {authMode === 'login' ? (
              <>
                <div>
                  <h3 className="font-black text-xl text-white">{t('modal.signInTitle', 'Sign In to MOUZIKETNA')}</h3>
                  <p className="text-xs text-white/50 mt-1">
                    {t('modal.signInDesc', 'Enter your username and password to access your cloud profile & playlists.')}
                  </p>
                </div>

                <form onSubmit={handleGateLogin} className="w-full flex flex-col gap-3">
                  {/* Invisible honeypot field for anti-bot spam protection */}
                  <div style={{ display: 'none' }} aria-hidden="true">
                    <input
                      type="text"
                      name="bot_field"
                      tabIndex={-1}
                      autoComplete="off"
                      value={botTrap}
                      onChange={(e) => setBotTrap(e.target.value)}
                    />
                  </div>
                  <input
                    type="text"
                    placeholder={t('modal.username', 'Username')}
                    value={gateUser}
                    onChange={(e) => setGateUser(e.target.value)}
                    autoCapitalize="none"
                    autoCorrect="off"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors text-center font-medium"
                  />
                  <div className="relative w-full">
                    <input
                      type={showGatePass ? 'text' : 'password'}
                      placeholder={t('modal.password', 'Password')}
                      value={gatePass}
                      onChange={(e) => setGatePass(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-4 pr-10 py-3 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors text-center font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowGatePass(!showGatePass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors cursor-pointer p-1"
                      tabIndex={-1}
                      aria-label="Toggle password visibility"
                    >
                      {showGatePass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {gateError && (
                    <p className="text-xs text-red-400 font-medium bg-red-500/10 p-2.5 rounded-lg border border-red-500/20 text-left">
                      {gateError}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={gateLoading || lockoutSeconds > 0 || !gateUser.trim() || !gatePass.trim()}
                    className="w-full py-3 bg-[var(--accent)] text-black font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 transition-all shadow-lg mt-1 cursor-pointer"
                  >
                    {gateLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : lockoutSeconds > 0 ? (
                      <span>Locked ({lockoutSeconds}s)</span>
                    ) : (
                      <span>{t('modal.signIn', 'Sign In')}</span>
                    )}
                  </button>
                </form>
              </>
            ) : (
              <>
                <div>
                  <h3 className="font-black text-xl text-white">{t('modal.signUpTitle', 'Create New Account')}</h3>
                  <p className="text-xs text-white/50 mt-1">
                    {t('modal.signUpDesc', 'Sign up to stream tunes, create playlists, and save your offline music.')}
                  </p>
                </div>

                <form onSubmit={handlePublicRegister} className="w-full flex flex-col gap-3">
                  {/* Invisible honeypot field for anti-bot spam protection */}
                  <div style={{ display: 'none' }} aria-hidden="true">
                    <input
                      type="text"
                      name="bot_field_reg"
                      tabIndex={-1}
                      autoComplete="off"
                      value={botTrap}
                      onChange={(e) => setBotTrap(e.target.value)}
                    />
                  </div>
                  <input
                    type="text"
                    placeholder={t('modal.chooseUsername', 'Choose Username')}
                    value={regUser}
                    onChange={(e) => setRegUser(e.target.value)}
                    autoCapitalize="none"
                    autoCorrect="off"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors text-center font-medium"
                  />
                  <div className="relative w-full">
                    <input
                      type={showRegPass ? 'text' : 'password'}
                      placeholder={t('modal.createPassword', 'Create Password')}
                      value={regPass}
                      onChange={(e) => setRegPass(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-4 pr-10 py-2.5 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors text-center font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPass(!showRegPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors cursor-pointer p-1"
                      tabIndex={-1}
                      aria-label="Toggle password visibility"
                    >
                      {showRegPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="relative w-full">
                    <input
                      type={showRegConfirmPass ? 'text' : 'password'}
                      placeholder={t('modal.confirmPassword', 'Confirm Password')}
                      value={regConfirmPass}
                      onChange={(e) => setRegConfirmPass(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-4 pr-10 py-2.5 text-sm text-white focus:outline-none focus:border-[var(--accent)] transition-colors text-center font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegConfirmPass(!showRegConfirmPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors cursor-pointer p-1"
                      tabIndex={-1}
                      aria-label="Toggle password visibility"
                    >
                      {showRegConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {regError && (
                    <p className="text-xs text-red-400 font-medium bg-red-500/10 p-2.5 rounded-lg border border-red-500/20 text-left">
                      {regError}
                    </p>
                  )}

                  {regSuccessMsg && (
                    <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs text-left font-semibold flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span>{regSuccessMsg}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={regLoading || !regUser.trim() || !regPass.trim() || !regConfirmPass.trim()}
                    className="w-full py-3 bg-[var(--accent)] text-black font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 transition-all shadow-lg mt-1 cursor-pointer"
                  >
                    {regLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <span>{t('modal.registerAccount', 'Register Account')}</span>
                    )}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}

      {/* 6. ACCOUNT NOT ENABLED / RESTRICTED MODAL */}
      {isAccountDisabledModalOpen && (
        <div
          onClick={() => setIsAccountDisabledModalOpen(false)}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in select-none"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#18181b] glass-panel border border-amber-500/30 rounded-3xl p-7 shadow-2xl flex flex-col items-center text-center gap-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-lg">
              <ShieldAlert className="w-7 h-7" />
            </div>

            <div>
              <h3 className="font-extrabold text-xl text-white">Account Not Enabled</h3>
              <p className="text-xs text-white/60 mt-2 leading-relaxed">
                Your account is currently pending administrator approval. You can browse public playlists and search, but track playback is restricted until an administrator enables your account.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300/90 text-left font-medium w-full leading-snug">
              ✓ Please contact an administrator to enable your account in real time.
            </div>

            <button
              onClick={() => setIsAccountDisabledModalOpen(false)}
              className="w-full py-3 bg-[var(--accent)] text-black font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer"
            >
              Understand & Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
