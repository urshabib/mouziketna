export interface Track {
  id: string;
  title: string;
  artist: string;
  album?: string;
  thumb: string | null;
  type: 'song' | 'artist' | 'playlist' | 'video';
  duration?: number;
}

export interface SongPlayStat {
  id: string;
  title: string;
  artist: string;
  thumb?: string | null;
  playCount: number;
  minutesListened: number;
  lastPlayed: number;
}

export interface ArtistPlayStat {
  name: string;
  playCount: number;
  minutesListened: number;
  thumb?: string | null;
}

export interface UserStats {
  totalMinutesListened: number;
  totalTracksPlayed: number;
  topSongs: SongPlayStat[];
  topArtists: ArtistPlayStat[];
  lastUpdated?: number;
}

export interface UserProfile {
  username: string;
  password?: string;
  displayName?: string;
  email?: string;
  likedSongs: Track[];
  customPlaylists: CustomPlaylist[];
  favouriteArtists: Track[];
  favouriteAlbums: any[];
  recentlyPlayed: Track[];
  hiddenStatsSongs?: SongPlayStat[];
  stats?: UserStats;
  dataSaver: boolean;
  dataSaverLevel: 'off' | 'saver' | 'ultra';
  downloadQuality?: 'stable' | 'high' | 'saver' | 'ultra';
  autoCacheQuality?: 'stable' | 'high' | 'saver' | 'ultra';
  customAppName?: string;
  appLogo?: string;
  downloadLyricsOffline: boolean;
  downloadArtOffline?: boolean;
  artQualityOffline?: 'low' | 'medium' | 'high' | 'original';
  autoCachePlayed: boolean;
  liquidGlass: boolean;
  liquidGlassLevel?: 'off' | 'medium' | 'ultra';
  language?: 'en' | 'fr' | 'ar';
  theme: 'dark' | 'light';
  accentColor: string;
  customAccentHex?: string;
  lyricsFont?: 'poppins' | 'bebas' | 'caveat' | 'playfair' | 'righteous' | 'jetbrains' | string;
  lyricsColor: string;
  customLyricsHex?: string;
  lyricsGlow?: 'off' | 'default' | 'strong';
  lyricsSignLanguage?: boolean;
  keyPartsDisplay?: 'off' | 'dots' | 'full';
  progressBarStyle?: 'default' | 'block' | 'wave' | 'aurora' | 'neon';
  progressBarColor?: string;
  customProgressBarHex?: string;
  presetTint: string;
  uiScale?: 'small' | 'default' | 'large' | 'extraLarge';
  activePreset: string | null;
  avatarUrl: string | null;
  isAdmin?: boolean;
  enabled?: boolean;
  isSettingsUnlocked?: boolean;
  unlockedSocialHandle?: string;
  unlockedPlatform?: string;
  unlockedAt?: number;
}

export interface SongHighlight {
  id: string;
  label: string;
  startTime: number;
  endTime: number;
  type: 'chorus' | 'hook' | 'drop' | 'intro';
}

export interface CustomPlaylist {
  id: string;
  name: string;
  tracks: Track[];
  source?: string;
  thumb?: string | null;
  customCover?: string | null;
}

export interface SyncedLyricsLine {
  time: number;
  text: string;
}

export interface LyricsData {
  mode: 'loading' | 'synced' | 'plain' | 'none' | 'error';
  lines?: SyncedLyricsLine[] | string | null;
  source?: string;
}

export interface DownloadRecord {
  id: string;
  title: string;
  artist: string;
  thumbLowRes: Blob | null;
  audioBlob: Blob;
  quality: string;
  lyricsData: LyricsData | null;
  sizeBytes: number;
  downloadedAt: number;
}

export type NavigationPane = 'home' | 'search' | 'library' | 'collection' | 'settings' | 'account' | 'admin' | 'offline';

export interface CollectionTarget {
  type: 'liked' | 'downloads' | 'custom-playlist' | 'artist' | 'playlist';
  id?: string | null;
  title?: string;
  thumb?: string | null;
}


